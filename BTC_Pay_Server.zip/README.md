# BTC PayServer

Self-hostable Bitcoin payment server. The payment engine is a FastAPI service talking to Bitcoin Core over RPC; `index.html` is the operator dashboard and the hosted customer checkout.

**Status: first cut, nothing in this repository has been executed yet.** Unit tests are written (`backend/tests`) but have not been run, and the regtest flow below has not been exercised end to end.

## Run it (regtest)

```bash
cp .env.example .env              # set the change-me values and BOOTSTRAP_API_KEY
docker compose up -d --build
./scripts/regtest.sh fund         # mines 101 blocks into a throwaway "funder" wallet
```

1. Open http://localhost:8000 and sign in with `BOOTSTRAP_API_KEY`.
2. Payments → create a payment, then open its checkout page (address and QR code).
3. `./scripts/regtest.sh pay <address> <btc>`: checkout shows "Payment detected" (0 confirmations, not final).
4. `./scripts/regtest.sh mine 1`: CONFIRMED once `confirmations_required` is met.
5. `./scripts/regtest.sh mine 2`: SETTLED at `SETTLEMENT_CONFIRMATIONS` (3 in `.env.example`).

Tests: `cd backend && pip install -r requirements.txt && python -m pytest`.
API docs: http://localhost:8000/docs (OpenAPI). Auth is an `X-API-Key` header; send an `Idempotency-Key` header on `POST /api/v1/payments` to make retries safe.

## How it works

- **Money** is integer satoshis end to end. RPC responses are parsed as `Decimal`, never `float`.
- **State machine** (`backend/app/state.py`): explicit transition table plus a pure `derive()` that maps chain facts (received sats, confirmations, expiry) to a status. Mempool-only funds are `SEEN_ON_NETWORK`, never confirmed. Confirmations are re-read from the node every cycle, so reorg regressions are corrected until a payment reaches `SETTLED`, which is final.
- **Reconciliation** (`service.reconcile`) runs every `RECONCILE_INTERVAL` seconds and recomputes each open payment from `listreceivedbyaddress`. State never depends on a notification being delivered.
- **Addresses**: one fresh bech32 address per payment from a Bitcoin Core descriptor wallet (`getnewaddress`), unique in the database. Private keys stay in Bitcoin Core; the browser never sees them.
- **Audit**: every status change is written to `payment_events` with the chain facts that caused it.

Trust boundaries: the browser only talks to the API; only the API talks to PostgreSQL and Bitcoin Core; Bitcoin Core RPC is not published outside the Compose network. Customers can read only the public checkout view of a payment (unguessable ID, no txid, no merchant data). Merchants cannot see each other's payments, and node/wallet status is operator-only.

## Production checklist

- Terminate TLS in front of the API (nginx or similar; not included) and keep port 8000 bound to localhost.
- Back up the Bitcoin Core wallet; losing it loses the funds.
- Run your own node on the target network. The Compose file is regtest-only and its `bitcoind` image is a convenience: pin and verify an image you trust.
- Set `SETTLEMENT_CONFIRMATIONS` to your reorg-risk tolerance (6 is the usual mainnet floor).
- The dashboard keeps the API key in `sessionStorage` for the tab's lifetime. Replace with real user sessions before giving the dashboard to more than one trusted operator.

## Not built yet

Fiat/exchange rates, invoices/payment links/PDF, customers and products, webhooks, ZMQ block notifications, Redis, Alembic migrations (tables are created at startup), user accounts and roles beyond the operator flag, rate limiting, API key rotation, REPLACED/INVALID states, reports/CSV, Settlements, Security and Settings pages, circuit breaker, regtest integration tests. Wallet spending is deliberately absent; this build only receives.
