# Aureom Forum

A community platform for considered, long-form discussion. HTML-first frontend (vanilla JS ES modules and a Web Component shell), FastAPI + PostgreSQL backend.

**Status: Phase 1 of 6 (Foundation) is built and runnable.** Accounts, sessions, the design system and the application shell are real. Communities, discussions, messaging, moderation and the rest are not built yet, and the interface does not pretend otherwise: unavailable navigation items are listed as "Soon" and are not links, and the home feed says plainly that nothing has been posted.

## Run it

Local development (needs Python 3.12+ and a PostgreSQL database):

```bash
cp .env.example .env            # set DATABASE_URL to your database
pip install -r backend/requirements-dev.txt
./scripts/dev.sh                # migrates, then serves everything on http://localhost:8000
```

Docker (PostgreSQL, Redis, migrations, API, Nginx on http://localhost:8080):

```bash
cp .env.example .env            # set POSTGRES_PASSWORD
docker compose up --build
```

First-run workflow, all persisted in PostgreSQL:

1. Open the site and choose **Create account**.
2. Open `/dev/outbox` (development only) and follow the confirmation link. Email is written to `var/outbox` rather than sent while `EMAIL_BACKEND=file`.
3. Sign in. Account settings show your sessions and let you change your password.
4. Make yourself a moderator or administrator (there is no admin UI until Phase 4):
   `cd backend && python -m app.cli promote <username> platform_administrator`

API reference: `/api/v1/docs` (OpenAPI).

## What Phase 1 contains

| Area | Built |
| --- | --- |
| Accounts | Register, email confirmation (and resend), sign in by username or email, sign out, forgot/reset password, change password |
| Sessions | Server-side, HttpOnly cookie, hash-only storage, absolute and idle expiry, list and revoke devices, revoke on password change/reset |
| Protection | Argon2id, per-session CSRF token, rate limits (login, register, reset), JSON-only writes, security headers and CSP, identical responses that avoid revealing which emails have accounts |
| Roles | Platform roles stored and rankable (`member`, `trusted_member`, `platform_moderator`, `platform_administrator`), enforced by `require_role`, assigned via CLI |
| Audit | Append-only `audit_logs` rows for every authentication event |
| Frontend | `index.html` shell, router, 12-item navigation, design system, home, auth pages, settings, dev mailbox |
| Platform | Alembic migration `0001`, Dockerfile, Compose stack, Nginx config |

Not built yet: communities and categories, discussions and replies, editor, reactions, bookmarks, profiles, following, messaging, notifications, search, moderation and appeals, administration, events, media, WebSockets, analytics. See the phase plan in the brief; each is additive to this foundation.

## Verification, honestly

Run in the build environment:

- 33 backend tests pass on SQLite and on PostgreSQL 16 (`./scripts/test.sh`, or set `DATABASE_URL`).
- `alembic upgrade head`, `downgrade base`, `upgrade head` round-trip on PostgreSQL 16.
- 11 frontend interaction checks (`frontend/tests`, jsdom driving the real modules against a live server) pass: register, confirm, sign in, settings, sign out, route guards, safe redirects, and that markup in a display name stays text.

Not verified: the Docker image and Compose stack and the Nginx configuration have not been run (no Docker in the build environment); the Redis rate limiter and SMTP delivery have not been exercised (the in-memory limiter and file mailbox are what the tests use); the interface has not been opened in a real browser, so layout, responsiveness and the CSP have not been checked visually.

## Layout

```
index.html                  entry point
frontend/css, frontend/js   design system, router, API client, shell component, pages
backend/app                 config, database, auth, users, api (deps, errors, v1), services
backend/migrations          Alembic
backend/tests               pytest
infrastructure/nginx        reverse proxy
docs/                       architecture.md, security.md
```

Empty module folders (`communities/`, `threads/`, ...) mark where later phases land. `frontend/css/editor.css` is reserved for Phase 2.

## Configuration

Everything is an environment variable (see `.env.example`). With `ENV=production` the server refuses to start unless cookies are secure, email uses SMTP, hosts are listed and the database is PostgreSQL.
