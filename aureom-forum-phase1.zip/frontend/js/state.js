/** Minimal observable store for what every page needs: who is signed in, and server meta. */
const state = { user: null, meta: {}, ready: false };
const subscribers = new Set();

export const getState = () => state;

export function setState(patch) {
  Object.assign(state, patch);
  subscribers.forEach((fn) => fn(state));
}

export function subscribe(fn) {
  subscribers.add(fn);
  return () => subscribers.delete(fn);
}
