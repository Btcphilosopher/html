import { h, svg } from "../utilities/dom.js";
import { getState, subscribe } from "../state.js";
import { signOut } from "../auth.js";
import { navigate } from "../router.js";
import { formatDate, roleLabel } from "../utilities/format.js";

const MARK = `<svg width="28" height="28" viewBox="0 0 32 32" aria-hidden="true"><path d="M6 26 16 6l10 20" fill="none" stroke="#fbfaf7" stroke-width="2.4"/><path d="M10.5 19.5h11" stroke="#b07a1e" stroke-width="2.4"/></svg>`;

// Destinations that work today link out; the rest are listed, but plainly not available.
const NAV = [
  { label: "Home", href: "/" },
  { label: "Discover" }, { label: "Communities" }, { label: "Discussions" },
  { label: "Following" }, { label: "Bookmarks" }, { label: "Messages" },
  { label: "Notifications" }, { label: "Events" }, { label: "Members" }, { label: "Search" },
  { label: "Settings", href: "/settings", auth: true },
];

class AureomShell extends HTMLElement {
  connectedCallback() {
    if (this.built) return;
    this.built = true;

    this.toggle = h("button", { class: "btn secondary menu-toggle", type: "button", "aria-expanded": "false",
      "aria-controls": "side-nav", onclick: () => this.setNav(!this.nav.classList.contains("is-open")) }, "Menu");
    this.account = h("div", { class: "account-area" });
    this.nav = h("nav", { class: "side-nav", id: "side-nav", "aria-label": "Main" });
    this.main = h("main", { id: "main", class: "main-col" });
    this.aside = h("aside", { class: "side-aside", "aria-label": "Account" });

    this.append(
      h("header", { class: "masthead" },
        this.toggle,
        h("a", { class: "wordmark", href: "/", "aria-label": "Aureom Forum home" }, svg(MARK), "Aureom Forum"),
        h("div", { class: "masthead-spacer" }),
        this.account),
      h("div", { class: "frame" }, this.nav, this.main, this.aside),
    );

    this.unsubscribe = subscribe(() => this.refresh());
    window.addEventListener("aureom:navigated", () => { this.refresh(); this.setNav(false); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") this.setNav(false); });
    this.refresh();
  }

  get outlet() { return this.main; }

  setNav(open) {
    this.nav.classList.toggle("is-open", open);
    this.toggle.setAttribute("aria-expanded", String(open));
  }

  refresh() {
    const { user } = getState();
    this.renderAccount(user);
    this.renderNav(user);
    this.renderAside(user);
  }

  renderAccount(user) {
    if (user) {
      this.account.replaceChildren(
        h("a", { class: "who", href: "/settings" }, user.display_name),
        h("button", { class: "btn secondary", type: "button", onclick: async () => { await signOut(); navigate("/"); } }, "Sign out"),
      );
    } else {
      this.account.replaceChildren(
        h("a", { class: "btn secondary", href: "/login" }, "Sign in"),
        h("a", { class: "btn", href: "/register" }, "Create account"),
      );
    }
  }

  renderNav(user) {
    const here = location.pathname;
    const items = NAV.filter((i) => !i.auth || user).map((i) =>
      h("li", {}, i.href
        ? h("a", { class: "nav-item", href: i.href, "aria-current": here === i.href ? "page" : false }, i.label)
        : h("span", { class: "nav-item is-unavailable", "aria-disabled": "true" },
            i.label, h("span", { class: "soon" }, "Soon"), h("span", { class: "visually-hidden" }, "Not yet available"))));
    this.nav.replaceChildren(h("ul", { class: "nav-list" }, items));
  }

  renderAside(user) {
    if (!user) {
      this.aside.replaceChildren(h("section", { class: "panel" },
        h("h2", {}, "Join Aureom Forum"),
        h("p", {}, "Create an account to take part as discussions open."),
        h("a", { class: "btn", href: "/register" }, "Create account")));
      return;
    }
    this.aside.replaceChildren(h("section", { class: "panel" },
      h("h2", {}, "Your account"),
      h("dl", {},
        h("dt", {}, "Signed in as"), h("dd", {}, `@${user.username}`),
        h("dt", {}, "Role"), h("dd", {}, roleLabel(user.role)),
        h("dt", {}, "Email"), h("dd", {}, user.email_verified ? "Confirmed" : "Not confirmed"),
        h("dt", {}, "Member since"), h("dd", {}, formatDate(user.created_at))),
      h("p", {}, h("a", { href: "/settings" }, "Account settings"))));
  }
}

customElements.define("aureom-shell", AureomShell);
