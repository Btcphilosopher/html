import { h } from "../utilities/dom.js";

/** A labelled input with hint and inline error. */
export function field({ label, name, type = "text", autocomplete, hint, required = true, minlength, value }) {
  const id = `f-${name}`;
  const hintEl = hint ? h("div", { class: "hint", id: `${id}-hint` }, hint) : null;
  const errorEl = h("div", { class: "error", id: `${id}-error`, role: "alert" });
  const input = h("input", {
    id, name, type, autocomplete, required, minlength, value,
    "aria-describedby": [hint ? `${id}-hint` : null, `${id}-error`].filter(Boolean).join(" "),
  });
  const el = h("div", { class: "field" }, h("label", { for: id }, label), input, hintEl, errorEl);
  return {
    el, input, name,
    setError(message) {
      errorEl.textContent = message ?? "";
      if (message) input.setAttribute("aria-invalid", "true");
      else input.removeAttribute("aria-invalid");
    },
  };
}

export function notice(kind, ...content) {
  const cls = { error: "notice is-error", ok: "notice is-ok" }[kind] ?? "notice";
  return h("div", { class: cls, role: kind === "error" ? "alert" : "status" }, ...content);
}

/** Maps an ApiError onto fields. Returns the message to show above the form
 *  when nothing field-specific explains the failure. */
export function applyErrors(fields, err) {
  fields.forEach((f) => f.setError(""));
  let placed = false;
  for (const d of err.details ?? []) {
    const f = fields.find((x) => x.name === d.field);
    if (f) { f.setError(d.message); placed = true; }
  }
  if (err.code === "rate_limited" && err.retryAfter) {
    return `${err.message} Try again in about ${Math.ceil(Number(err.retryAfter) / 60)} minute(s).`;
  }
  return placed ? null : err.message;
}

/** Disables a button while an async action runs. */
export async function busy(button, action) {
  button.setAttribute("disabled", "");
  try { return await action(); } finally { button.removeAttribute("disabled"); }
}
