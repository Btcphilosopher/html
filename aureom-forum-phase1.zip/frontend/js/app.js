import "./components/app-shell.js";
import { bootstrap } from "./auth.js";
import { configure, render } from "./router.js";
import { h } from "./utilities/dom.js";

const shell = document.querySelector("aureom-shell");

try {
  await bootstrap();
} catch {
  shell.outlet.replaceChildren(h("div", { class: "notice is-error", role: "alert" },
    h("p", {}, "Aureom Forum cannot reach its server right now. Reload in a moment.")));
  throw new Error("bootstrap failed");
}

configure(shell.outlet);
await render();
