import { getState } from "./state.js";

const ROUTES = [
  { path: "/", page: "home", title: "Home" },
  { path: "/login", page: "login", title: "Sign in", guestOnly: true },
  { path: "/register", page: "register", title: "Create account", guestOnly: true },
  { path: "/verify-email", page: "verify-email", title: "Confirm email" },
  { path: "/forgot-password", page: "forgot-password", title: "Reset password", guestOnly: true },
  { path: "/reset-password", page: "reset-password", title: "Choose a new password" },
  { path: "/settings", page: "settings", title: "Settings", auth: true },
  { path: "/dev/outbox", page: "dev-outbox", title: "Development mailbox" },
];
const NOT_FOUND = { page: "not-found", title: "Page not found" };

let outlet = null;
let sequence = 0;

/** Only same-site paths may be used as a post-login destination. */
export function safeNext(next) {
  return typeof next === "string" && next.startsWith("/") && !next.startsWith("//") && !next.includes("\\")
    ? next : "/";
}

export function configure(el) {
  outlet = el;
  window.addEventListener("popstate", render);
  document.addEventListener("click", (event) => {
    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const a = event.target.closest?.("a[href]");
    if (!a || a.target || a.hasAttribute("download")) return;
    const href = a.getAttribute("href");
    if (!href.startsWith("/") || href.startsWith("//") || href.startsWith("/api/") || href.startsWith("/frontend/")) return;
    event.preventDefault();
    navigate(href);
  });
}

export function navigate(to, { replace = false } = {}) {
  history[replace ? "replaceState" : "pushState"]({}, "", to);
  return render();
}

export async function render() {
  const mine = ++sequence;
  const url = new URL(location.href);
  const route = ROUTES.find((r) => r.path === url.pathname) ?? NOT_FOUND;
  const { user } = getState();

  if (route.auth && !user) {
    return navigate(`/login?next=${encodeURIComponent(url.pathname + url.search)}`, { replace: true });
  }
  if (route.guestOnly && user) return navigate("/", { replace: true });

  let node;
  try {
    const page = await import(`./pages/${route.page}.js`);
    node = await page.default({ query: url.searchParams, navigate, user });
  } catch (err) {
    console.error(err);
    const { h } = await import("./utilities/dom.js");
    node = h("div", { class: "notice is-error" }, h("p", {}, "This page could not be loaded. Reload and try again."));
  }
  if (mine !== sequence) return; // a newer navigation superseded this one

  outlet.replaceChildren(node);
  document.title = `${route.title} · Aureom Forum`;
  const heading = outlet.querySelector("h1");
  if (heading) {
    heading.setAttribute("tabindex", "-1");
    heading.focus({ preventScroll: true });
  }
  window.scrollTo(0, 0);
  window.dispatchEvent(new CustomEvent("aureom:navigated"));
}
