import { h } from "../utilities/dom.js";
import { register } from "../auth.js";
import { getState } from "../state.js";
import { applyErrors, busy, field, notice } from "../components/form.js";

export default async function registerPage() {
  const { meta } = getState();
  if (!meta.registration_open) {
    return h("div", {}, h("header", { class: "page-head" }, h("h1", {}, "Registration is closed")),
      h("p", {}, "New accounts cannot be created right now."));
  }
  const username = field({ label: "Username", name: "username", autocomplete: "username", hint: "3 to 32 letters, numbers or underscores." });
  const displayName = field({ label: "Display name (optional)", name: "display_name", autocomplete: "name", required: false });
  const email = field({ label: "Email", name: "email", type: "email", autocomplete: "email" });
  const password = field({ label: "Password", name: "password", type: "password", autocomplete: "new-password",
    hint: `At least ${meta.password_min_length} characters. A short phrase of unrelated words works well.` });
  const slot = h("div", { "aria-live": "polite" });
  const submit = h("button", { class: "btn", type: "submit" }, "Create account");
  const fields = [username, displayName, email, password];

  const wrapper = h("div", {});
  const form = h("form", { class: "form", novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    slot.replaceChildren();
    await busy(submit, async () => {
      try {
        await register({
          username: username.input.value, email: email.input.value, password: password.input.value,
          display_name: displayName.input.value || null,
        });
        wrapper.replaceChildren(
          h("header", { class: "page-head" }, h("h1", {}, "Check your email")),
          notice("ok", h("p", {}, `We sent a confirmation link to ${email.input.value.trim()}. Open it to activate your account, then sign in.`)),
          meta.dev_outbox
            ? h("p", { class: "meta" }, "Development mode: read the message in the ", h("a", { href: "/dev/outbox" }, "development mailbox"), ".")
            : null);
      } catch (err) {
        const message = applyErrors(fields, err);
        if (message) slot.replaceChildren(notice("error", h("p", {}, message)));
      }
    });
  } }, slot, ...fields.map((f) => f.el), h("div", { class: "form-actions" }, submit));

  wrapper.append(
    h("header", { class: "page-head" }, h("h1", {}, "Create your account")),
    form,
    h("p", { class: "meta" }, "Already registered? ", h("a", { href: "/login" }, "Sign in"), "."));
  return wrapper;
}
