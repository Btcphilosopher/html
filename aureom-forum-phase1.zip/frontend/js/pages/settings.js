import { h } from "../utilities/dom.js";
import { api } from "../api.js";
import { getState } from "../state.js";
import { applyErrors, busy, field, notice } from "../components/form.js";
import { formatDate, roleLabel, timeAgo } from "../utilities/format.js";

export default async function settings() {
  const { user, meta } = getState();
  const head = h("header", { class: "page-head" }, h("h1", {}, "Settings"));

  const account = h("section", { class: "section", "aria-labelledby": "acct-h" },
    h("h2", { id: "acct-h" }, "Account"),
    h("div", { class: "panel" }, h("dl", {},
      h("dt", {}, "Username"), h("dd", {}, `@${user.username}`),
      h("dt", {}, "Display name"), h("dd", {}, user.display_name),
      h("dt", {}, "Email"), h("dd", {}, user.email),
      h("dt", {}, "Role"), h("dd", {}, roleLabel(user.role)),
      h("dt", {}, "Member since"), h("dd", {}, formatDate(user.created_at)))));

  // Change password
  const current = field({ label: "Current password", name: "current_password", type: "password", autocomplete: "current-password" });
  const next = field({ label: "New password", name: "new_password", type: "password", autocomplete: "new-password",
    hint: `At least ${meta.password_min_length} characters. Other devices are signed out when you change it.` });
  const pwSlot = h("div", { "aria-live": "polite" });
  const pwSubmit = h("button", { class: "btn", type: "submit" }, "Change password");
  const passwordForm = h("form", { class: "form", novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    pwSlot.replaceChildren();
    await busy(pwSubmit, async () => {
      try {
        const res = await api.post("/auth/password/change", { current_password: current.input.value, new_password: next.input.value });
        current.input.value = next.input.value = "";
        pwSlot.replaceChildren(notice("ok", h("p", {}, res.message)));
        await loadSessions();
      } catch (err) {
        const message = applyErrors([current, next], err);
        if (message) pwSlot.replaceChildren(notice("error", h("p", {}, message)));
      }
    });
  } }, pwSlot, current.el, next.el, h("div", { class: "form-actions" }, pwSubmit));
  const security = h("section", { class: "section", "aria-labelledby": "pw-h" }, h("h2", { id: "pw-h" }, "Password"), passwordForm);

  // Devices
  const list = h("ul", { class: "list" });
  const devSlot = h("div", { "aria-live": "polite" });
  const others = h("button", { class: "btn secondary", type: "button", onclick: async (e) => {
    await busy(e.target, async () => {
      const { revoked } = await api.post("/auth/sessions/revoke-others");
      devSlot.replaceChildren(notice("ok", h("p", {}, revoked ? `Signed out ${revoked} other device(s).` : "No other devices were signed in.")));
      await loadSessions();
    });
  } }, "Sign out other devices");

  async function loadSessions() {
    const sessions = await api.get("/auth/sessions");
    list.replaceChildren(...sessions.map((s) => h("li", {},
      h("div", { class: "row" },
        h("strong", {}, s.current ? "This device" : "Another device"),
        s.current ? h("span", { class: "tag-current" }, "Current session")
          : h("button", { class: "btn quiet", type: "button", onclick: async (e) => {
              await busy(e.target, () => api.del(`/auth/sessions/${s.id}`));
              await loadSessions();
            } }, "Sign out")),
      h("div", { class: "meta" }, `Active ${timeAgo(s.last_seen_at)} · signed in ${timeAgo(s.created_at)}${s.ip ? ` · ${s.ip}` : ""}`),
      s.user_agent ? h("div", { class: "meta" }, s.user_agent) : null)));
    others.toggleAttribute("hidden", sessions.length < 2);
  }
  await loadSessions();
  const devices = h("section", { class: "section", "aria-labelledby": "dev-h" },
    h("h2", { id: "dev-h" }, "Signed-in devices"), devSlot, list, h("p", {}, others));

  return h("div", {}, head, account, security, devices);
}
