import { h } from "../utilities/dom.js";
import { api } from "../api.js";
import { getState } from "../state.js";
import { applyErrors, busy, field, notice } from "../components/form.js";

export default async function resetPassword({ query }) {
  const token = query.get("token");
  const head = h("header", { class: "page-head" }, h("h1", {}, "Choose a new password"));
  if (!token) return h("div", {}, head, notice("error", h("p", {}, "This link is incomplete. Request a new one."),
    h("p", {}, h("a", { href: "/forgot-password" }, "Request a reset link"))));

  const min = getState().meta.password_min_length;
  const password = field({ label: "New password", name: "new_password", type: "password", autocomplete: "new-password",
    hint: `At least ${min} characters.` });
  const slot = h("div", { "aria-live": "polite" });
  const submit = h("button", { class: "btn", type: "submit" }, "Save password");
  const wrapper = h("div", {}, head);
  wrapper.append(h("form", { class: "form", novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    slot.replaceChildren();
    await busy(submit, async () => {
      try {
        const res = await api.post("/auth/password/reset", { token, new_password: password.input.value });
        wrapper.replaceChildren(head, notice("ok", h("p", {}, res.message)), h("p", {}, h("a", { class: "btn", href: "/login" }, "Sign in")));
      } catch (err) {
        const message = applyErrors([password], err);
        if (message) slot.replaceChildren(notice("error", h("p", {}, message)));
      }
    });
  } }, slot, password.el, h("div", { class: "form-actions" }, submit)));
  return wrapper;
}
