import { h } from "../utilities/dom.js";

export default async function home({ user }) {
  const intro = "Aureom Forum is a community for considered, long-form discussion.";
  return h("div", {},
    h("header", { class: "page-head" },
      h("h1", {}, user ? `Welcome back, ${user.display_name}.` : "Welcome to Aureom Forum."),
      h("p", {}, intro)),
    user ? null : h("p", {},
      h("a", { class: "btn", href: "/register" }, "Create account"), " ",
      h("a", { class: "btn secondary", href: "/login" }, "Sign in")),
    h("section", { class: "section", "aria-labelledby": "feed-h" },
      h("h2", { id: "feed-h" }, "Latest discussions"),
      h("div", { class: "empty" },
        h("h3", {}, "Nothing has been posted yet"),
        h("p", {}, "Discussions will appear here once members can start them."))));
}
