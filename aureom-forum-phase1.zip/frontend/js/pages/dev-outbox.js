import { h } from "../utilities/dom.js";
import { api } from "../api.js";
import { getState } from "../state.js";
import { notice } from "../components/form.js";

const IN_APP = new Set(["/verify-email", "/reset-password", "/forgot-password"]);

/** Turns known in-app links in an email body into same-origin links; everything else stays text. */
function linkify(text) {
  return text.split(/(https?:\/\/[^\s]+)/g).map((part) => {
    if (!/^https?:\/\//.test(part)) return part;
    try {
      const u = new URL(part);
      if (IN_APP.has(u.pathname)) return h("a", { href: u.pathname + u.search }, part);
    } catch { /* not a URL */ }
    return part;
  });
}

export default async function devOutbox() {
  const head = h("header", { class: "page-head" }, h("h1", {}, "Development mailbox"),
    h("p", {}, "Emails the platform would have sent. Only available in development."));
  if (!getState().meta.dev_outbox) return h("div", {}, head, notice("error", h("p", {}, "The development mailbox is switched off on this server.")));
  const mails = await api.get("/dev/outbox");
  if (!mails.length) return h("div", {}, head, h("div", { class: "empty" }, h("h3", {}, "No messages yet")));
  return h("div", {}, head, ...mails.map((m) => h("article", { class: "mail" },
    h("h2", {}, m.subject), h("div", { class: "meta" }, `To ${m.to}`), h("pre", {}, ...linkify(m.body)))));
}
