import { h } from "../utilities/dom.js";
import { api } from "../api.js";
import { signIn } from "../auth.js";
import { safeNext } from "../router.js";
import { applyErrors, busy, field, notice } from "../components/form.js";

export default async function login({ query, navigate }) {
  const identifier = field({ label: "Username or email", name: "identifier", autocomplete: "username" });
  const password = field({ label: "Password", name: "password", type: "password", autocomplete: "current-password" });
  const slot = h("div", { "aria-live": "polite" });
  const submit = h("button", { class: "btn", type: "submit" }, "Sign in");

  const resend = (email) => h("div", {},
    h("p", {}, "Confirm your email address before signing in. We can send a new link."),
    h("button", { class: "btn secondary", type: "button", onclick: async (e) => {
      await busy(e.target, () => api.post("/auth/resend-verification", { email }));
      slot.replaceChildren(notice("ok", h("p", {}, "If that account needs confirming, a new link is on its way.")));
    } }, "Send a new link"));

  const form = h("form", { class: "form", novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    slot.replaceChildren();
    await busy(submit, async () => {
      try {
        await signIn(identifier.input.value, password.input.value);
        await navigate(safeNext(query.get("next")), { replace: true });
      } catch (err) {
        if (err.code === "email_not_verified" && identifier.input.value.includes("@")) {
          slot.replaceChildren(notice("error", resend(identifier.input.value.trim())));
          return;
        }
        const message = applyErrors([identifier, password], err);
        if (message) slot.replaceChildren(notice("error", h("p", {}, message)));
      }
    });
  } }, slot, identifier.el, password.el,
    h("div", { class: "form-actions" }, submit, h("a", { href: "/forgot-password" }, "Forgot your password?")));

  return h("div", {},
    h("header", { class: "page-head" }, h("h1", {}, "Sign in")),
    form,
    h("p", { class: "meta" }, "New here? ", h("a", { href: "/register" }, "Create an account"), "."));
}
