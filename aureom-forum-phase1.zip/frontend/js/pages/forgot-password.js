import { h } from "../utilities/dom.js";
import { api } from "../api.js";
import { getState } from "../state.js";
import { applyErrors, busy, field, notice } from "../components/form.js";

export default async function forgotPassword() {
  const email = field({ label: "Email", name: "email", type: "email", autocomplete: "email" });
  const slot = h("div", { "aria-live": "polite" });
  const submit = h("button", { class: "btn", type: "submit" }, "Send reset link");
  const form = h("form", { class: "form", novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    slot.replaceChildren();
    await busy(submit, async () => {
      try {
        await api.post("/auth/password/forgot", { email: email.input.value });
        slot.replaceChildren(notice("ok", h("p", {}, "If an account uses that address, a reset link is on its way. It expires in an hour."),
          getState().meta.dev_outbox ? h("p", {}, "Development mode: see the ", h("a", { href: "/dev/outbox" }, "development mailbox"), ".") : null));
      } catch (err) {
        const message = applyErrors([email], err);
        if (message) slot.replaceChildren(notice("error", h("p", {}, message)));
      }
    });
  } }, slot, email.el, h("div", { class: "form-actions" }, submit, h("a", { href: "/login" }, "Back to sign in")));
  return h("div", {}, h("header", { class: "page-head" }, h("h1", {}, "Reset your password")), form);
}
