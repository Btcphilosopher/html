import { h } from "../utilities/dom.js";
import { api } from "../api.js";
import { notice } from "../components/form.js";

export default async function verifyEmail({ query }) {
  const token = query.get("token");
  const head = h("header", { class: "page-head" }, h("h1", {}, "Confirm your email"));
  if (!token) return h("div", {}, head, notice("error", h("p", {}, "This link is incomplete. Open the link from your email again.")));
  try {
    const res = await api.post("/auth/verify-email", { token });
    return h("div", {}, head, notice("ok", h("p", {}, res.message)), h("p", {}, h("a", { class: "btn", href: "/login" }, "Sign in")));
  } catch (err) {
    return h("div", {}, head, notice("error", h("p", {}, err.message)),
      h("p", {}, "Links expire and can be used once. Sign in to request a new one."));
  }
}
