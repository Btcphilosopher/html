import { h } from "../utilities/dom.js";

export default async function notFound() {
  return h("div", {}, h("header", { class: "page-head" }, h("h1", {}, "Page not found"),
    h("p", {}, "That address does not lead anywhere on Aureom Forum.")),
    h("p", {}, h("a", { class: "btn", href: "/" }, "Go to home")));
}
