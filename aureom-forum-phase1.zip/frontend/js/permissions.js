/** Mirrors backend/app/users/permissions.py. Used ONLY to decide which controls to
 *  show; the server re-checks every action and is the sole authority. */
const RANK = { member: 10, trusted_member: 20, platform_moderator: 70, platform_administrator: 90 };

export function hasRole(user, minimum) {
  return Boolean(user) && (RANK[user.role] ?? 0) >= RANK[minimum];
}
