import { api } from "./api.js";
import { setState } from "./state.js";

export async function bootstrap() {
  const [meta, session] = await Promise.all([api.get("/meta"), api.get("/auth/session")]);
  setState({ meta, user: session.user, ready: true });
}

export async function signIn(identifier, password) {
  const user = await api.post("/auth/login", { identifier, password });
  setState({ user });
  return user;
}

export async function signOut() {
  try {
    await api.post("/auth/logout");
  } finally {
    setState({ user: null }); // the server session is revoked or already gone
  }
}

export const register = (payload) => api.post("/auth/register", payload);
