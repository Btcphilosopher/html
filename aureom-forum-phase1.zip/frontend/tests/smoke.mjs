// Drives the real frontend modules (in jsdom) against a running backend.
// Usage: BASE_URL=http://localhost:8123 node smoke.mjs
import { JSDOM } from "jsdom";
import assert from "node:assert/strict";
import path from "node:path";
import { pathToFileURL } from "node:url";

const BASE = process.env.BASE_URL ?? "http://localhost:8123";
const JS = path.resolve(import.meta.dirname, "../js");
const dom = new JSDOM('<!doctype html><body></body>', { url: BASE + "/", pretendToBeVisual: true });
const { window } = dom;
for (const k of ["window", "document", "HTMLElement", "Node", "CustomEvent", "Event", "customElements", "history", "location"]) {
  Object.defineProperty(globalThis, k, { value: k === "window" ? window : window[k], configurable: true, writable: true });
}
window.scrollTo = () => {};

// fetch with a cookie jar; the non-HttpOnly CSRF cookie is mirrored into document.cookie like a browser would.
const jar = new Map();
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, opts = {}) => {
  const headers = { ...(opts.headers ?? {}), Cookie: [...jar].map(([k, v]) => `${k}=${v}`).join("; ") };
  const res = await realFetch(BASE + url, { ...opts, headers });
  for (const line of res.headers.getSetCookie()) {
    const [pair, ...attrs] = line.split("; ");
    const [name, value] = [pair.slice(0, pair.indexOf("=")), pair.slice(pair.indexOf("=") + 1)];
    const gone = attrs.some((a) => a.toLowerCase() === "max-age=0") || value === "";
    gone ? jar.delete(name) : jar.set(name, value);
    if (!attrs.includes("HttpOnly")) document.cookie = gone ? `${name}=; Max-Age=0; path=/` : `${name}=${value}; path=/`;
  }
  return res;
};

const mod = (p) => import(pathToFileURL(path.join(JS, p)).href);
await mod("components/app-shell.js");
const { bootstrap } = await mod("auth.js");
const { configure, navigate, safeNext } = await mod("router.js");

const shell = document.createElement("aureom-shell");
document.body.append(shell);
await bootstrap();
configure(shell.outlet);

const waitFor = async (fn, what, ms = 4000) => {
  const t0 = Date.now();
  for (;;) {
    try { const v = fn(); if (v) return v; } catch {}
    if (Date.now() - t0 > ms) throw new Error("timed out waiting for " + what);
    await new Promise((r) => setTimeout(r, 25));
  }
};
const h1 = () => shell.outlet.querySelector("h1")?.textContent;
const type = (name, value) => { shell.outlet.querySelector(`input[name="${name}"]`).value = value; };
const submit = () => shell.outlet.querySelector("form").dispatchEvent(new window.Event("submit", { cancelable: true, bubbles: true }));
const results = [];
const step = async (name, fn) => { await fn(); results.push(name); console.log("ok  -", name); };

const PW = "correct horse battery staple";
const NAME = '<img src=x onerror=alert(1)> Alice';

await step("guest home shows welcome, sign-in controls and no Settings link", async () => {
  await navigate("/");
  assert.equal(h1(), "Welcome to Aureom Forum.");
  assert.ok(shell.querySelector('a[href="/login"]'));
  assert.equal(shell.querySelector('a[href="/settings"]'), null);
  const soon = [...shell.querySelectorAll(".is-unavailable")].map((e) => e.getAttribute("aria-disabled"));
  assert.ok(soon.length >= 8 && soon.every((v) => v === "true"));
});

await step("unauthenticated /settings redirects to login with a next parameter", async () => {
  await navigate("/settings");
  assert.equal(location.pathname, "/login");
  assert.equal(new URL(location.href).searchParams.get("next"), "/settings");
});

await step("registration rejects a weak password with an inline error", async () => {
  await navigate("/register");
  type("username", "alice"); type("email", "alice@example.com"); type("password", "short");
  submit();
  await waitFor(() => shell.outlet.querySelector("#f-password-error")?.textContent, "password error");
  assert.equal(shell.outlet.querySelector("#f-password").getAttribute("aria-invalid"), "true");
});

await step("registration succeeds and tells the person to check email", async () => {
  type("password", PW); type("display_name", NAME);
  submit();
  await waitFor(() => h1() === "Check your email", "check-email page");
});

await step("sign-in is refused before the email is confirmed", async () => {
  await navigate("/login");
  type("identifier", "alice@example.com"); type("password", PW);
  submit();
  await waitFor(() => /Confirm your email/.test(shell.outlet.textContent) && shell.outlet.querySelector("button[type=button]"), "unverified notice");
});

await step("confirmation link from the dev mailbox verifies the account", async () => {
  await navigate("/dev/outbox");
  const link = await waitFor(() => shell.outlet.querySelector('pre a[href^="/verify-email"]'), "verify link");
  await navigate(link.getAttribute("href"));
  await waitFor(() => /Email confirmed/.test(shell.outlet.textContent), "verified message");
});

await step("sign-in works and lands on a personalised home; markup in names stays text", async () => {
  await navigate("/login");
  type("identifier", "alice"); type("password", PW);
  submit();
  await waitFor(() => location.pathname === "/" && /Welcome back/.test(h1() ?? ""), "signed-in home");
  assert.equal(h1(), `Welcome back, ${NAME}.`);
  assert.equal(document.querySelector("img"), null, "no element may be created from user text");
  assert.ok(shell.querySelector('a[href="/settings"]'));
  assert.match(shell.aside.textContent, /Your account/);
});

await step("settings lists the current session and rejects a wrong current password", async () => {
  await navigate("/settings");
  await waitFor(() => /This device/.test(shell.outlet.textContent), "session list");
  const form = shell.outlet.querySelectorAll("form")[0];
  form.querySelector('input[name="current_password"]').value = "not my password";
  form.querySelector('input[name="new_password"]').value = "a brand new passphrase!";
  form.dispatchEvent(new window.Event("submit", { cancelable: true, bubbles: true }));
  await waitFor(() => shell.outlet.querySelector("#f-current_password-error")?.textContent, "wrong password error");
});

await step("sign out returns to guest state and protected pages redirect again", async () => {
  [...shell.querySelectorAll("button")].find((b) => b.textContent === "Sign out").click();
  await waitFor(() => shell.querySelector('a[href="/login"]'), "guest controls");
  await navigate("/settings");
  assert.equal(location.pathname, "/login");
});

await step("post-login redirects only to same-site paths", async () => {
  assert.equal(safeNext("//evil.example"), "/");
  assert.equal(safeNext("https://evil.example"), "/");
  assert.equal(safeNext("/\\evil"), "/");
  assert.equal(safeNext("/settings"), "/settings");
});

await step("unknown routes render the not-found page", async () => {
  await navigate("/no-such-page");
  assert.equal(h1(), "Page not found");
});

console.log(`\n${results.length} frontend interaction checks passed`);
process.exit(0);
