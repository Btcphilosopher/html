from app.users.models import PlatformRole as R
from app.users.permissions import role_at_least


def test_role_ordering():
    assert role_at_least(R.PLATFORM_ADMINISTRATOR, R.PLATFORM_MODERATOR)
    assert role_at_least(R.TRUSTED_MEMBER, R.MEMBER)
    assert not role_at_least(R.MEMBER, R.PLATFORM_MODERATOR)


def test_cli_promote_changes_role_and_is_audited(db):
    from sqlalchemy import select
    from app import cli
    from app.administration.models import AuditLog
    from app.users.models import User
    from tests.conftest import new_client, register, verify

    c = new_client()
    register(c)
    verify(c)
    assert cli.promote("ALICE", "platform_moderator") == 0
    db.expire_all()
    assert db.scalar(select(User)).role == R.PLATFORM_MODERATOR
    assert db.scalar(select(AuditLog).where(AuditLog.action == "admin.role_changed"))
    assert cli.promote("alice", "overlord") == 2
    assert cli.promote("nobody", "member") == 1
