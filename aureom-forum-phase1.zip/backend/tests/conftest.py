import os
import re
import tempfile

# Settings are read at import time, so configure the environment first.
_outbox = tempfile.mkdtemp(prefix="aureom-outbox-")
os.environ.setdefault("DATABASE_URL", "sqlite+pysqlite://")  # in-memory unless overridden
os.environ["ENV"] = "test"
os.environ["OUTBOX_DIR"] = _outbox
os.environ["EMAIL_BACKEND"] = "file"
os.environ["SERVE_FRONTEND"] = "true"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

import app.models  # noqa: E402,F401
from app.database import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.services.email import clear_outbox, read_outbox  # noqa: E402
from app.services.ratelimit import limiter  # noqa: E402

GOOD_PW = "correct horse battery staple"


@pytest.fixture(scope="session", autouse=True)
def _schema():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    yield
    Base.metadata.drop_all(engine)


@pytest.fixture(autouse=True)
def _clean():
    with engine.begin() as conn:
        for table in reversed(Base.metadata.sorted_tables):
            conn.execute(table.delete())
    clear_outbox()
    limiter.reset()
    yield


@pytest.fixture
def db():
    with SessionLocal() as session:
        yield session


def new_client() -> TestClient:
    return TestClient(app, base_url="http://localhost")


@pytest.fixture
def client():
    return new_client()


def last_token(kind: str) -> str:
    for mail in read_outbox():
        m = re.search(rf"/{kind}\?token=([A-Za-z0-9_-]+)", mail["body"])
        if m:
            return m.group(1)
    raise AssertionError(f"no {kind} email in outbox")


def register(client, username="alice", email="alice@example.com", password=GOOD_PW, **extra):
    return client.post("/api/v1/auth/register",
                       json={"username": username, "email": email, "password": password, **extra})


def verify(client):
    r = client.post("/api/v1/auth/verify-email", json={"token": last_token("verify-email")})
    assert r.status_code == 200, r.text


def login(client, identifier="alice", password=GOOD_PW):
    return client.post("/api/v1/auth/login", json={"identifier": identifier, "password": password})


def csrf(client) -> dict:
    return {"X-CSRF-Token": client.cookies.get("aureom_csrf")}


def signed_in(username="alice", email="alice@example.com") -> TestClient:
    c = new_client()
    assert register(c, username, email).status_code == 202
    verify(c)
    assert login(c, username).status_code == 200
    return c
