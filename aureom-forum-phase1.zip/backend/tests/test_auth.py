from datetime import timedelta

from sqlalchemy import func, select

from app.administration.models import AuditLog
from app.auth.models import AuthSession, EmailToken
from app.database import utcnow
from app.services.email import read_outbox
from app.users.models import User
from tests.conftest import (GOOD_PW, csrf, last_token, login, new_client, register,
                            signed_in, verify)


# ---- registration -------------------------------------------------------------

def test_register_creates_unverified_user_and_sends_email(client, db):
    r = register(client)
    assert r.status_code == 202
    user = db.scalar(select(User).where(User.username_key == "alice"))
    assert user and user.email_verified_at is None
    assert user.password_hash.startswith("$argon2id$")
    assert GOOD_PW not in user.password_hash
    assert len(read_outbox()) == 1


def test_unverified_user_cannot_sign_in(client):
    register(client)
    r = login(client)
    assert r.status_code == 403 and r.json()["error"]["code"] == "email_not_verified"


def test_duplicate_username_is_rejected_case_insensitively(client):
    register(client)
    r = register(client, username="ALICE", email="other@example.com")
    assert r.status_code == 409 and r.json()["error"]["code"] == "username_taken"


def test_duplicate_email_looks_identical_and_creates_nothing(client, db):
    first = register(client)
    second = register(client, username="alice2")
    assert second.status_code == first.status_code == 202
    assert second.json() == first.json()
    assert db.scalar(select(func.count()).select_from(User)) == 1
    assert "already have one" in read_outbox()[0]["body"]


def test_weak_passwords_are_rejected(client):
    for pw in ["short", "alice-is-my-name", "a" * 14]:
        r = register(client, password=pw)
        assert r.status_code == 422, pw
        assert r.json()["error"]["details"]


def test_invalid_username_and_reserved_names(client):
    assert register(client, username="a b").status_code == 422
    assert register(client, username="admin").status_code == 422


def test_registration_can_be_closed(client, monkeypatch):
    from app.config import get_settings
    monkeypatch.setattr(get_settings(), "registration_open", False)
    assert register(client).status_code == 403


# ---- email verification -------------------------------------------------------

def test_verification_token_is_single_use_and_hashed(client, db):
    register(client)
    token = last_token("verify-email")
    assert db.scalar(select(EmailToken).where(EmailToken.token_hash == token)) is None
    assert client.post("/api/v1/auth/verify-email", json={"token": token}).status_code == 200
    again = client.post("/api/v1/auth/verify-email", json={"token": token})
    assert again.status_code == 400 and again.json()["error"]["code"] == "invalid_token"


def test_expired_verification_token_fails(client, db):
    register(client)
    for t in db.scalars(select(EmailToken)):
        t.expires_at = utcnow() - timedelta(minutes=1)
    db.commit()
    r = client.post("/api/v1/auth/verify-email", json={"token": last_token("verify-email")})
    assert r.status_code == 400


def test_resend_verification_issues_new_token_and_stays_silent_for_unknown(client):
    register(client)
    old = last_token("verify-email")
    assert client.post("/api/v1/auth/resend-verification",
                       json={"email": "alice@example.com"}).status_code == 202
    assert client.post("/api/v1/auth/resend-verification",
                       json={"email": "nobody@example.com"}).status_code == 202
    assert len(read_outbox()) == 2
    assert client.post("/api/v1/auth/verify-email", json={"token": old}).status_code == 400
    verify(client)


# ---- sign in / sessions -------------------------------------------------------

def test_login_sets_hardened_cookies_and_session_state(client):
    register(client)
    verify(client)
    r = login(client, "alice@example.com")  # email works as well as username
    assert r.status_code == 200 and r.json()["username"] == "alice"
    cookies = r.headers.get_list("set-cookie")
    session_cookie = next(c for c in cookies if c.startswith("aureom_session="))
    assert "HttpOnly" in session_cookie and "SameSite=lax" in session_cookie
    csrf_cookie = next(c for c in cookies if c.startswith("aureom_csrf="))
    assert "HttpOnly" not in csrf_cookie
    state = client.get("/api/v1/auth/session").json()
    assert state["authenticated"] and state["user"]["email"] == "alice@example.com"


def test_guest_session_state_is_not_an_error(client):
    r = client.get("/api/v1/auth/session")
    assert r.status_code == 200 and r.json() == {"authenticated": False, "user": None}


def test_wrong_password_and_unknown_user_look_the_same(client):
    register(client)
    verify(client)
    a = login(client, "alice", "wrong password entirely")
    b = login(client, "ghost", "wrong password entirely")
    assert a.status_code == b.status_code == 401
    assert a.json() == b.json()


def test_login_is_rate_limited_per_identifier(client):
    register(client)
    verify(client)
    for _ in range(5):
        assert login(client, "alice", "nope nope nope nope").status_code == 401
    r = login(client, "alice")  # even the right password is refused now
    assert r.status_code == 429 and "retry-after" in r.headers


def test_session_token_is_stored_hashed(client, db):
    c = signed_in()
    raw = c.cookies.get("aureom_session")
    assert db.scalar(select(AuthSession).where(AuthSession.token_hash == raw)) is None
    assert db.scalar(select(func.count()).select_from(AuthSession)) == 1


def test_logout_requires_csrf_then_revokes_session():
    c = signed_in()
    assert c.post("/api/v1/auth/logout").status_code == 403
    assert c.post("/api/v1/auth/logout", headers={"X-CSRF-Token": "forged"}).status_code == 403
    assert c.get("/api/v1/auth/session").json()["authenticated"]
    assert c.post("/api/v1/auth/logout", headers=csrf(c)).status_code == 204
    assert not c.get("/api/v1/auth/session").json()["authenticated"]


def test_stolen_cookie_is_useless_after_logout():
    c = signed_in()
    stolen = c.cookies.get("aureom_session")
    c.post("/api/v1/auth/logout", headers=csrf(c))
    thief = new_client()
    thief.cookies.set("aureom_session", stolen)
    assert not thief.get("/api/v1/auth/session").json()["authenticated"]


def test_expired_and_idle_sessions_are_rejected(db):
    c = signed_in()
    sess = db.scalar(select(AuthSession))
    sess.expires_at = utcnow() - timedelta(seconds=1)
    db.commit()
    assert not c.get("/api/v1/auth/session").json()["authenticated"]
    sess.expires_at = utcnow() + timedelta(days=1)
    sess.last_seen_at = utcnow() - timedelta(days=30)
    db.commit()
    assert not c.get("/api/v1/auth/session").json()["authenticated"]


def test_suspended_user_loses_access(db):
    c = signed_in()
    user = db.scalar(select(User))
    user.status = "suspended"
    db.commit()
    assert not c.get("/api/v1/auth/session").json()["authenticated"]


def test_list_and_revoke_other_sessions():
    a = signed_in()
    b = new_client()
    assert login(b).status_code == 200
    sessions = a.get("/api/v1/auth/sessions").json()
    assert len(sessions) == 2 and sum(s["current"] for s in sessions) == 1
    other = next(s for s in sessions if not s["current"])
    assert a.delete(f"/api/v1/auth/sessions/{other['id']}", headers=csrf(a)).status_code == 204
    assert not b.get("/api/v1/auth/session").json()["authenticated"]
    assert a.get("/api/v1/auth/session").json()["authenticated"]


def test_cannot_revoke_someone_elses_session():
    a = signed_in("alice", "alice@example.com")
    b = signed_in("bobby", "bobby@example.com")
    victim = b.get("/api/v1/auth/sessions").json()[0]["id"]
    assert a.delete(f"/api/v1/auth/sessions/{victim}", headers=csrf(a)).status_code == 404
    assert b.get("/api/v1/auth/session").json()["authenticated"]


def test_revoke_all_others():
    a = signed_in()
    for _ in range(2):
        assert login(new_client()).status_code == 200
    r = a.post("/api/v1/auth/sessions/revoke-others", headers=csrf(a))
    assert r.json() == {"revoked": 2}


# ---- passwords ----------------------------------------------------------------

def test_change_password_requires_current_and_signs_out_other_devices():
    a = signed_in()
    b = new_client()
    login(b)
    bad = a.post("/api/v1/auth/password/change", headers=csrf(a),
                 json={"current_password": "wrong", "new_password": "a brand new passphrase"})
    assert bad.status_code == 403
    ok = a.post("/api/v1/auth/password/change", headers=csrf(a),
                json={"current_password": GOOD_PW, "new_password": "a brand new passphrase"})
    assert ok.status_code == 200
    assert a.get("/api/v1/auth/session").json()["authenticated"]
    assert not b.get("/api/v1/auth/session").json()["authenticated"]
    assert login(new_client(), "alice", "a brand new passphrase").status_code == 200
    assert login(new_client(), "alice", GOOD_PW).status_code == 401


def test_password_reset_flow_revokes_sessions_and_token_is_single_use(client):
    a = signed_in()
    r = client.post("/api/v1/auth/password/forgot", json={"email": "alice@example.com"})
    assert r.status_code == 202
    token = last_token("reset-password")
    weak = client.post("/api/v1/auth/password/reset", json={"token": token, "new_password": "short"})
    assert weak.status_code == 422
    ok = client.post("/api/v1/auth/password/reset",
                     json={"token": token, "new_password": "totally different words here"})
    assert ok.status_code == 200
    assert not a.get("/api/v1/auth/session").json()["authenticated"]
    reuse = client.post("/api/v1/auth/password/reset",
                        json={"token": token, "new_password": "another different phrase"})
    assert reuse.status_code == 400
    assert login(new_client(), "alice", "totally different words here").status_code == 200


def test_forgot_password_does_not_reveal_accounts(client):
    signed_in()
    known = client.post("/api/v1/auth/password/forgot", json={"email": "alice@example.com"})
    unknown = client.post("/api/v1/auth/password/forgot", json={"email": "ghost@example.com"})
    assert known.status_code == unknown.status_code == 202 and known.json() == unknown.json()


def test_forgot_password_is_rate_limited(client):
    for _ in range(5):
        assert client.post("/api/v1/auth/password/forgot",
                           json={"email": "x@example.com"}).status_code == 202
    assert client.post("/api/v1/auth/password/forgot",
                       json={"email": "x@example.com"}).status_code == 429


# ---- transport and platform ----------------------------------------------------

def test_non_json_bodies_are_refused(client):
    r = client.post("/api/v1/auth/login", content="identifier=a&password=b",
                    headers={"Content-Type": "application/x-www-form-urlencoded"})
    assert r.status_code == 415


def test_security_headers_present(client):
    r = client.get("/api/v1/health")
    assert r.status_code == 200
    assert r.headers["x-content-type-options"] == "nosniff"
    assert "script-src 'self'" in r.headers["content-security-policy"]
    assert r.headers["cache-control"] == "no-store"


def test_meta_and_unknown_api_paths(client):
    meta = client.get("/api/v1/meta").json()
    assert meta["password_min_length"] == 12 and meta["dev_outbox"] is True
    missing = client.get("/api/v1/nope")
    assert missing.status_code == 404 and missing.json()["error"]["code"] == "not_found"


def test_shell_is_served_for_client_side_routes(client):
    for path in ["/", "/login", "/settings"]:
        r = client.get(path)
        assert r.status_code == 200 and "<title>" in r.text


def test_audit_trail_records_security_events(client, db):
    c = signed_in()
    login(new_client(), "alice", "wrong wrong wrong wrong")
    c.post("/api/v1/auth/logout", headers=csrf(c))
    actions = {a for (a,) in db.execute(select(AuditLog.action))}
    assert {"auth.register", "auth.verify_email", "auth.login", "auth.login_failed",
            "auth.logout"} <= actions
