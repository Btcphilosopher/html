import enum
import uuid
from datetime import datetime

from sqlalchemy import Enum, String, Uuid
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base, UTCDateTime, utcnow


class PlatformRole(str, enum.Enum):
    """Platform-wide roles. Community-scoped roles (community moderator and
    administrator) belong to community memberships and arrive in Phase 2."""

    MEMBER = "member"
    TRUSTED_MEMBER = "trusted_member"
    PLATFORM_MODERATOR = "platform_moderator"
    PLATFORM_ADMINISTRATOR = "platform_administrator"


class AccountStatus(str, enum.Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    BANNED = "banned"
    DELETED = "deleted"


def _values(e):
    return [m.value for m in e]


class User(Base):
    __tablename__ = "users"

    id: Mapped[uuid.UUID] = mapped_column(Uuid, primary_key=True, default=uuid.uuid4)
    username: Mapped[str] = mapped_column(String(32))
    username_key: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(80))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[PlatformRole] = mapped_column(
        Enum(PlatformRole, native_enum=False, length=32, values_callable=_values),
        default=PlatformRole.MEMBER,
    )
    status: Mapped[AccountStatus] = mapped_column(
        Enum(AccountStatus, native_enum=False, length=16, values_callable=_values),
        default=AccountStatus.ACTIVE,
    )
    email_verified_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    password_changed_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    last_login_at: Mapped[datetime | None] = mapped_column(UTCDateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)

    @property
    def is_verified(self) -> bool:
        return self.email_verified_at is not None
