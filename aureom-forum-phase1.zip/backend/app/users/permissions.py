"""Platform role ranking. The server is the only authority; the frontend keeps a
mirror in js/permissions.js purely to decide which controls to show."""
from app.users.models import PlatformRole

_RANK = {
    PlatformRole.MEMBER: 10,
    PlatformRole.TRUSTED_MEMBER: 20,
    PlatformRole.PLATFORM_MODERATOR: 70,
    PlatformRole.PLATFORM_ADMINISTRATOR: 90,
}


def role_at_least(role: PlatformRole, minimum: PlatformRole) -> bool:
    return _RANK[role] >= _RANK[minimum]
