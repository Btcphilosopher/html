import uuid
from datetime import datetime

from pydantic import BaseModel

from app.users.models import PlatformRole


class UserOut(BaseModel):
    """The signed-in user's own account view (includes email)."""

    id: uuid.UUID
    username: str
    display_name: str
    email: str
    role: PlatformRole
    email_verified: bool
    created_at: datetime

    @classmethod
    def of(cls, user) -> "UserOut":
        return cls(
            id=user.id, username=user.username, display_name=user.display_name,
            email=user.email, role=user.role, email_verified=user.is_verified,
            created_at=user.created_at,
        )
