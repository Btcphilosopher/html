"""Operator commands. There is no admin UI until Phase 4, so roles are assigned here.

    python -m app.cli promote <username> <role>
"""
from __future__ import annotations

import argparse
import sys

from sqlalchemy import select

from app.database import SessionLocal
from app.services import audit
from app.users.models import PlatformRole, User


def promote(username: str, role: str) -> int:
    try:
        new_role = PlatformRole(role)
    except ValueError:
        print(f"Unknown role {role!r}. Choose from: {', '.join(r.value for r in PlatformRole)}", file=sys.stderr)
        return 2
    with SessionLocal() as db:
        user = db.scalar(select(User).where(User.username_key == username.lower()))
        if user is None:
            print(f"No user named {username!r}.", file=sys.stderr)
            return 1
        old = user.role
        user.role = new_role
        audit.record(db, "admin.role_changed", target_type="user", target_id=str(user.id),
                     source="cli", old=old.value, new=new_role.value)
        db.commit()
    print(f"{username}: {old.value} -> {new_role.value}")
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="python -m app.cli")
    sub = p.add_subparsers(dest="cmd", required=True)
    pr = sub.add_parser("promote", help="set a user's platform role")
    pr.add_argument("username")
    pr.add_argument("role")
    args = p.parse_args(argv)
    return promote(args.username, args.role)


if __name__ == "__main__":
    raise SystemExit(main())
