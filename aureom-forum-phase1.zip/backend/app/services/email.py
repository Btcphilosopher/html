"""Outbound email. `file` writes JSON to the dev outbox; `smtp` sends for real."""
from __future__ import annotations

import json
import logging
import smtplib
import time
import uuid
from email.message import EmailMessage

from app.config import get_settings

log = logging.getLogger("aureom.email")


def send_email(to: str, subject: str, body: str) -> None:
    s = get_settings()
    try:
        if s.email_backend == "smtp":
            msg = EmailMessage()
            msg["From"], msg["To"], msg["Subject"] = s.email_from, to, subject
            msg.set_content(body)
            with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=15) as smtp:
                if s.smtp_starttls:
                    smtp.starttls()
                if s.smtp_user:
                    smtp.login(s.smtp_user, s.smtp_password or "")
                smtp.send_message(msg)
        else:
            s.outbox_dir.mkdir(parents=True, exist_ok=True)
            name = f"{time.time_ns()}-{uuid.uuid4().hex[:8]}.json"
            (s.outbox_dir / name).write_text(
                json.dumps({"to": to, "subject": subject, "body": body, "sent_at": time.time()})
            )
    except Exception:  # never let a mail failure break the request
        log.exception("Failed to send email to %s", to)


def read_outbox(limit: int = 50) -> list[dict]:
    d = get_settings().outbox_dir
    if not d.exists():
        return []
    files = sorted(d.glob("*.json"), reverse=True)[:limit]
    return [json.loads(f.read_text()) for f in files]


def clear_outbox() -> None:
    d = get_settings().outbox_dir
    if d.exists():
        for f in d.glob("*.json"):
            f.unlink()
