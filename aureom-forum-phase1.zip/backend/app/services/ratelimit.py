"""Fixed-window rate limiting. Redis when REDIS_URL is set, memory otherwise.

The in-memory limiter is per process, so it is only suitable for development
and single-worker deployments; production should set REDIS_URL."""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass

from app.config import get_settings

log = logging.getLogger("aureom.ratelimit")


@dataclass
class Result:
    allowed: bool
    retry_after: int


class MemoryLimiter:
    def __init__(self) -> None:
        self._hits: dict[str, tuple[int, float]] = {}
        self._lock = threading.Lock()

    def hit(self, key: str, limit: int, window: int) -> Result:
        now = time.monotonic()
        with self._lock:
            count, reset_at = self._hits.get(key, (0, now + window))
            if now >= reset_at:
                count, reset_at = 0, now + window
            count += 1
            self._hits[key] = (count, reset_at)
            return Result(count <= limit, max(1, int(reset_at - now)))

    def clear(self, key: str) -> None:
        with self._lock:
            self._hits.pop(key, None)

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


class RedisLimiter:
    def __init__(self, url: str) -> None:
        import redis

        self._r = redis.Redis.from_url(url, socket_timeout=1, socket_connect_timeout=1)
        self._fallback = MemoryLimiter()

    def hit(self, key: str, limit: int, window: int) -> Result:
        try:
            k = f"rl:{key}"
            count = self._r.incr(k)
            if count == 1:
                self._r.expire(k, window)
            ttl = self._r.ttl(k)
            return Result(count <= limit, max(1, ttl if ttl and ttl > 0 else window))
        except Exception:
            log.warning("Redis unavailable; using in-process rate limiting", exc_info=True)
            return self._fallback.hit(key, limit, window)

    def clear(self, key: str) -> None:
        try:
            self._r.delete(f"rl:{key}")
        except Exception:
            self._fallback.clear(key)

    def reset(self) -> None:
        self._fallback.reset()


def _build():
    url = get_settings().redis_url
    return RedisLimiter(url) if url else MemoryLimiter()


limiter = _build()
