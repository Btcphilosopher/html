from __future__ import annotations

from sqlalchemy.orm import Session

from app.administration.models import AuditLog


def record(db: Session, action: str, *, actor_id=None, target_type: str | None = None,
           target_id: str | None = None, ip: str | None = None, **data) -> None:
    """Adds an audit row to the current transaction (the caller commits)."""
    db.add(AuditLog(actor_user_id=actor_id, action=action, target_type=target_type,
                    target_id=target_id, ip=ip, data=data))
