"""Imports every model so Base.metadata is complete (used by Alembic and tests)."""
from app.administration.models import AuditLog  # noqa: F401
from app.auth.models import AuthSession, EmailToken  # noqa: F401
from app.users.models import User  # noqa: F401
