"""Account and session logic shared by the routers."""
from __future__ import annotations

from datetime import timedelta

from fastapi import Request, Response
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.auth.models import AuthSession, EmailToken
from app.auth.security import hash_token, new_token
from app.config import get_settings
from app.database import utcnow
from app.users.models import User

VERIFY, RESET = "verify_email", "reset_password"


def find_user_by_identifier(db: Session, identifier: str) -> User | None:
    ident = identifier.strip().lower()
    col = User.email if "@" in ident else User.username_key
    return db.scalar(select(User).where(col == ident))


def create_session(db: Session, user: User, ip: str | None, user_agent: str | None):
    s = get_settings()
    raw, csrf = new_token(), new_token()
    now = utcnow()
    sess = AuthSession(
        user_id=user.id, token_hash=hash_token(raw), csrf_token=csrf,
        created_at=now, last_seen_at=now, expires_at=now + timedelta(hours=s.session_ttl_hours),
        ip=ip, user_agent=(user_agent or "")[:255] or None,
    )
    db.add(sess)
    return sess, raw


def set_auth_cookies(response: Response, raw_token: str, sess: AuthSession) -> None:
    s = get_settings()
    max_age = int((sess.expires_at - utcnow()).total_seconds())
    common = dict(secure=s.cookie_secure, samesite="lax", path="/", max_age=max_age)
    response.set_cookie(s.session_cookie_name, raw_token, httponly=True, **common)
    # Readable by the page's JS so it can echo the token in X-CSRF-Token.
    response.set_cookie(s.csrf_cookie_name, sess.csrf_token, httponly=False, **common)


def clear_auth_cookies(response: Response) -> None:
    s = get_settings()
    response.delete_cookie(s.session_cookie_name, path="/")
    response.delete_cookie(s.csrf_cookie_name, path="/")


def issue_email_token(db: Session, user: User, purpose: str, ttl: timedelta) -> str:
    now = utcnow()
    db.execute(
        update(EmailToken)
        .where(EmailToken.user_id == user.id, EmailToken.purpose == purpose,
               EmailToken.used_at.is_(None))
        .values(used_at=now)  # supersede earlier unused tokens
    )
    raw = new_token()
    db.add(EmailToken(user_id=user.id, purpose=purpose, token_hash=hash_token(raw),
                      created_at=now, expires_at=now + ttl))
    return raw


def consume_email_token(db: Session, raw: str, purpose: str) -> EmailToken | None:
    tok = db.scalar(select(EmailToken).where(EmailToken.token_hash == hash_token(raw),
                                             EmailToken.purpose == purpose))
    now = utcnow()
    if tok is None or tok.used_at is not None or tok.expires_at <= now:
        return None
    tok.used_at = now
    return tok


def revoke_sessions(db: Session, user_id, except_id=None) -> int:
    q = update(AuthSession).where(AuthSession.user_id == user_id,
                                  AuthSession.revoked_at.is_(None))
    if except_id is not None:
        q = q.where(AuthSession.id != except_id)
    return db.execute(q.values(revoked_at=utcnow())).rowcount or 0


def user_agent_of(request: Request) -> str | None:
    return request.headers.get("user-agent")
