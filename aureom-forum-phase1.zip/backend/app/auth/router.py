from __future__ import annotations

import uuid
from datetime import timedelta

from fastapi import APIRouter, BackgroundTasks, Depends, Request, Response
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.api.deps import (AuthContext, client_ip, current_auth, enforce_rate,
                          optional_auth)
from app.api.errors import AppError
from app.auth import service
from app.auth.models import AuthSession
from app.auth.schemas import (ChangePasswordIn, EmailIn, LoginIn, MessageOut, RegisterIn,
                              ResetIn, RevokedOut, SessionInfo, SessionStateOut, TokenIn)
from app.auth.security import (DUMMY_HASH, hash_password, needs_rehash, validate_password,
                               verify_password)
from app.config import get_settings
from app.database import get_db, utcnow
from app.services import audit
from app.services.email import send_email
from app.services.ratelimit import limiter
from app.users.models import AccountStatus, User
from app.users.schemas import UserOut

router = APIRouter(prefix="/auth", tags=["auth"])

ACCEPTED = "If that is possible, we have sent an email with the next step."


def _weak(problems: list[str]) -> AppError:
    return AppError(422, "weak_password", "That password is not strong enough.",
                    [{"field": "password", "message": p} for p in problems])


def _link(path: str, token: str) -> str:
    return f"{get_settings().public_base_url.rstrip('/')}/{path}?token={token}"


@router.post("/register", status_code=202, response_model=MessageOut)
def register(body: RegisterIn, request: Request, background: BackgroundTasks,
             db: Session = Depends(get_db)):
    s, ip = get_settings(), client_ip(request)
    if not s.registration_open:
        raise AppError(403, "registration_closed", "Registration is currently closed.")
    enforce_rate("register", ip, s.register_attempts, s.register_window_seconds)

    problems = validate_password(body.password, body.username, body.email)
    if problems:
        raise AppError(422, "weak_password", "That password is not strong enough.",
                       [{"field": "password", "message": p} for p in problems])

    pw_hash = hash_password(body.password)  # hashed on every path to keep timing similar
    if db.scalar(select(User.id).where(User.username_key == body.username.lower())):
        raise AppError(409, "username_taken", "That username is taken.",
                       [{"field": "username", "message": "That username is taken."}])

    existing = db.scalar(select(User).where(User.email == body.email))
    if existing:
        # Same response as success, so the form cannot be used to probe for accounts.
        audit.record(db, "auth.register_duplicate_email", actor_id=existing.id, ip=ip)
        db.commit()
        background.add_task(
            send_email, existing.email, "Someone tried to register with your email",
            "Someone tried to create an Aureom Forum account with this email address, "
            "but you already have one. If it was you, sign in or reset your password:\n"
            f"{s.public_base_url.rstrip('/')}/forgot-password\n\nIf not, ignore this message.",
        )
        return MessageOut(message=ACCEPTED)

    user = User(username=body.username, username_key=body.username.lower(), email=body.email,
                display_name=body.display_name or body.username, password_hash=pw_hash)
    db.add(user)
    try:
        db.flush()
        raw = service.issue_email_token(db, user, service.VERIFY,
                                        timedelta(hours=s.verify_token_ttl_hours))
        audit.record(db, "auth.register", actor_id=user.id, target_type="user",
                     target_id=str(user.id), ip=ip)
        db.commit()
    except IntegrityError:
        db.rollback()
        if db.scalar(select(User.id).where(User.username_key == body.username.lower())):
            raise AppError(409, "username_taken", "That username is taken.",
                           [{"field": "username", "message": "That username is taken."}])
        return MessageOut(message=ACCEPTED)
    background.add_task(
        send_email, user.email, "Confirm your Aureom Forum email",
        f"Welcome, {user.display_name}.\n\nConfirm your email address to activate your account:\n"
        f"{_link('verify-email', raw)}\n\nThis link expires in {s.verify_token_ttl_hours} hours.",
    )
    return MessageOut(message=ACCEPTED)


@router.post("/verify-email", response_model=MessageOut)
def verify_email(body: TokenIn, request: Request, db: Session = Depends(get_db)):
    tok = service.consume_email_token(db, body.token, service.VERIFY)
    if tok is None:
        raise AppError(400, "invalid_token", "This link is invalid or has expired.")
    user = db.get(User, tok.user_id)
    if user.email_verified_at is None:
        user.email_verified_at = utcnow()
    audit.record(db, "auth.verify_email", actor_id=user.id, ip=client_ip(request))
    db.commit()
    return MessageOut(message="Email confirmed. You can sign in now.")


@router.post("/resend-verification", status_code=202, response_model=MessageOut)
def resend_verification(body: EmailIn, request: Request, background: BackgroundTasks,
                        db: Session = Depends(get_db)):
    s, ip = get_settings(), client_ip(request)
    enforce_rate("resend", ip, s.reset_attempts, s.reset_window_seconds)
    user = db.scalar(select(User).where(User.email == body.email))
    if user and not user.is_verified and user.status == AccountStatus.ACTIVE:
        raw = service.issue_email_token(db, user, service.VERIFY,
                                        timedelta(hours=s.verify_token_ttl_hours))
        db.commit()
        background.add_task(send_email, user.email, "Confirm your Aureom Forum email",
                            f"Confirm your email address:\n{_link('verify-email', raw)}")
    return MessageOut(message=ACCEPTED)


@router.post("/login", response_model=UserOut)
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    s, ip = get_settings(), client_ip(request)
    ident = body.identifier.strip().lower()
    enforce_rate("login-ip", ip, s.login_ip_attempts, s.login_window_seconds)
    pair_key = f"{ip}:{ident}"
    enforce_rate("login", pair_key, s.login_attempts, s.login_window_seconds)

    user = service.find_user_by_identifier(db, ident)
    ok = verify_password(user.password_hash if user else DUMMY_HASH, body.password)
    if not (user and ok):
        audit.record(db, "auth.login_failed", actor_id=user.id if user else None, ip=ip)
        db.commit()
        raise AppError(401, "invalid_credentials", "Username or password is incorrect.")
    if user.status != AccountStatus.ACTIVE:
        audit.record(db, "auth.login_blocked", actor_id=user.id, ip=ip, status=user.status.value)
        db.commit()
        raise AppError(403, "account_unavailable", "This account cannot sign in.")
    if not user.is_verified:
        raise AppError(403, "email_not_verified",
                       "Confirm your email address before signing in.")

    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(body.password)
    user.last_login_at = utcnow()
    sess, raw = service.create_session(db, user, ip, service.user_agent_of(request))
    audit.record(db, "auth.login", actor_id=user.id, ip=ip)
    db.commit()
    limiter.clear(f"login:{pair_key}")
    service.set_auth_cookies(response, raw, sess)
    return UserOut.of(user)


@router.get("/session", response_model=SessionStateOut)
def session_state(ctx: AuthContext | None = Depends(optional_auth)):
    """Never errors for guests, so the page can bootstrap without a 401."""
    if ctx is None:
        return SessionStateOut(authenticated=False)
    return SessionStateOut(authenticated=True, user=UserOut.of(ctx.user))


@router.post("/logout", status_code=204)
def logout(request: Request, ctx: AuthContext = Depends(current_auth),
           db: Session = Depends(get_db)):
    ctx.session.revoked_at = utcnow()
    audit.record(db, "auth.logout", actor_id=ctx.user.id, ip=client_ip(request))
    db.commit()
    response = Response(status_code=204)
    service.clear_auth_cookies(response)
    return response


@router.post("/password/forgot", status_code=202, response_model=MessageOut)
def forgot_password(body: EmailIn, request: Request, background: BackgroundTasks,
                    db: Session = Depends(get_db)):
    s, ip = get_settings(), client_ip(request)
    enforce_rate("reset", ip, s.reset_attempts, s.reset_window_seconds)
    user = db.scalar(select(User).where(User.email == body.email))
    if user and user.status == AccountStatus.ACTIVE:
        raw = service.issue_email_token(db, user, service.RESET,
                                        timedelta(minutes=s.reset_token_ttl_minutes))
        audit.record(db, "auth.reset_requested", actor_id=user.id, ip=ip)
        db.commit()
        background.add_task(
            send_email, user.email, "Reset your Aureom Forum password",
            f"Use this link to choose a new password:\n{_link('reset-password', raw)}\n\n"
            f"It expires in {s.reset_token_ttl_minutes} minutes. If you did not ask for it, "
            "you can ignore this message.",
        )
    return MessageOut(message=ACCEPTED)


@router.post("/password/reset", response_model=MessageOut)
def reset_password(body: ResetIn, request: Request, db: Session = Depends(get_db)):
    tok = service.consume_email_token(db, body.token, service.RESET)
    if tok is None:
        raise AppError(400, "invalid_token", "This link is invalid or has expired.")
    user = db.get(User, tok.user_id)
    problems = validate_password(body.new_password, user.username, user.email)
    if problems:
        db.rollback()  # leave the token unused so the person can try again
        raise _weak(problems)
    user.password_hash = hash_password(body.new_password)
    user.password_changed_at = utcnow()
    if user.email_verified_at is None:
        user.email_verified_at = utcnow()  # the reset link proved control of the mailbox
    n = service.revoke_sessions(db, user.id)
    audit.record(db, "auth.password_reset", actor_id=user.id, ip=client_ip(request), revoked=n)
    db.commit()
    return MessageOut(message="Password updated. Sign in with your new password.")


@router.post("/password/change", response_model=MessageOut)
def change_password(body: ChangePasswordIn, request: Request, background: BackgroundTasks,
                    ctx: AuthContext = Depends(current_auth), db: Session = Depends(get_db)):
    user = ctx.user
    enforce_rate("pwchange", str(user.id), 5, 900)
    if not verify_password(user.password_hash, body.current_password):
        raise AppError(403, "invalid_credentials", "Your current password is incorrect.",
                       [{"field": "current_password", "message": "Incorrect password."}])
    problems = validate_password(body.new_password, user.username, user.email)
    if problems:
        raise _weak(problems)
    user.password_hash = hash_password(body.new_password)
    user.password_changed_at = utcnow()
    n = service.revoke_sessions(db, user.id, except_id=ctx.session.id)
    audit.record(db, "auth.password_changed", actor_id=user.id, ip=client_ip(request), revoked=n)
    db.commit()
    background.add_task(send_email, user.email, "Your Aureom Forum password was changed",
                        "Your password was just changed and other devices were signed out. "
                        "If this was not you, reset your password immediately.")
    return MessageOut(message="Password changed. Other devices have been signed out.")


@router.get("/sessions", response_model=list[SessionInfo])
def list_sessions(ctx: AuthContext = Depends(current_auth), db: Session = Depends(get_db)):
    rows = db.scalars(
        select(AuthSession)
        .where(AuthSession.user_id == ctx.user.id, AuthSession.revoked_at.is_(None),
               AuthSession.expires_at > utcnow())
        .order_by(AuthSession.last_seen_at.desc()).limit(50)
    ).all()
    return [SessionInfo(id=r.id, created_at=r.created_at, last_seen_at=r.last_seen_at,
                        expires_at=r.expires_at, ip=r.ip, user_agent=r.user_agent,
                        current=r.id == ctx.session.id) for r in rows]


@router.post("/sessions/revoke-others", response_model=RevokedOut)
def revoke_others(request: Request, ctx: AuthContext = Depends(current_auth),
                  db: Session = Depends(get_db)):
    n = service.revoke_sessions(db, ctx.user.id, except_id=ctx.session.id)
    audit.record(db, "auth.sessions_revoked", actor_id=ctx.user.id, ip=client_ip(request), count=n)
    db.commit()
    return RevokedOut(revoked=n)


@router.delete("/sessions/{session_id}", status_code=204)
def revoke_session(session_id: uuid.UUID, request: Request,
                   ctx: AuthContext = Depends(current_auth), db: Session = Depends(get_db)):
    sess = db.get(AuthSession, session_id)
    if sess is None or sess.user_id != ctx.user.id or sess.revoked_at is not None:
        raise AppError(404, "not_found", "Session not found.")
    sess.revoked_at = utcnow()
    audit.record(db, "auth.session_revoked", actor_id=ctx.user.id, ip=client_ip(request),
                 session_id=str(session_id))
    db.commit()
    response = Response(status_code=204)
    if sess.id == ctx.session.id:
        service.clear_auth_cookies(response)
    return response
