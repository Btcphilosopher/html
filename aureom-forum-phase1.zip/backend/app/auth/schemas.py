import re
import uuid
from datetime import datetime

from pydantic import BaseModel, EmailStr, Field, field_validator

from app.users.schemas import UserOut

_USERNAME = re.compile(r"^[A-Za-z0-9_]{3,32}$")
_RESERVED = {"admin", "administrator", "root", "system", "moderator", "mod", "support",
             "aureom", "staff", "null", "anonymous", "everyone"}
_CONTROL = re.compile(r"[\x00-\x1f\x7f]")


class RegisterIn(BaseModel):
    username: str
    email: EmailStr
    password: str = Field(max_length=256)
    display_name: str | None = Field(default=None, max_length=80)

    @field_validator("username")
    @classmethod
    def _username(cls, v: str) -> str:
        v = v.strip()
        if not _USERNAME.match(v):
            raise ValueError("Use 3 to 32 letters, numbers or underscores.")
        if v.lower() in _RESERVED:
            raise ValueError("That username is reserved.")
        return v

    @field_validator("email")
    @classmethod
    def _email(cls, v: str) -> str:
        return v.strip().lower()

    @field_validator("display_name")
    @classmethod
    def _display(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = _CONTROL.sub("", v).strip()
        return v or None


class LoginIn(BaseModel):
    identifier: str = Field(min_length=1, max_length=320)
    password: str = Field(min_length=1, max_length=256)


class TokenIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)


class EmailIn(BaseModel):
    email: EmailStr

    @field_validator("email")
    @classmethod
    def _email(cls, v: str) -> str:
        return v.strip().lower()


class ResetIn(TokenIn):
    new_password: str = Field(max_length=256)


class ChangePasswordIn(BaseModel):
    current_password: str = Field(max_length=256)
    new_password: str = Field(max_length=256)


class MessageOut(BaseModel):
    message: str


class SessionStateOut(BaseModel):
    authenticated: bool
    user: UserOut | None = None


class SessionInfo(BaseModel):
    id: uuid.UUID
    created_at: datetime
    last_seen_at: datetime
    expires_at: datetime
    ip: str | None
    user_agent: str | None
    current: bool


class RevokedOut(BaseModel):
    revoked: int
