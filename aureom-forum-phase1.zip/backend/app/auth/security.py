"""Password hashing (Argon2id), opaque tokens and the password policy."""
from __future__ import annotations

import hashlib
import secrets

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from app.config import get_settings

_hasher = PasswordHasher()  # argon2-cffi default type is Argon2id
_COMMON = {
    "password1234", "123456789012", "qwertyuiop12", "letmein12345",
    "iloveyou1234", "administrator", "welcome12345", "changeme1234",
}


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    try:
        return _hasher.verify(stored_hash, password)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


def needs_rehash(stored_hash: str) -> bool:
    return _hasher.check_needs_rehash(stored_hash)


# Verified against when a login names an unknown account, so timing is similar.
DUMMY_HASH = hash_password(secrets.token_urlsafe(16))


def new_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def validate_password(password: str, username: str = "", email: str = "") -> list[str]:
    s = get_settings()
    problems: list[str] = []
    if len(password) < s.password_min_length:
        problems.append(f"Use at least {s.password_min_length} characters.")
    if len(password) > 128:
        problems.append("Use no more than 128 characters.")
    low = password.lower()
    if len(username) >= 3 and username.lower() in low:
        problems.append("Do not include your username.")
    local = email.split("@")[0].lower() if email else ""
    if len(local) >= 3 and local in low:
        problems.append("Do not include your email address.")
    if low in _COMMON or len(set(password)) < 5:
        problems.append("Choose something less guessable.")
    return problems
