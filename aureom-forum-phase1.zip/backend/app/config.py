"""Application settings, read from the environment (or a repo-root .env file)."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

REPO_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=REPO_ROOT / ".env", extra="ignore")

    env: Literal["development", "test", "production"] = "development"
    public_base_url: str = "http://localhost:8000"
    allowed_hosts: str = "*"  # comma separated; must be explicit in production

    database_url: str = "postgresql+psycopg://aureom:aureom@localhost:5432/aureom"
    redis_url: str | None = None

    # Sessions and cookies
    cookie_secure: bool = False
    session_cookie_name: str = "aureom_session"
    csrf_cookie_name: str = "aureom_csrf"
    session_ttl_hours: int = 24 * 14
    session_idle_hours: int = 24 * 7

    # Accounts
    registration_open: bool = True
    password_min_length: int = 12
    verify_token_ttl_hours: int = 48
    reset_token_ttl_minutes: int = 60

    # Rate limits: (attempts, window seconds)
    login_attempts: int = 5
    login_window_seconds: int = 900
    login_ip_attempts: int = 30
    register_attempts: int = 10
    register_window_seconds: int = 3600
    reset_attempts: int = 5
    reset_window_seconds: int = 3600

    # Email
    email_backend: Literal["file", "smtp"] = "file"
    email_from: str = "Aureom Forum <no-reply@localhost>"
    smtp_host: str = "localhost"
    smtp_port: int = 587
    smtp_user: str | None = None
    smtp_password: str | None = None
    smtp_starttls: bool = True
    outbox_dir: Path = REPO_ROOT / "var" / "outbox"

    serve_frontend: bool = True

    @property
    def host_list(self) -> list[str]:
        return [h.strip() for h in self.allowed_hosts.split(",") if h.strip()]

    @property
    def dev_outbox_enabled(self) -> bool:
        return self.env in {"development", "test"} and self.email_backend == "file"

    @model_validator(mode="after")
    def _production_guard(self) -> "Settings":
        if self.env == "production":
            problems = []
            if not self.cookie_secure:
                problems.append("COOKIE_SECURE must be true")
            if self.email_backend == "file":
                problems.append("EMAIL_BACKEND must be smtp")
            if self.host_list == ["*"] or not self.host_list:
                problems.append("ALLOWED_HOSTS must list your real hostnames")
            if self.database_url.startswith("sqlite"):
                problems.append("DATABASE_URL must point at PostgreSQL")
            if problems:
                raise ValueError("Unsafe production configuration: " + "; ".join(problems))
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
