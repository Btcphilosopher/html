from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware

from app.api import errors
from app.api.errors import error_response
from app.api.v1 import api_router
from app.config import REPO_ROOT, get_settings

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}
CSP = ("default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; "
       "font-src 'self'; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'self'; "
       "form-action 'self'; frame-ancestors 'none'")


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(
        title="Aureom Forum API", version="0.1.0",
        docs_url="/api/v1/docs", redoc_url=None, openapi_url="/api/v1/openapi.json",
    )
    errors.install(app)
    if s.host_list != ["*"]:
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=s.host_list)

    @app.middleware("http")
    async def guard_and_harden(request: Request, call_next):
        path = request.url.path
        if request.method in UNSAFE and path.startswith("/api/"):
            has_body = request.headers.get("content-length", "0") != "0" or \
                "transfer-encoding" in request.headers
            ctype = request.headers.get("content-type", "").split(";")[0].strip().lower()
            if has_body and ctype != "application/json":
                return error_response(415, "unsupported_media_type",
                                      "Send requests as application/json.")
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        response.headers.setdefault("X-Frame-Options", "DENY")
        if path.startswith("/api/"):
            response.headers.setdefault("Cache-Control", "no-store")
        if not path.startswith("/api/v1/docs"):  # Swagger UI loads assets from a CDN
            response.headers.setdefault("Content-Security-Policy", CSP)
        return response

    app.include_router(api_router)

    if s.serve_frontend:
        app.mount("/frontend", StaticFiles(directory=REPO_ROOT / "frontend"), name="frontend")

        @app.get("/{full_path:path}", include_in_schema=False)
        async def shell(full_path: str):
            if full_path.startswith("api/"):
                return error_response(404, "not_found", "No such API endpoint.")
            return FileResponse(REPO_ROOT / "index.html", media_type="text/html")

    return app


app = create_app()
