"""Shared request dependencies: client IP, rate limits, session auth and CSRF."""
from __future__ import annotations

import hmac
from dataclasses import dataclass
from datetime import timedelta

from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.errors import AppError
from app.auth.models import AuthSession
from app.auth.security import hash_token
from app.config import get_settings
from app.database import get_db, utcnow
from app.services.ratelimit import limiter
from app.users.models import AccountStatus, User
from app.users.models import PlatformRole
from app.users.permissions import role_at_least

UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}
TOUCH_INTERVAL = timedelta(minutes=5)


def client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def enforce_rate(bucket: str, key: str, limit: int, window: int) -> None:
    r = limiter.hit(f"{bucket}:{key}", limit, window)
    if not r.allowed:
        raise AppError(429, "rate_limited", "Too many attempts. Please wait and try again.",
                       headers={"Retry-After": str(r.retry_after)})


@dataclass
class AuthContext:
    user: User
    session: AuthSession


def _load(request: Request, db: Session) -> AuthContext | None:
    s = get_settings()
    raw = request.cookies.get(s.session_cookie_name)
    if not raw:
        return None
    sess = db.scalar(select(AuthSession).where(AuthSession.token_hash == hash_token(raw)))
    now = utcnow()
    if (
        sess is None
        or sess.revoked_at is not None
        or sess.expires_at <= now
        or sess.last_seen_at + timedelta(hours=s.session_idle_hours) <= now
    ):
        return None
    user = db.get(User, sess.user_id)
    if user is None or user.status != AccountStatus.ACTIVE:
        return None
    if now - sess.last_seen_at > TOUCH_INTERVAL:
        sess.last_seen_at = now
        db.commit()
    return AuthContext(user, sess)


def optional_auth(request: Request, db: Session = Depends(get_db)) -> AuthContext | None:
    return _load(request, db)


def current_auth(request: Request, db: Session = Depends(get_db)) -> AuthContext:
    """Requires a valid session. Unsafe methods must also carry the session's
    CSRF token in X-CSRF-Token (synchroniser token, compared in constant time)."""
    ctx = _load(request, db)
    if ctx is None:
        raise AppError(401, "not_authenticated", "Sign in to continue.")
    if request.method in UNSAFE:
        sent = request.headers.get("x-csrf-token", "")
        if not hmac.compare_digest(sent, ctx.session.csrf_token):
            raise AppError(403, "csrf_failed", "Your session could not be verified. Reload and try again.")
    return ctx


def require_role(minimum: PlatformRole):
    def dep(ctx: AuthContext = Depends(current_auth)) -> AuthContext:
        if not role_at_least(ctx.user.role, minimum):
            raise AppError(403, "forbidden", "You do not have permission to do that.")
        return ctx
    return dep
