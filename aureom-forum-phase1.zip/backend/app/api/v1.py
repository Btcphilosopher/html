from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.auth.router import router as auth_router
from app.config import get_settings
from app.database import get_db
from app.services.email import read_outbox

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(auth_router)


@api_router.get("/health", tags=["system"])
def health(db: Session = Depends(get_db)):
    db.execute(text("SELECT 1"))
    return {"status": "ok"}


@api_router.get("/meta", tags=["system"])
def meta():
    """Public, non-sensitive settings the frontend needs to render forms."""
    s = get_settings()
    return {
        "name": "Aureom Forum",
        "registration_open": s.registration_open,
        "password_min_length": s.password_min_length,
        "dev_outbox": s.dev_outbox_enabled,
    }


if get_settings().dev_outbox_enabled:
    @api_router.get("/dev/outbox", tags=["development"])
    def dev_outbox():
        """Development only: lists emails the platform "sent" instead of delivering them."""
        return read_outbox()
