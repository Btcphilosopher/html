# Security notes (Phase 1)

## Threats considered and mitigations

| Threat | Mitigation | Test |
| --- | --- | --- |
| Credential stuffing / brute force | Per identifier+IP and per-IP login limits, Argon2id, identical errors for bad password and unknown user, dummy-hash verification for unknown users | `test_login_is_rate_limited_per_identifier`, `test_wrong_password_and_unknown_user_look_the_same` |
| Account enumeration | Registration, resend and forgot-password return identical responses for known and unknown emails (usernames are public, so a taken username is reported) | `test_duplicate_email_looks_identical...`, `test_forgot_password_does_not_reveal_accounts` |
| Session theft after logout / reset | Server-side revocation; stored hashes only; password change or reset revokes sessions | `test_stolen_cookie_is_useless_after_logout`, reset and change tests |
| CSRF | SameSite=Lax cookie, per-session token required on unsafe methods, JSON-only API bodies (415 otherwise) | `test_logout_requires_csrf...`, `test_non_json_bodies_are_refused` |
| XSS | No HTML parsing of user text in the frontend, no inline scripts or styles, CSP `script-src 'self'` | frontend smoke test (markup in display name) |
| Token leakage from the database | Session and email tokens stored as SHA-256 | `test_session_token_is_stored_hashed`, `test_verification_token_is_single_use_and_hashed` |
| Open redirect after login | `safeNext` accepts only same-site paths | frontend smoke test |
| Unsafe production config | Startup validation (secure cookies, SMTP, explicit hosts, PostgreSQL) | `Settings._production_guard` |

## Known gaps (planned)

No breached-password check, no multi-factor authentication, no account lockout notification, audit log immutability is not enforced by the database, IP addresses are stored in sessions and audit rows without a retention policy, and the dev mailbox must never be enabled outside development (it is off unless `ENV` is `development` or `test` and `EMAIL_BACKEND=file`).

## Before deploying

1. `ENV=production`, `COOKIE_SECURE=true`, TLS in front of Nginx, real `ALLOWED_HOSTS`.
2. SMTP credentials set and tested; `PUBLIC_BASE_URL` is the public https address.
3. `REDIS_URL` set so rate limits are shared across workers.
4. Strong `POSTGRES_PASSWORD`; database not exposed publicly.
5. Port 8000 not published: the API trusts forwarded headers from Nginx only.
