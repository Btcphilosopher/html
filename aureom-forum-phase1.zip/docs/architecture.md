# Architecture (Phase 1)

**Request path.** Browser → Nginx → FastAPI. Nginx serves `index.html` and `/frontend/*` and proxies `/api/`. In development the API serves the frontend itself (`SERVE_FRONTEND=true`).

**Frontend.** `index.html` loads `frontend/js/app.js`, which defines `<aureom-shell>` (masthead, navigation, content outlet, sidebar), bootstraps `/api/v1/meta` and `/api/v1/auth/session`, then starts the History-API router. Pages are lazily imported modules that return DOM built with `h()`, which only ever inserts text nodes. No inline scripts or styles, so a strict CSP applies. `permissions.js` mirrors roles only to decide which controls to show.

**Backend.** One package per domain under `backend/app`. Routers are thin; logic shared between routers lives in `service.py`. Database access is synchronous SQLAlchemy 2.0 in FastAPI's thread pool (simple, correct, adequate to start; revisit for WebSockets in Phase 5). Every endpoint commits explicitly. Errors share one shape: `{"error": {"code", "message", "details": [{"field", "message"}]}}`.

**Authentication.** Opaque random session token in an HttpOnly cookie; only its SHA-256 is stored. Each session carries its own CSRF token, returned in a readable cookie and required in `X-CSRF-Token` on unsafe methods, compared in constant time. The `current_auth` dependency performs session and CSRF checks together, so a protected route cannot forget CSRF. Expiry is absolute (`SESSION_TTL_HOURS`) and idle (`SESSION_IDLE_HOURS`).

**Data model.** `users`, `auth_sessions`, `email_tokens` (hashed, single use, superseded on reissue), `audit_logs` (append-only by convention; database enforcement is a Phase 6 item). Timestamps are timezone-aware UTC via `UTCDateTime`, which also corrects SQLite's habit of dropping offsets.

**Rate limiting.** Fixed window, Redis if `REDIS_URL` is set, otherwise per-process memory (single worker only).

**Roles.** Platform roles live on the user. Community-scoped roles belong to community memberships and arrive with communities in Phase 2.
