#!/usr/bin/env bash
# Backend tests (SQLite in memory by default; set DATABASE_URL to run against PostgreSQL).
set -euo pipefail
cd "$(dirname "$0")/../backend"
python -m pytest -q "$@"
