#!/usr/bin/env bash
# Local development: migrate, then serve API + frontend on http://localhost:8000
set -euo pipefail
cd "$(dirname "$0")/../backend"
[ -f ../.env ] || cp ../.env.example ../.env
alembic upgrade head
exec uvicorn app.main:app --reload --port 8000
