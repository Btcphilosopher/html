package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.ai.AureomCopilotService
import com.example.ai.CopilotTaskType
import com.example.data.local.AccountEntity
import com.example.data.local.AureomDatabase
import com.example.data.local.CalendarEventEntity
import com.example.data.local.DeliveryStatus
import com.example.data.local.DemoSeedData
import com.example.data.local.MessageEntity
import com.example.data.local.OutboxStatus
import com.example.data.local.ProviderType
import com.example.data.local.RuleEntity
import com.example.data.local.SyncHealth
import com.example.data.repository.AureomRepository
import com.example.domain.CalendarMath
import com.example.domain.HtmlSanitizer
import com.example.domain.PromptInjectionGuard
import com.example.domain.RuleEngine
import com.example.domain.SenderSecurityAnalyzer
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.time.ZonedDateTime
import java.time.ZoneId

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AureomMailTestSuite {

    private lateinit var db: AureomDatabase
    private lateinit var repo: AureomRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AureomDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = AureomRepository(db)
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `1_account_and_shared_mailbox_permissions_enforced`() = runTest {
        repo.ensureSeeded()
        val boardMsg = db.messageDao().getById("msg_08")!!
        var threw = false
        try {
            repo.moveMessageToFolder(boardMsg.id, "fld_work_archive", isOffline = false)
        } catch (e: IllegalStateException) {
            threw = true
        }
        assertTrue("Board Audit mailbox with READ-only permission must block FILE/move", threw)

        val restrictedDraft = boardMsg.copy(id = "msg_board_send", toRecipients = "someone@aureom-corp.example")
        var sendThrew = false
        try {
            repo.queueOrSendMessage(restrictedDraft, 0, null, isOffline = false)
        } catch (e: IllegalStateException) {
            sendThrew = true
        }
        assertTrue("Board Audit mailbox without SEND_AS must block sending", sendThrew)
    }

    @Test
    fun `2_html_sanitization_remote_images_and_reply_to_spoofing`() {
        val seed = DemoSeedData.createSeedSnapshot()
        val secMsg = seed.messages.first { it.id == "msg_03" }

        val sanitized = HtmlSanitizer.sanitize(secMsg.bodyHtml, blockRemoteImages = true)
        assertFalse("Script tag must be stripped", sanitized.safeHtml.contains("<script", ignoreCase = true))
        assertFalse("XSS payload must be stripped", sanitized.safeHtml.contains("alert('xss')"))
        assertEquals(1, sanitized.blockedRemoteImageCount)
        assertTrue(sanitized.strippedDangerousTagsCount >= 1)

        val warning = SenderSecurityAnalyzer.analyze(secMsg)
        assertNotNull("Reply-To mismatch + DKIM/DMARC failure must surface warning", warning)
        assertTrue(warning!!.hasReplyToMismatch)
        assertTrue(warning.hasAuthFailure)
    }

    @Test
    fun `3_draft_autosave_and_recovery`() = runTest {
        repo.ensureSeeded()
        val draft = MessageEntity(
            id = "msg_draft_test",
            accountId = "acc_work",
            folderId = "fld_work_inbox",
            threadId = "thr_test",
            subject = "Autosave Verification",
            senderName = "Elena Vance",
            senderEmail = "elena.vance@aureom-corp.example",
            toRecipients = "m.sterling@northstar-partners.example",
            bodyPlainText = "Recoverable draft text.",
            bodyHtml = "<p>Recoverable draft text.</p>",
            snippet = "Recoverable draft text.",
            timestampEpochMs = System.currentTimeMillis(),
            messageIdHeader = "<draft-test@aureom-corp.example>"
        )
        val saved = repo.saveDraft(draft)
        assertEquals("fld_work_drafts", saved.folderId)
        assertEquals(DeliveryStatus.DRAFT.name, saved.deliveryStatus)

        val recovered = db.messageDao().getById("msg_draft_test")
        assertNotNull(recovered)
        assertEquals("Autosave Verification", recovered!!.subject)
    }

    @Test
    fun `4_duplicate_send_prevention_and_delayed_send_cancellation`() = runTest {
        repo.ensureSeeded()
        val draft = MessageEntity(
            id = "msg_idem_1",
            accountId = "acc_work",
            folderId = "fld_work_drafts",
            threadId = "thr_idem",
            subject = "Idempotent Send",
            senderName = "Elena Vance",
            senderEmail = "elena.vance@aureom-corp.example",
            toRecipients = "claire.dubois@aureom-corp.example",
            bodyPlainText = "Testing delayed send & duplicate guard.",
            bodyHtml = "<p>Testing</p>",
            snippet = "Testing",
            timestampEpochMs = System.currentTimeMillis(),
            messageIdHeader = "<idem-1@aureom-corp.example>",
            idempotencyKey = "unique-key-123"
        )
        val delayed = repo.queueOrSendMessage(draft, delayWindowSeconds = 10, scheduledEpochMs = null, isOffline = false)
        assertEquals(DeliveryStatus.DELAYED_SEND.name, delayed.deliveryStatus)

        // Second attempt with same idempotencyKey returns existing without duplicating
        val duplicateAttempt = repo.queueOrSendMessage(
            draft.copy(id = "msg_idem_2"),
            delayWindowSeconds = 0,
            scheduledEpochMs = null,
            isOffline = false
        )
        assertEquals("msg_idem_1", duplicateAttempt.id)

        // Cancel during local delay window restores draft
        val cancelled = repo.cancelDelayedSend("msg_idem_1")
        assertTrue(cancelled)
        assertEquals(DeliveryStatus.DRAFT.name, db.messageDao().getById("msg_idem_1")!!.deliveryStatus)
    }

    @Test
    fun `5_uncertain_submission_outcome_surfaced_without_auto_resend`() = runTest {
        repo.ensureSeeded()
        val msg = MessageEntity(
            id = "msg_uncertain",
            accountId = "acc_work",
            folderId = "fld_work_drafts",
            threadId = "thr_unc",
            subject = "Uncertain SMTP Ack",
            senderName = "Elena Vance",
            senderEmail = "elena.vance@aureom-corp.example",
            toRecipients = "m.sterling@northstar-partners.example",
            bodyPlainText = "Checking uncertain outcome.",
            bodyHtml = "<p>Checking</p>",
            snippet = "Checking",
            timestampEpochMs = System.currentTimeMillis(),
            messageIdHeader = "<unc@aureom-corp.example>",
            idempotencyKey = "key-uncertain"
        )
        val res = repo.queueOrSendMessage(msg, delayWindowSeconds = 0, scheduledEpochMs = null, isOffline = false, simulateUncertain = true)
        assertEquals(DeliveryStatus.UNCERTAIN.name, res.deliveryStatus)

        val outbox = db.outboxDao().getPendingOrFailed()
        assertTrue(outbox.any { it.status == OutboxStatus.UNCERTAIN_OUTCOME.name && it.targetId == "msg_uncertain" })

        // Reconciling must NOT auto-resend uncertain items
        repo.reconcileOutboxWhenOnline()
        assertEquals(DeliveryStatus.UNCERTAIN.name, db.messageDao().getById("msg_uncertain")!!.deliveryStatus)
    }

    @Test
    fun `6_incremental_imap_uidvalidity_detection_and_recovery`() = runTest {
        repo.ensureSeeded()
        val failedSummary = repo.syncAccount("acc_personal", recoverUidValidity = false)
        assertTrue(failedSummary.contains("UIDVALIDITY"))
        assertEquals(SyncHealth.FAILED.name, db.accountDao().getById("acc_personal")!!.syncHealth)

        val recoveredSummary = repo.syncAccount("acc_personal", recoverUidValidity = true)
        assertTrue(recoveredSummary.contains("Synced"))
        val acc = db.accountDao().getById("acc_personal")!!
        assertEquals(SyncHealth.SYNCED.name, acc.syncHealth)
        assertEquals(4899L, acc.imapUidValidity)
    }

    @Test
    fun `7_recurring_calendar_exception_preserves_series_master`() = runTest {
        repo.ensureSeeded()
        val master = db.calendarDao().getEventById("evt_01")!!
        repo.editSingleRecurringOccurrence(
            masterEventId = master.id,
            occurrenceStartMs = master.startEpochMs,
            newTitle = "Special Moved Standup",
            newStartMs = master.startEpochMs + 7_200_000L,
            newEndMs = master.endEpochMs + 7_200_000L,
            newLocation = "Room Z"
        )
        val updatedMaster = db.calendarDao().getEventById("evt_01")!!
        assertEquals("Q4 Nordic Launch Standup", updatedMaster.title)
        assertTrue(updatedMaster.exceptionDatesCsv.isNotBlank())

        val allEvents = db.calendarDao().observeAllEvents().first()
        val overrideEvent = allEvents.firstOrNull { it.seriesMasterId == "evt_01" }
        assertNotNull(overrideEvent)
        assertEquals("Special Moved Standup", overrideEvent!!.title)
    }

    @Test
    fun `8_daylight_saving_transition_and_timezone_math`() {
        // US Eastern Spring Forward: 2026-03-08 02:00 jumps to 03:00 EDT
        val nyZone = ZoneId.of("America/New_York")
        val preDst = ZonedDateTime.of(2026, 3, 7, 9, 0, 0, 0, nyZone)
        val evt = CalendarEventEntity(
            id = "evt_dst",
            calendarId = "cal_work",
            accountId = "acc_work",
            title = "DST Daily Check",
            startEpochMs = preDst.toInstant().toEpochMilli(),
            endEpochMs = preDst.plusHours(1).toInstant().toEpochMilli(),
            timezoneId = "America/New_York",
            recurrenceRule = "DAILY"
        )
        val rangeEnd = preDst.plusDays(4).toInstant().toEpochMilli()
        val occurrences = CalendarMath.expandOccurrences(listOf(evt), evt.startEpochMs, rangeEnd)
        assertEquals(5, occurrences.size)

        // Wall-clock hour on March 9 (after DST transition) must still be 09:00 America/New_York
        val march9 = ZonedDateTime.ofInstant(java.time.Instant.ofEpochMilli(occurrences[2].startEpochMs), nyZone)
        assertEquals(9, march9.hour)
        assertTrue(CalendarMath.isDaylightSavingTime(occurrences[2].startEpochMs, "America/New_York"))
    }

    @Test
    fun `9_offline_queue_persistence_and_reconciliation`() = runTest {
        repo.ensureSeeded()
        val msg = MessageEntity(
            id = "msg_off_1",
            accountId = "acc_work",
            folderId = "fld_work_drafts",
            threadId = "thr_off",
            subject = "Offline Queued Mail",
            senderName = "Elena Vance",
            senderEmail = "elena.vance@aureom-corp.example",
            toRecipients = "claire.dubois@aureom-corp.example",
            bodyPlainText = "Sent while offline.",
            bodyHtml = "<p>Sent while offline.</p>",
            snippet = "Sent while offline.",
            timestampEpochMs = System.currentTimeMillis(),
            messageIdHeader = "<off-1@aureom-corp.example>"
        )
        val queued = repo.queueOrSendMessage(msg, delayWindowSeconds = 0, scheduledEpochMs = null, isOffline = true)
        assertEquals(DeliveryStatus.QUEUED_OFFLINE.name, queued.deliveryStatus)

        val reconciledCount = repo.reconcileOutboxWhenOnline()
        assertEquals(1, reconciledCount)
        assertEquals(DeliveryStatus.SUBMITTED.name, db.messageDao().getById("msg_off_1")!!.deliveryStatus)
    }

    @Test
    fun `10_search_excludes_inaccessible_shared_mailbox`() = runTest {
        repo.ensureSeeded()
        // "SapphireEscrowToken99" lives inside acc_shared_board where isSearchIndexedForUser = false
        val restrictedHits = repo.searchMessages("SapphireEscrowToken99")
        assertTrue("Inaccessible shared mailbox content must NEVER appear in user search", restrictedHits.isEmpty())

        val permittedHits = repo.searchMessages("Nordic")
        assertTrue("Permitted mailbox content must appear in search", permittedHits.isNotEmpty())
    }

    @Test
    fun `11_and_12_prompt_injection_guard_and_ai_approval_enforcement`() = runTest {
        repo.ensureSeeded()
        val injectedMsg = db.messageDao().getById("msg_03")!!
        assertTrue(PromptInjectionGuard.containsInjectionAttempt(injectedMsg.bodyPlainText))

        val copilot = AureomCopilotService()
        val tasksBefore = db.taskDao().observeAll().first().size

        val result = copilot.runTask(
            taskType = CopilotTaskType.EXTRACT_TASKS_MEETINGS,
            authorizedMessages = listOf(injectedMsg),
            useMockMode = true,
            isOffline = false
        )
        assertNotNull("Copilot must surface injection block notice", result.injectionBlockedNotice)
        assertTrue("Copilot proposes action requiring approval", result.proposedActions.isNotEmpty())

        // Verify no tasks were mutated automatically before user approval
        val tasksAfter = db.taskDao().observeAll().first().size
        assertEquals("AI must remain read-only until explicit user approval", tasksBefore, tasksAfter)
    }

    @Test
    fun `rule_engine_loop_prevention_and_explicit_forwarding_gate`() {
        val seed = DemoSeedData.createSeedSnapshot()
        val msg = seed.messages.first()
        val folders = seed.folders.filter { it.accountId == msg.accountId }

        val unconfirmedForward = RuleEntity(
            id = "r_fwd",
            accountId = "ALL",
            name = "Unconfirmed External Fwd",
            orderIndex = 1,
            scope = "APP_SIDE",
            conditionField = "SUBJECT",
            conditionValue = "Nordic",
            actionType = "FORWARD_EXPLICIT",
            actionTarget = "outside@evil.example",
            explicitForwardConfirmed = false
        )
        val summary = RuleEngine.applyRules(msg, listOf(unconfirmedForward), folders)
        assertTrue("Unconfirmed forwarding rule must never trigger", summary.triggeredRuleNames.isEmpty())
    }
}
