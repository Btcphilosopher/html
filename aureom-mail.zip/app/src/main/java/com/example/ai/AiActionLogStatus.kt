package com.example.ai

enum class AiActionLogStatus {
    COMPLETED,
    CANCELLED,
    AWAITING_APPROVAL,
    APPROVED,
    REJECTED,
    ERROR
}
