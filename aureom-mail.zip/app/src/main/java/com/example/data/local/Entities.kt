package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ProviderType { MICROSOFT_GRAPH, GMAIL_API, IMAP_SMTP, SHARED_MAILBOX }
enum class SyncHealth { SYNCED, SYNCING, FAILED, OFFLINE_PAUSED }
enum class FolderSystemType { INBOX, SENT, DRAFTS, ARCHIVE, JUNK, DELETED, CUSTOM }
enum class DeliveryStatus { RECEIVED, DRAFT, QUEUED_OFFLINE, DELAYED_SEND, SUBMITTED, FAILED, UNCERTAIN }
enum class AuthResult { PASS, FAIL, NONE }
enum class ScanStatus { CLEAN, QUARANTINED, PENDING }
enum class RsvpStatus { ORGANIZER, ACCEPTED, TENTATIVE, DECLINED, NEEDS_ACTION }
enum class InvitationSendState { LOCAL_ONLY, INVITE_SENT, PENDING_OFFLINE }
enum class TaskPriority { HIGH, NORMAL, LOW }
enum class RuleScope { APP_SIDE, PROVIDER_SIDE }
enum class OutboxStatus { PENDING, IN_FLIGHT, UNCERTAIN_OUTCOME, FAILED, COMPLETED }

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val email: String,
    val providerType: String, // ProviderType.name
    val avatarColorHex: Long,
    val signature: String,
    val syncHealth: String, // SyncHealth.name
    val lastSyncEpochMs: Long,
    val syncErrorMessage: String? = null,
    val imapUidValidity: Long? = null,
    val imapLastUid: Long? = null,
    val oauthTokenStatus: String = "VALID_OAUTH2",
    val rateLimitRemaining: Int = 950,
    val isSharedMailbox: Boolean = false,
    val sharedPermissions: String = "READ,FILE,REPLY,SEND_AS", // comma-separated
    val isSearchIndexedForUser: Boolean = true
) {
    fun hasPermission(permission: String): Boolean {
        if (!isSharedMailbox) return true
        return sharedPermissions.split(",").map { it.trim() }.contains(permission)
    }
}

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val name: String,
    val parentFolderId: String? = null,
    val systemType: String, // FolderSystemType.name
    val imapUidValidity: Long? = null
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val folderId: String,
    val threadId: String,
    val subject: String,
    val senderName: String,
    val senderEmail: String,
    val replyToEmail: String? = null,
    val toRecipients: String,
    val ccRecipients: String = "",
    val bccRecipients: String = "",
    val bodyPlainText: String,
    val bodyHtml: String,
    val snippet: String,
    val timestampEpochMs: Long,
    val isRead: Boolean = false,
    val isFlagged: Boolean = false,
    val followUpDueEpochMs: Long? = null,
    val isPinned: Boolean = false,
    val snoozedUntilEpochMs: Long? = null,
    val categories: String = "", // comma-separated
    val authSpf: String = AuthResult.PASS.name,
    val authDkim: String = AuthResult.PASS.name,
    val authDmarc: String = AuthResult.PASS.name,
    val providerUid: Long? = null,
    val messageIdHeader: String,
    val deliveryStatus: String = DeliveryStatus.RECEIVED.name,
    val scheduledSendEpochMs: Long? = null,
    val delayedSendCancelUntilEpochMs: Long? = null,
    val sendingIdentityEmail: String? = null,
    val internalNote: String? = null,
    val assignedOwner: String? = null,
    val remoteImagesBlocked: Boolean = true,
    val idempotencyKey: String? = null
)

@Entity(tableName = "attachments")
data class AttachmentEntity(
    @PrimaryKey val id: String,
    val messageId: String,
    val accountId: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val localCachedPath: String,
    val scanStatus: String = ScanStatus.CLEAN.name,
    val isInline: Boolean = false,
    val createdEpochMs: Long
)

@Entity(tableName = "calendars")
data class CalendarEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val name: String,
    val colorHex: Long,
    val timezoneId: String,
    val isVisible: Boolean = true,
    val isPrimary: Boolean = false
)

@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
    @PrimaryKey val id: String,
    val calendarId: String,
    val accountId: String,
    val seriesMasterId: String? = null,
    val title: String,
    val description: String = "",
    val location: String = "",
    val startEpochMs: Long,
    val endEpochMs: Long,
    val timezoneId: String,
    val isAllDay: Boolean = false,
    val recurrenceRule: String = "NONE", // NONE, DAILY, WEEKLY, MONTHLY
    val exceptionDatesCsv: String = "", // yyyy-MM-dd
    val attendeesCsv: String = "",
    val rsvpStatus: String = RsvpStatus.ORGANIZER.name,
    val reminderMinutes: Int = 15,
    val invitationSendState: String = InvitationSendState.LOCAL_ONLY.name,
    val conferencingProvider: String = "AUREOM_MEET_MOCK",
    val conferencingJoinUrl: String? = null
)

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val fullName: String,
    val primaryEmail: String,
    val secondaryEmailsCsv: String = "",
    val phoneNumbersCsv: String = "",
    val organization: String = "",
    val jobTitle: String = "",
    val notes: String = "",
    val categoriesCsv: String = "",
    val isFavorite: Boolean = false,
    val isTrustedSavedContact: Boolean = true,
    val lastInteractionEpochMs: Long = 0L
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val listName: String = "Personal",
    val title: String,
    val notes: String = "",
    val dueEpochMs: Long? = null,
    val priority: String = TaskPriority.NORMAL.name,
    val reminderEpochMs: Long? = null,
    val isCompleted: Boolean = false,
    val completedEpochMs: Long? = null,
    val recurrenceRule: String = "NONE",
    val checklistSerialized: String = "", // newline-delimited "[ ] item" or "[x] item"
    val linkedMessageId: String? = null,
    val linkedEventId: String? = null,
    val isInMyDay: Boolean = false
)

@Entity(tableName = "rules")
data class RuleEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val name: String,
    val orderIndex: Int,
    val isEnabled: Boolean = true,
    val scope: String = RuleScope.APP_SIDE.name,
    val conditionField: String, // SENDER, RECIPIENT, SUBJECT, ACCOUNT
    val conditionValue: String,
    val actionType: String, // MOVE_FOLDER, APPLY_CATEGORY, MARK_READ, FLAG, NOTIFY, FORWARD_EXPLICIT
    val actionTarget: String,
    val stopProcessing: Boolean = false,
    val explicitForwardConfirmed: Boolean = false
)

@Entity(tableName = "outbox_operations")
data class OutboxOperationEntity(
    @PrimaryKey val id: String,
    val accountId: String,
    val operationType: String, // SEND_MESSAGE, MOVE_MESSAGE, MARK_READ, FLAG_MESSAGE, SEND_INVITE, SYNC_ACCOUNT
    val targetId: String,
    val payloadSummary: String,
    val idempotencyKey: String,
    val status: String = OutboxStatus.PENDING.name,
    val retryCount: Int = 0,
    val lastAttemptEpochMs: Long = 0L,
    val errorMessage: String? = null
)

@Entity(tableName = "saved_searches")
data class SavedSearchEntity(
    @PrimaryKey val id: String,
    val name: String,
    val query: String,
    val folderFilter: String = "ALL",
    val categoryFilter: String = "ALL",
    val hasAttachmentOnly: Boolean = false,
    val unreadOnly: Boolean = false
)

@Entity(tableName = "ai_action_logs")
data class AiActionLogEntity(
    @PrimaryKey val id: String,
    val timestampEpochMs: Long,
    val actionType: String,
    val promptSummary: String,
    val resultPreview: String,
    val sourceMessageIdsCsv: String,
    val status: String, // COMPLETED, CANCELLED, AWAITING_APPROVAL, REJECTED, ERROR
    val mode: String // FIREBASE_AI, LOCAL_MOCK
)
