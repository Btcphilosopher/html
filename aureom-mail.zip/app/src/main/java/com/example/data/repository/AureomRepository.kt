package com.example.data.repository

import com.example.ai.AiActionLogStatus
import com.example.data.local.AccountEntity
import com.example.data.local.AiActionLogEntity
import com.example.data.local.AttachmentEntity
import com.example.data.local.AureomDatabase
import com.example.data.local.CalendarEntity
import com.example.data.local.CalendarEventEntity
import com.example.data.local.ContactEntity
import com.example.data.local.DeliveryStatus
import com.example.data.local.DemoSeedData
import com.example.data.local.FolderEntity
import com.example.data.local.FolderSystemType
import com.example.data.local.InvitationSendState
import com.example.data.local.MessageEntity
import com.example.data.local.OutboxOperationEntity
import com.example.data.local.OutboxStatus
import com.example.data.local.RuleEntity
import com.example.data.local.SavedSearchEntity
import com.example.data.local.SyncHealth
import com.example.data.local.TaskEntity
import com.example.domain.AttachmentPolicy
import com.example.domain.CalendarMath
import com.example.domain.IcsCodec
import com.example.domain.ProviderAdapterFactory
import com.example.domain.RuleEngine
import com.example.domain.SubmitOutcome
import com.example.domain.SyncResult
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class AureomRepository(private val db: AureomDatabase) {
    private val accountDao = db.accountDao()
    private val folderDao = db.folderDao()
    private val messageDao = db.messageDao()
    private val attachmentDao = db.attachmentDao()
    private val calendarDao = db.calendarDao()
    private val contactDao = db.contactDao()
    private val taskDao = db.taskDao()
    private val ruleDao = db.ruleDao()
    private val outboxDao = db.outboxDao()
    private val searchAndAiDao = db.searchAndAiDao()

    val accounts: Flow<List<AccountEntity>> = accountDao.observeAll()
    val folders: Flow<List<FolderEntity>> = folderDao.observeAll()
    val messages: Flow<List<MessageEntity>> = messageDao.observeAll()
    val attachments: Flow<List<AttachmentEntity>> = attachmentDao.observeAll()
    val calendars: Flow<List<CalendarEntity>> = calendarDao.observeAllCalendars()
    val events: Flow<List<CalendarEventEntity>> = calendarDao.observeAllEvents()
    val contacts: Flow<List<ContactEntity>> = contactDao.observeAll()
    val tasks: Flow<List<TaskEntity>> = taskDao.observeAll()
    val rules: Flow<List<RuleEntity>> = ruleDao.observeAll()
    val outboxOperations: Flow<List<OutboxOperationEntity>> = outboxDao.observeAll()
    val savedSearches: Flow<List<SavedSearchEntity>> = searchAndAiDao.observeSavedSearches()
    val aiLogs: Flow<List<AiActionLogEntity>> = searchAndAiDao.observeAiLogs()

    suspend fun ensureSeeded() {
        if (accountDao.getAll().isNotEmpty()) return
        seedFreshDemoData()
    }

    suspend fun resetDemoData() {
        db.clearAllTables()
        seedFreshDemoData()
    }

    private suspend fun seedFreshDemoData() {
        val snap = DemoSeedData.createSeedSnapshot()
        accountDao.insertAll(snap.accounts)
        folderDao.insertAll(snap.folders)
        messageDao.insertAll(snap.messages)
        attachmentDao.insertAll(snap.attachments)
        calendarDao.insertAllCalendars(snap.calendars)
        calendarDao.insertAllEvents(snap.events)
        contactDao.insertAll(snap.contacts)
        taskDao.insertAll(snap.tasks)
        ruleDao.insertAll(snap.rules)
        searchAndAiDao.insertAllSavedSearches(snap.savedSearches)
        searchAndAiDao.insertAllAiLogs(snap.aiLogs)
    }

    suspend fun markRead(messageId: String, isRead: Boolean, isOffline: Boolean) {
        val msg = messageDao.getById(messageId) ?: return
        messageDao.upsert(msg.copy(isRead = isRead))
        if (isOffline) {
            queueOfflineOp(msg.accountId, "MARK_READ", msg.id, "Mark ${if (isRead) "read" else "unread"}: ${msg.subject}")
        }
    }

    suspend fun toggleFlag(messageId: String, followUpDueMs: Long? = null, isOffline: Boolean = false) {
        val msg = messageDao.getById(messageId) ?: return
        val newFlag = !msg.isFlagged
        messageDao.upsert(
            msg.copy(
                isFlagged = newFlag,
                followUpDueEpochMs = if (newFlag) (followUpDueMs ?: (System.currentTimeMillis() + 86_400_000L)) else null
            )
        )
        if (isOffline) {
            queueOfflineOp(msg.accountId, "FLAG_MESSAGE", msg.id, "Flag=${newFlag}: ${msg.subject}")
        }
    }

    suspend fun togglePin(messageId: String) {
        val msg = messageDao.getById(messageId) ?: return
        messageDao.upsert(msg.copy(isPinned = !msg.isPinned))
    }

    suspend fun snoozeMessage(messageId: String, untilEpochMs: Long?) {
        val msg = messageDao.getById(messageId) ?: return
        messageDao.upsert(msg.copy(snoozedUntilEpochMs = untilEpochMs))
    }

    suspend fun setRemoteImagesBlocked(messageId: String, blocked: Boolean) {
        val msg = messageDao.getById(messageId) ?: return
        messageDao.upsert(msg.copy(remoteImagesBlocked = blocked))
    }

    suspend fun addCategoryToMessage(messageId: String, category: String) {
        val msg = messageDao.getById(messageId) ?: return
        val existing = msg.categories.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (category !in existing) {
            messageDao.upsert(msg.copy(categories = (existing + category).joinToString(",")))
        }
    }

    suspend fun moveMessageToFolder(messageId: String, targetFolderId: String, isOffline: Boolean) {
        val msg = messageDao.getById(messageId) ?: return
        val account = accountDao.getById(msg.accountId) ?: return
        if (account.isSharedMailbox && !account.hasPermission("FILE")) {
            throw IllegalStateException("Delegated FILE permission is not granted on ${account.email}")
        }
        messageDao.upsert(msg.copy(folderId = targetFolderId))
        if (isOffline) {
            queueOfflineOp(msg.accountId, "MOVE_MESSAGE", msg.id, "Move '${msg.subject}' -> $targetFolderId")
        }
    }

    suspend fun moveMessageToSystemFolder(messageId: String, systemType: FolderSystemType, isOffline: Boolean) {
        val msg = messageDao.getById(messageId) ?: return
        val folders = folderDao.getByAccount(msg.accountId)
        val target = folders.firstOrNull { it.systemType == systemType.name } ?: return
        moveMessageToFolder(messageId, target.id, isOffline)
    }

    suspend fun updateSharedMailboxNote(messageId: String, note: String, owner: String?) {
        val msg = messageDao.getById(messageId) ?: return
        messageDao.upsert(msg.copy(internalNote = note, assignedOwner = owner))
    }

    suspend fun createCustomFolder(accountId: String, name: String, parentFolderId: String? = null) {
        val cleanName = name.trim()
        if (cleanName.isBlank()) return
        folderDao.upsert(
            FolderEntity(
                id = "fld_${UUID.randomUUID().toString().take(8)}",
                accountId = accountId,
                name = cleanName,
                parentFolderId = parentFolderId,
                systemType = FolderSystemType.CUSTOM.name
            )
        )
    }

    suspend fun saveDraft(draft: MessageEntity): MessageEntity {
        val folders = folderDao.getByAccount(draft.accountId)
        val draftsFolder = folders.firstOrNull { it.systemType == FolderSystemType.DRAFTS.name }
        val saved = draft.copy(
            folderId = draftsFolder?.id ?: draft.folderId,
            deliveryStatus = DeliveryStatus.DRAFT.name,
            timestampEpochMs = System.currentTimeMillis()
        )
        messageDao.upsert(saved)
        return saved
    }

    suspend fun attachDemoFile(
        messageId: String,
        accountId: String,
        fileName: String,
        mimeType: String,
        sizeBytes: Long
    ): String {
        val check = AttachmentPolicy.validate(fileName, sizeBytes)
        if (!check.allowed) {
            return check.reason
        }
        attachmentDao.upsert(
            AttachmentEntity(
                id = "att_${UUID.randomUUID().toString().take(8)}",
                messageId = messageId,
                accountId = accountId,
                fileName = fileName,
                mimeType = mimeType,
                sizeBytes = sizeBytes,
                localCachedPath = "cache/${fileName}",
                scanStatus = check.scanStatus.name,
                createdEpochMs = System.currentTimeMillis()
            )
        )
        return "Attached $fileName (${check.reason})"
    }

    suspend fun queueOrSendMessage(
        draft: MessageEntity,
        delayWindowSeconds: Int,
        scheduledEpochMs: Long?,
        isOffline: Boolean,
        simulateUncertain: Boolean = false
    ): MessageEntity {
        val idempotencyKey = draft.idempotencyKey ?: "idem_${UUID.randomUUID().toString().take(12)}"
        val existing = messageDao.findByIdempotencyKey(idempotencyKey)
        if (RuleEngine.isDuplicateSend(existing)) {
            return existing!!
        }

        val account = accountDao.getById(draft.accountId)
            ?: throw IllegalStateException("Sending account not found.")
        if (account.isSharedMailbox && !account.hasPermission("SEND_AS") && !account.hasPermission("REPLY")) {
            throw IllegalStateException("Delegated SEND_AS/REPLY permission denied for ${account.email}")
        }

        val folders = folderDao.getByAccount(draft.accountId)
        val sentFolder = folders.firstOrNull { it.systemType == FolderSystemType.SENT.name }
        val draftsFolder = folders.firstOrNull { it.systemType == FolderSystemType.DRAFTS.name }
        val now = System.currentTimeMillis()

        if (isOffline) {
            val queued = draft.copy(
                folderId = draftsFolder?.id ?: draft.folderId,
                deliveryStatus = DeliveryStatus.QUEUED_OFFLINE.name,
                scheduledSendEpochMs = scheduledEpochMs,
                timestampEpochMs = now,
                idempotencyKey = idempotencyKey
            )
            messageDao.upsert(queued)
            queueOfflineOp(
                accountId = draft.accountId,
                type = "SEND_MESSAGE",
                targetId = queued.id,
                summary = "Send '${queued.subject}' to ${queued.toRecipients}",
                idempotencyKey = idempotencyKey
            )
            return queued
        }

        if (scheduledEpochMs != null && scheduledEpochMs > now) {
            val scheduled = draft.copy(
                folderId = draftsFolder?.id ?: draft.folderId,
                deliveryStatus = DeliveryStatus.DELAYED_SEND.name,
                scheduledSendEpochMs = scheduledEpochMs,
                delayedSendCancelUntilEpochMs = scheduledEpochMs,
                timestampEpochMs = now,
                idempotencyKey = idempotencyKey
            )
            messageDao.upsert(scheduled)
            return scheduled
        }

        if (delayWindowSeconds > 0) {
            val delayed = draft.copy(
                folderId = draftsFolder?.id ?: draft.folderId,
                deliveryStatus = DeliveryStatus.DELAYED_SEND.name,
                delayedSendCancelUntilEpochMs = now + delayWindowSeconds * 1000L,
                timestampEpochMs = now,
                idempotencyKey = idempotencyKey
            )
            messageDao.upsert(delayed)
            return delayed
        }

        return finalizeSubmission(draft.copy(idempotencyKey = idempotencyKey), account, sentFolder?.id, simulateUncertain)
    }

    suspend fun finalizeDelayedSendIfNotCancelled(messageId: String, simulateUncertain: Boolean = false): MessageEntity? {
        val msg = messageDao.getById(messageId) ?: return null
        if (msg.deliveryStatus != DeliveryStatus.DELAYED_SEND.name) return msg
        val account = accountDao.getById(msg.accountId) ?: return msg
        val sentFolder = folderDao.getByAccount(msg.accountId).firstOrNull { it.systemType == FolderSystemType.SENT.name }
        return finalizeSubmission(msg, account, sentFolder?.id, simulateUncertain)
    }

    suspend fun cancelDelayedSend(messageId: String): Boolean {
        val msg = messageDao.getById(messageId) ?: return false
        val now = System.currentTimeMillis()
        if (!RuleEngine.canCancelDelayedSend(msg, now)) return false
        val draftsFolder = folderDao.getByAccount(msg.accountId).firstOrNull { it.systemType == FolderSystemType.DRAFTS.name }
        messageDao.upsert(
            msg.copy(
                folderId = draftsFolder?.id ?: msg.folderId,
                deliveryStatus = DeliveryStatus.DRAFT.name,
                delayedSendCancelUntilEpochMs = null,
                scheduledSendEpochMs = null
            )
        )
        return true
    }

    private suspend fun finalizeSubmission(
        msg: MessageEntity,
        account: AccountEntity,
        sentFolderId: String?,
        simulateUncertain: Boolean
    ): MessageEntity {
        val adapter = ProviderAdapterFactory.forAccount(account)
        return when (val outcome = adapter.submitMessage(account, msg, simulateUncertain)) {
            is SubmitOutcome.Submitted -> {
                val sent = msg.copy(
                    folderId = sentFolderId ?: msg.folderId,
                    deliveryStatus = DeliveryStatus.SUBMITTED.name,
                    delayedSendCancelUntilEpochMs = null,
                    timestampEpochMs = System.currentTimeMillis()
                )
                messageDao.upsert(sent)
                sent
            }
            is SubmitOutcome.UncertainOutcome -> {
                val uncertain = msg.copy(
                    deliveryStatus = DeliveryStatus.UNCERTAIN.name,
                    delayedSendCancelUntilEpochMs = null
                )
                messageDao.upsert(uncertain)
                outboxDao.upsert(
                    OutboxOperationEntity(
                        id = "obx_${UUID.randomUUID().toString().take(8)}",
                        accountId = account.id,
                        operationType = "SEND_MESSAGE",
                        targetId = uncertain.id,
                        payloadSummary = "Uncertain submission: ${uncertain.subject}",
                        idempotencyKey = uncertain.idempotencyKey ?: uncertain.id,
                        status = OutboxStatus.UNCERTAIN_OUTCOME.name,
                        retryCount = 1,
                        lastAttemptEpochMs = System.currentTimeMillis(),
                        errorMessage = outcome.reason
                    )
                )
                uncertain
            }
            is SubmitOutcome.Failed -> {
                val failed = msg.copy(deliveryStatus = DeliveryStatus.FAILED.name)
                messageDao.upsert(failed)
                failed
            }
        }
    }

    suspend fun syncAccount(accountId: String, recoverUidValidity: Boolean = false, isOffline: Boolean = false): String {
        val account = accountDao.getById(accountId) ?: return "Account not found."
        if (isOffline) {
            accountDao.upsert(account.copy(syncHealth = SyncHealth.OFFLINE_PAUSED.name))
            return "Offline: sync paused for ${account.displayName}."
        }

        val workingAccount = if (recoverUidValidity) {
            account.copy(
                syncHealth = SyncHealth.SYNCING.name,
                imapUidValidity = 4899L,
                syncErrorMessage = null
            )
        } else {
            account.copy(syncHealth = SyncHealth.SYNCING.name)
        }
        accountDao.upsert(workingAccount)

        val folders = folderDao.getByAccount(accountId)
        val inbox = folders.firstOrNull { it.systemType == FolderSystemType.INBOX.name }
        val adapter = ProviderAdapterFactory.forAccount(workingAccount)
        return when (val res = adapter.syncIncremental(workingAccount, inbox, null)) {
            is SyncResult.Success -> {
                val rules = ruleDao.getEnabledOrdered()
                for (m in res.fetchedMessages) {
                    val ruled = RuleEngine.applyRules(m, rules, folders)
                    messageDao.upsert(ruled.updatedMessage)
                }
                accountDao.upsert(
                    workingAccount.copy(
                        syncHealth = SyncHealth.SYNCED.name,
                        lastSyncEpochMs = System.currentTimeMillis(),
                        syncErrorMessage = null,
                        imapUidValidity = res.newUidValidity ?: workingAccount.imapUidValidity,
                        imapLastUid = res.lastUid ?: workingAccount.imapLastUid,
                        rateLimitRemaining = res.rateLimitRemaining
                    )
                )
                "Synced ${workingAccount.displayName}: ${res.fetchedMessages.size} new message(s)."
            }
            is SyncResult.UidValidityResetRequired -> {
                accountDao.upsert(
                    workingAccount.copy(
                        syncHealth = SyncHealth.FAILED.name,
                        syncErrorMessage = res.message
                    )
                )
                res.message
            }
            is SyncResult.Failure -> {
                accountDao.upsert(
                    workingAccount.copy(
                        syncHealth = SyncHealth.FAILED.name,
                        syncErrorMessage = res.reason
                    )
                )
                res.reason
            }
        }
    }

    suspend fun reconcileOutboxWhenOnline(): Int {
        val pending = outboxDao.getPendingOrFailed()
        var processed = 0
        for (op in pending) {
            if (op.status == OutboxStatus.UNCERTAIN_OUTCOME.name) {
                // Do not auto-resend uncertain submissions! Require explicit user check.
                continue
            }
            if (op.operationType == "SEND_MESSAGE") {
                val msg = messageDao.getById(op.targetId)
                val acc = accountDao.getById(op.accountId)
                if (msg != null && acc != null) {
                    val sentFolder = folderDao.getByAccount(acc.id).firstOrNull { it.systemType == FolderSystemType.SENT.name }
                    finalizeSubmission(msg, acc, sentFolder?.id, simulateUncertain = false)
                }
            }
            outboxDao.upsert(
                op.copy(
                    status = OutboxStatus.COMPLETED.name,
                    lastAttemptEpochMs = System.currentTimeMillis()
                )
            )
            processed++
        }
        return processed
    }

    suspend fun resolveUncertainOutbox(opId: String, markAsAlreadyDelivered: Boolean) {
        val pending = outboxDao.getPendingOrFailed().firstOrNull { it.id == opId } ?: return
        val msg = messageDao.getById(pending.targetId)
        if (markAsAlreadyDelivered) {
            if (msg != null) {
                val sentFolder = folderDao.getByAccount(msg.accountId).firstOrNull { it.systemType == FolderSystemType.SENT.name }
                messageDao.upsert(
                    msg.copy(
                        folderId = sentFolder?.id ?: msg.folderId,
                        deliveryStatus = DeliveryStatus.SUBMITTED.name
                    )
                )
            }
            outboxDao.upsert(pending.copy(status = OutboxStatus.COMPLETED.name, errorMessage = "Confirmed delivered by user reconciliation."))
        } else {
            // Re-submit cleanly with new idempotency key
            if (msg != null) {
                val fresh = msg.copy(idempotencyKey = "idem_${UUID.randomUUID().toString().take(12)}")
                val acc = accountDao.getById(msg.accountId)
                if (acc != null) {
                    val sentFolder = folderDao.getByAccount(acc.id).firstOrNull { it.systemType == FolderSystemType.SENT.name }
                    finalizeSubmission(fresh, acc, sentFolder?.id, simulateUncertain = false)
                }
            }
            outboxDao.upsert(pending.copy(status = OutboxStatus.COMPLETED.name))
        }
    }

    private suspend fun queueOfflineOp(
        accountId: String,
        type: String,
        targetId: String,
        summary: String,
        idempotencyKey: String = "idem_${UUID.randomUUID().toString().take(10)}"
    ) {
        val existing = outboxDao.findByIdempotencyKey(idempotencyKey)
        if (existing != null) return
        outboxDao.upsert(
            OutboxOperationEntity(
                id = "obx_${UUID.randomUUID().toString().take(8)}",
                accountId = accountId,
                operationType = type,
                targetId = targetId,
                payloadSummary = summary,
                idempotencyKey = idempotencyKey,
                status = OutboxStatus.PENDING.name,
                lastAttemptEpochMs = System.currentTimeMillis()
            )
        )
    }

    // Search (permission-scoped via DAO query where isSearchIndexedForUser = 1)
    suspend fun searchMessages(query: String): List<MessageEntity> {
        if (query.isBlank()) return emptyList()
        return messageDao.searchAuthorizedMessages(query.trim())
    }

    suspend fun saveSearch(search: SavedSearchEntity) = searchAndAiDao.upsertSavedSearch(search)
    suspend fun deleteSavedSearch(id: String) = searchAndAiDao.deleteSavedSearch(id)

    // Calendar operations
    suspend fun upsertCalendarEvent(event: CalendarEventEntity) = calendarDao.upsertEvent(event)
    suspend fun updateRsvp(eventId: String, status: String) {
        val evt = calendarDao.getEventById(eventId) ?: return
        calendarDao.upsertEvent(evt.copy(rsvpStatus = status))
    }

    suspend fun editSingleRecurringOccurrence(
        masterEventId: String,
        occurrenceStartMs: Long,
        newTitle: String,
        newStartMs: Long,
        newEndMs: Long,
        newLocation: String
    ) {
        val master = calendarDao.getEventById(masterEventId) ?: return
        val (updatedMaster, overrideEvent) = CalendarMath.createSingleOccurrenceException(
            seriesMaster = master,
            occurrenceStartMs = occurrenceStartMs,
            newTitle = newTitle,
            newStartMs = newStartMs,
            newEndMs = newEndMs,
            newLocation = newLocation
        )
        calendarDao.upsertEvent(updatedMaster)
        calendarDao.upsertEvent(overrideEvent)
    }

    suspend fun importIcsText(icsText: String, calendarId: String, accountId: String): Int {
        val imported = IcsCodec.importIcs(icsText, calendarId, accountId)
        calendarDao.insertAllEvents(imported)
        return imported.size
    }

    // Contacts & Duplicate Merging
    suspend fun upsertContact(contact: ContactEntity) = contactDao.upsert(contact)
    suspend fun toggleContactFavorite(contactId: String) {
        val c = contactDao.getById(contactId) ?: return
        contactDao.upsert(c.copy(isFavorite = !c.isFavorite))
    }

    suspend fun promoteToTrustedContact(contactId: String) {
        val c = contactDao.getById(contactId) ?: return
        contactDao.upsert(c.copy(isTrustedSavedContact = true))
    }

    suspend fun mergeContacts(primaryId: String, duplicateId: String) {
        val primary = contactDao.getById(primaryId) ?: return
        val dup = contactDao.getById(duplicateId) ?: return
        val secondaryEmails = (primary.secondaryEmailsCsv.split(",") + dup.primaryEmail + dup.secondaryEmailsCsv.split(","))
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.equals(primary.primaryEmail, ignoreCase = true) }
            .distinct()
            .joinToString(",")
        val phones = (primary.phoneNumbersCsv.split(",") + dup.phoneNumbersCsv.split(","))
            .map { it.trim() }.filter { it.isNotEmpty() }.distinct().joinToString(",")
        val categories = (primary.categoriesCsv.split(",") + dup.categoriesCsv.split(","))
            .map { it.trim() }.filter { it.isNotEmpty() }.distinct().joinToString(",")
        val combinedNotes = listOf(primary.notes, dup.notes).filter { it.isNotBlank() }.distinct().joinToString("\n")

        contactDao.upsert(
            primary.copy(
                secondaryEmailsCsv = secondaryEmails,
                phoneNumbersCsv = phones,
                categoriesCsv = categories,
                notes = combinedNotes,
                organization = primary.organization.ifBlank { dup.organization },
                jobTitle = primary.jobTitle.ifBlank { dup.jobTitle },
                isTrustedSavedContact = true
            )
        )
        contactDao.deleteById(dup.id)
    }

    // Tasks
    suspend fun upsertTask(task: TaskEntity) = taskDao.upsert(task)
    suspend fun toggleTaskComplete(taskId: String) {
        val t = taskDao.getById(taskId) ?: return
        val nowDone = !t.isCompleted
        taskDao.upsert(
            t.copy(
                isCompleted = nowDone,
                completedEpochMs = if (nowDone) System.currentTimeMillis() else null
            )
        )
    }

    suspend fun toggleTaskMyDay(taskId: String) {
        val t = taskDao.getById(taskId) ?: return
        taskDao.upsert(t.copy(isInMyDay = !t.isInMyDay))
    }

    suspend fun toggleChecklistItem(taskId: String, lineIndex: Int) {
        val t = taskDao.getById(taskId) ?: return
        val lines = t.checklistSerialized.lines().toMutableList()
        if (lineIndex in lines.indices) {
            val line = lines[lineIndex]
            lines[lineIndex] = when {
                line.startsWith("[x] ") -> "[ ] " + line.removePrefix("[x] ")
                line.startsWith("[ ] ") -> "[x] " + line.removePrefix("[ ] ")
                else -> line
            }
            taskDao.upsert(t.copy(checklistSerialized = lines.joinToString("\n")))
        }
    }

    suspend fun createTaskFromMessage(message: MessageEntity, listName: String = "Follow-Ups") {
        taskDao.upsert(
            TaskEntity(
                id = "tsk_${UUID.randomUUID().toString().take(8)}",
                accountId = message.accountId,
                listName = listName,
                title = "Follow up: ${message.subject}",
                notes = "Linked from ${message.senderName} <${message.senderEmail}>\n${message.snippet}",
                dueEpochMs = System.currentTimeMillis() + 86_400_000L,
                linkedMessageId = message.id,
                isInMyDay = true
            )
        )
    }

    // Rules
    suspend fun upsertRule(rule: RuleEntity) = ruleDao.upsert(rule)
    suspend fun deleteRule(id: String) = ruleDao.deleteById(id)

    // Retention & Cache Management
    suspend fun purgeCacheOlderThan(days: Int) {
        val cutoff = System.currentTimeMillis() - days.toLong() * 86_400_000L
        messageDao.purgeOlderThan(cutoff)
    }

    suspend fun removeLocalAccountCopy(accountId: String) {
        messageDao.deleteByAccount(accountId)
        folderDao.deleteByAccount(accountId)
        attachmentDao.deleteByAccount(accountId)
        calendarDao.deleteEventsByAccount(accountId)
        calendarDao.deleteCalendarsByAccount(accountId)
        accountDao.deleteById(accountId)
    }

    // AI Action Logging
    suspend fun logAiAction(
        actionType: String,
        promptSummary: String,
        resultPreview: String,
        sourceIds: List<String>,
        status: AiActionLogStatus,
        mode: String
    ) {
        searchAndAiDao.upsertAiLog(
            AiActionLogEntity(
                id = "ai_${UUID.randomUUID().toString().take(8)}",
                timestampEpochMs = System.currentTimeMillis(),
                actionType = actionType,
                promptSummary = promptSummary,
                resultPreview = resultPreview,
                sourceMessageIdsCsv = sourceIds.joinToString(","),
                status = status.name,
                mode = mode
            )
        )
    }
}
