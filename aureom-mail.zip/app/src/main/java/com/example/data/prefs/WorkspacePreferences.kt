package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.DensityMode
import com.example.ui.theme.ReadingPanePosition
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "aureom_workspace_prefs")

data class WorkspaceSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val densityMode: DensityMode = DensityMode.COMFORTABLE,
    val readingPanePosition: ReadingPanePosition = ReadingPanePosition.RIGHT,
    val showCalendarSidebar: Boolean = true,
    val conversationGrouping: Boolean = true,
    val delayedSendSeconds: Int = 8,
    val isOfflineMode: Boolean = false,
    val remoteImagesBlockedByDefault: Boolean = true,
    val retentionDays: Int = 90,
    val aiMockMode: Boolean = false,
    val aiDailyBudgetLimit: Int = 40,
    val aiDailyUsedCount: Int = 3,
    val reducedMotion: Boolean = false,
    val selectedAccountId: String = "UNIFIED",
    val selectedFolderSystemType: String = "INBOX"
)

class WorkspacePreferences(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DENSITY_MODE = stringPreferencesKey("density_mode")
        val READING_PANE = stringPreferencesKey("reading_pane")
        val SHOW_CALENDAR_SIDEBAR = booleanPreferencesKey("show_calendar_sidebar")
        val CONVERSATION_GROUPING = booleanPreferencesKey("conversation_grouping")
        val DELAYED_SEND_SECONDS = intPreferencesKey("delayed_send_seconds")
        val OFFLINE_MODE = booleanPreferencesKey("offline_mode")
        val REMOTE_IMAGES_BLOCKED = booleanPreferencesKey("remote_images_blocked")
        val RETENTION_DAYS = intPreferencesKey("retention_days")
        val AI_MOCK_MODE = booleanPreferencesKey("ai_mock_mode")
        val AI_BUDGET_LIMIT = intPreferencesKey("ai_budget_limit")
        val AI_USED_COUNT = intPreferencesKey("ai_used_count")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val SELECTED_ACCOUNT = stringPreferencesKey("selected_account")
        val SELECTED_FOLDER_TYPE = stringPreferencesKey("selected_folder_type")
    }

    val settingsFlow: Flow<WorkspaceSettings> = context.dataStore.data.map { prefs ->
        WorkspaceSettings(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            densityMode = prefs[Keys.DENSITY_MODE]?.let { runCatching { DensityMode.valueOf(it) }.getOrNull() }
                ?: DensityMode.COMFORTABLE,
            readingPanePosition = prefs[Keys.READING_PANE]?.let { runCatching { ReadingPanePosition.valueOf(it) }.getOrNull() }
                ?: ReadingPanePosition.RIGHT,
            showCalendarSidebar = prefs[Keys.SHOW_CALENDAR_SIDEBAR] ?: true,
            conversationGrouping = prefs[Keys.CONVERSATION_GROUPING] ?: true,
            delayedSendSeconds = prefs[Keys.DELAYED_SEND_SECONDS] ?: 8,
            isOfflineMode = prefs[Keys.OFFLINE_MODE] ?: false,
            remoteImagesBlockedByDefault = prefs[Keys.REMOTE_IMAGES_BLOCKED] ?: true,
            retentionDays = prefs[Keys.RETENTION_DAYS] ?: 90,
            aiMockMode = prefs[Keys.AI_MOCK_MODE] ?: false,
            aiDailyBudgetLimit = prefs[Keys.AI_BUDGET_LIMIT] ?: 40,
            aiDailyUsedCount = prefs[Keys.AI_USED_COUNT] ?: 3,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false,
            selectedAccountId = prefs[Keys.SELECTED_ACCOUNT] ?: "UNIFIED",
            selectedFolderSystemType = prefs[Keys.SELECTED_FOLDER_TYPE] ?: "INBOX"
        )
    }

    suspend fun updateThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun updateDensityMode(mode: DensityMode) {
        context.dataStore.edit { it[Keys.DENSITY_MODE] = mode.name }
    }

    suspend fun updateReadingPanePosition(position: ReadingPanePosition) {
        context.dataStore.edit { it[Keys.READING_PANE] = position.name }
    }

    suspend fun setShowCalendarSidebar(show: Boolean) {
        context.dataStore.edit { it[Keys.SHOW_CALENDAR_SIDEBAR] = show }
    }

    suspend fun setConversationGrouping(enabled: Boolean) {
        context.dataStore.edit { it[Keys.CONVERSATION_GROUPING] = enabled }
    }

    suspend fun setDelayedSendSeconds(seconds: Int) {
        context.dataStore.edit { it[Keys.DELAYED_SEND_SECONDS] = seconds.coerceIn(0, 30) }
    }

    suspend fun setOfflineMode(offline: Boolean) {
        context.dataStore.edit { it[Keys.OFFLINE_MODE] = offline }
    }

    suspend fun setRemoteImagesBlockedByDefault(blocked: Boolean) {
        context.dataStore.edit { it[Keys.REMOTE_IMAGES_BLOCKED] = blocked }
    }

    suspend fun setRetentionDays(days: Int) {
        context.dataStore.edit { it[Keys.RETENTION_DAYS] = days }
    }

    suspend fun setAiMockMode(mock: Boolean) {
        context.dataStore.edit { it[Keys.AI_MOCK_MODE] = mock }
    }

    suspend fun incrementAiUsage() {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.AI_USED_COUNT] ?: 3
            prefs[Keys.AI_USED_COUNT] = current + 1
        }
    }

    suspend fun setReducedMotion(reduced: Boolean) {
        context.dataStore.edit { it[Keys.REDUCED_MOTION] = reduced }
    }

    suspend fun setSelectedAccount(accountId: String) {
        context.dataStore.edit { it[Keys.SELECTED_ACCOUNT] = accountId }
    }

    suspend fun setSelectedFolderType(systemType: String) {
        context.dataStore.edit { it[Keys.SELECTED_FOLDER_TYPE] = systemType }
    }
}
