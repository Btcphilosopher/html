package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY isSharedMailbox ASC, displayName ASC")
    fun observeAll(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts")
    suspend fun getAll(): List<AccountEntity>

    @Query("SELECT * FROM accounts WHERE id = :id")
    suspend fun getById(id: String): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(accounts: List<AccountEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(account: AccountEntity)

    @Query("DELETE FROM accounts WHERE id = :accountId")
    suspend fun deleteById(accountId: String)
}

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders ORDER BY systemType ASC, name ASC")
    fun observeAll(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders WHERE accountId = :accountId")
    suspend fun getByAccount(accountId: String): List<FolderEntity>

    @Query("SELECT * FROM folders WHERE id = :folderId")
    suspend fun getById(folderId: String): FolderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(folders: List<FolderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(folder: FolderEntity)

    @Query("DELETE FROM folders WHERE accountId = :accountId")
    suspend fun deleteByAccount(accountId: String)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY isPinned DESC, timestampEpochMs DESC")
    fun observeAll(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun getById(id: String): MessageEntity?

    @Query("SELECT * FROM messages WHERE threadId = :threadId ORDER BY timestampEpochMs ASC")
    suspend fun getByThreadId(threadId: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE idempotencyKey = :key LIMIT 1")
    suspend fun findByIdempotencyKey(key: String): MessageEntity?

    @Query("""
        SELECT m.* FROM messages m
        INNER JOIN accounts a ON m.accountId = a.id
        WHERE a.isSearchIndexedForUser = 1
          AND (
            m.subject LIKE '%' || :query || '%'
            OR m.bodyPlainText LIKE '%' || :query || '%'
            OR m.senderName LIKE '%' || :query || '%'
            OR m.senderEmail LIKE '%' || :query || '%'
            OR m.toRecipients LIKE '%' || :query || '%'
            OR m.categories LIKE '%' || :query || '%'
          )
        ORDER BY m.timestampEpochMs DESC
    """)
    suspend fun searchAuthorizedMessages(query: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(messages: List<MessageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(message: MessageEntity)

    @Update
    suspend fun update(message: MessageEntity)

    @Query("DELETE FROM messages WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("DELETE FROM messages WHERE accountId = :accountId")
    suspend fun deleteByAccount(accountId: String)

    @Query("DELETE FROM messages WHERE timestampEpochMs < :cutoffEpochMs AND deliveryStatus = 'RECEIVED'")
    suspend fun purgeOlderThan(cutoffEpochMs: Long)
}

@Dao
interface AttachmentDao {
    @Query("SELECT * FROM attachments ORDER BY createdEpochMs DESC")
    fun observeAll(): Flow<List<AttachmentEntity>>

    @Query("SELECT * FROM attachments WHERE messageId = :messageId")
    suspend fun getByMessage(messageId: String): List<AttachmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(attachments: List<AttachmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(attachment: AttachmentEntity)

    @Query("DELETE FROM attachments WHERE accountId = :accountId")
    suspend fun deleteByAccount(accountId: String)
}

@Dao
interface CalendarDao {
    @Query("SELECT * FROM calendars ORDER BY isPrimary DESC, name ASC")
    fun observeAllCalendars(): Flow<List<CalendarEntity>>

    @Query("SELECT * FROM calendar_events ORDER BY startEpochMs ASC")
    fun observeAllEvents(): Flow<List<CalendarEventEntity>>

    @Query("SELECT * FROM calendar_events WHERE id = :id")
    suspend fun getEventById(id: String): CalendarEventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCalendars(calendars: List<CalendarEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCalendar(calendar: CalendarEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllEvents(events: List<CalendarEventEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEvent(event: CalendarEventEntity)

    @Query("DELETE FROM calendar_events WHERE id = :id")
    suspend fun deleteEventById(id: String)

    @Query("DELETE FROM calendars WHERE accountId = :accountId")
    suspend fun deleteCalendarsByAccount(accountId: String)

    @Query("DELETE FROM calendar_events WHERE accountId = :accountId")
    suspend fun deleteEventsByAccount(accountId: String)
}

@Dao
interface ContactDao {
    @Query("SELECT * FROM contacts ORDER BY isFavorite DESC, isTrustedSavedContact DESC, fullName ASC")
    fun observeAll(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE id = :id")
    suspend fun getById(id: String): ContactEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(contacts: List<ContactEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(contact: ContactEntity)

    @Query("DELETE FROM contacts WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, isInMyDay DESC, priority ASC, dueEpochMs ASC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: String): TaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tasks: List<TaskEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface RuleDao {
    @Query("SELECT * FROM rules ORDER BY orderIndex ASC")
    fun observeAll(): Flow<List<RuleEntity>>

    @Query("SELECT * FROM rules WHERE isEnabled = 1 ORDER BY orderIndex ASC")
    suspend fun getEnabledOrdered(): List<RuleEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rules: List<RuleEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: RuleEntity)

    @Query("DELETE FROM rules WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface OutboxDao {
    @Query("SELECT * FROM outbox_operations ORDER BY lastAttemptEpochMs DESC")
    fun observeAll(): Flow<List<OutboxOperationEntity>>

    @Query("SELECT * FROM outbox_operations WHERE status IN ('PENDING', 'FAILED', 'UNCERTAIN_OUTCOME')")
    suspend fun getPendingOrFailed(): List<OutboxOperationEntity>

    @Query("SELECT * FROM outbox_operations WHERE idempotencyKey = :key LIMIT 1")
    suspend fun findByIdempotencyKey(key: String): OutboxOperationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(op: OutboxOperationEntity)

    @Query("DELETE FROM outbox_operations WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface SearchAndAiDao {
    @Query("SELECT * FROM saved_searches ORDER BY name ASC")
    fun observeSavedSearches(): Flow<List<SavedSearchEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSavedSearches(searches: List<SavedSearchEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSavedSearch(search: SavedSearchEntity)

    @Query("DELETE FROM saved_searches WHERE id = :id")
    suspend fun deleteSavedSearch(id: String)

    @Query("SELECT * FROM ai_action_logs ORDER BY timestampEpochMs DESC LIMIT 50")
    fun observeAiLogs(): Flow<List<AiActionLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAiLogs(logs: List<AiActionLogEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAiLog(log: AiActionLogEntity)
}
