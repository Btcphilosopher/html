package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        AccountEntity::class,
        FolderEntity::class,
        MessageEntity::class,
        AttachmentEntity::class,
        CalendarEntity::class,
        CalendarEventEntity::class,
        ContactEntity::class,
        TaskEntity::class,
        RuleEntity::class,
        OutboxOperationEntity::class,
        SavedSearchEntity::class,
        AiActionLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AureomDatabase : RoomDatabase() {
    abstract fun accountDao(): AccountDao
    abstract fun folderDao(): FolderDao
    abstract fun messageDao(): MessageDao
    abstract fun attachmentDao(): AttachmentDao
    abstract fun calendarDao(): CalendarDao
    abstract fun contactDao(): ContactDao
    abstract fun taskDao(): TaskDao
    abstract fun ruleDao(): RuleDao
    abstract fun outboxDao(): OutboxDao
    abstract fun searchAndAiDao(): SearchAndAiDao

    companion object {
        @Volatile
        private var INSTANCE: AureomDatabase? = null

        fun getInstance(context: Context): AureomDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AureomDatabase::class.java,
                    "aureom_mail.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
