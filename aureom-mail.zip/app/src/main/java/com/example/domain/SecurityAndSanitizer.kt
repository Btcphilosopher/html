package com.example.domain

import com.example.data.local.AuthResult
import com.example.data.local.MessageEntity
import com.example.data.local.ScanStatus

data class SanitizedHtmlResult(
    val safeHtml: String,
    val plainText: String,
    val blockedRemoteImageCount: Int,
    val strippedDangerousTagsCount: Int,
    val safeLinks: List<SafeLinkInfo>
)

data class SafeLinkInfo(
    val url: String,
    val host: String,
    val isHttpInsecure: Boolean
)

data class SenderSecurityWarning(
    val hasReplyToMismatch: Boolean,
    val replyToEmail: String?,
    val hasAuthFailure: Boolean,
    val summary: String
)

data class AttachmentValidationResult(
    val allowed: Boolean,
    val reason: String,
    val scanStatus: ScanStatus
)

object HtmlSanitizer {
    private val dangerousTagRegex = Regex(
        "<(script|iframe|object|embed|applet|form|meta|link|base)\\b[^>]*>([\\s\\S]*?</\\1>)?",
        setOf(RegexOption.IGNORE_CASE)
    )
    private val selfClosingDangerousRegex = Regex(
        "<(script|iframe|object|embed|applet|meta|link|base)\\b[^>]*/?>",
        setOf(RegexOption.IGNORE_CASE)
    )
    private val inlineHandlerRegex = Regex(
        "\\son[a-zA-Z]+\\s*=\\s*(\"[^\"]*\"|'[^']*'|[^\\s>]+)",
        setOf(RegexOption.IGNORE_CASE)
    )
    private val jsUriRegex = Regex(
        "(href|src|action)\\s*=\\s*([\"'])\\s*(javascript|vbscript|data:text/html):[^\"']*\\2",
        setOf(RegexOption.IGNORE_CASE)
    )
    private val remoteImgRegex = Regex(
        "<img\\b[^>]*\\bsrc\\s*=\\s*([\"'])(https?://[^\"']+)\\1[^>]*/?>",
        setOf(RegexOption.IGNORE_CASE)
    )
    private val anchorRegex = Regex(
        "<a\\b[^>]*\\bhref\\s*=\\s*([\"'])(https?://[^\"']+)\\1[^>]*>",
        setOf(RegexOption.IGNORE_CASE)
    )
    private val htmlTagRegex = Regex("<[^>]+>")

    fun sanitize(rawHtml: String, blockRemoteImages: Boolean): SanitizedHtmlResult {
        var working = rawHtml
        var strippedCount = 0

        val tagMatches = dangerousTagRegex.findAll(working).count()
        strippedCount += tagMatches
        working = dangerousTagRegex.replace(working, "")

        val selfClosingMatches = selfClosingDangerousRegex.findAll(working).count()
        strippedCount += selfClosingMatches
        working = selfClosingDangerousRegex.replace(working, "")

        val handlerMatches = inlineHandlerRegex.findAll(working).count()
        strippedCount += handlerMatches
        working = inlineHandlerRegex.replace(working, "")

        val jsMatches = jsUriRegex.findAll(working).count()
        strippedCount += jsMatches
        working = jsUriRegex.replace(working, "$1=\"#blocked\"")

        var blockedImages = 0
        if (blockRemoteImages) {
            blockedImages = remoteImgRegex.findAll(working).count()
            working = remoteImgRegex.replace(working) {
                "[Blocked remote image]"
            }
        }

        val links = anchorRegex.findAll(working).map { match ->
            val url = match.groupValues[2]
            val host = url.substringAfter("://").substringBefore("/").substringBefore("?")
            SafeLinkInfo(
                url = url,
                host = host,
                isHttpInsecure = url.startsWith("http://", ignoreCase = true)
            )
        }.toList()

        val plainText = working
            .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("</(p|div|li|tr|h[1-6])>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("<li\\b[^>]*>", RegexOption.IGNORE_CASE), "• ")
            .let { htmlTagRegex.replace(it, "") }
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()

        return SanitizedHtmlResult(
            safeHtml = working.trim(),
            plainText = plainText,
            blockedRemoteImageCount = blockedImages,
            strippedDangerousTagsCount = strippedCount,
            safeLinks = links
        )
    }
}

object SenderSecurityAnalyzer {
    fun analyze(message: MessageEntity): SenderSecurityWarning? {
        val replyTo = message.replyToEmail?.takeIf { it.isNotBlank() }
        val mismatch = replyTo != null && !replyTo.equals(message.senderEmail, ignoreCase = true)
        val authFail = message.authSpf == AuthResult.FAIL.name ||
            message.authDkim == AuthResult.FAIL.name ||
            message.authDmarc == AuthResult.FAIL.name

        if (!mismatch && !authFail) return null

        val parts = buildList {
            if (mismatch) {
                add("Reply-To ($replyTo) differs from Sender (${message.senderEmail})")
            }
            if (authFail) {
                add("Provider auth failed: SPF=${message.authSpf}, DKIM=${message.authDkim}, DMARC=${message.authDmarc}")
            }
        }

        return SenderSecurityWarning(
            hasReplyToMismatch = mismatch,
            replyToEmail = replyTo,
            hasAuthFailure = authFail,
            summary = parts.joinToString(" · ")
        )
    }
}

object AttachmentPolicy {
    private const val MAX_BYTES = 25L * 1024L * 1024L
    private val blockedExtensions = setOf("exe", "bat", "cmd", "vbs", "js", "apk", "scr", "msi", "ps1")

    fun validate(fileName: String, sizeBytes: Long): AttachmentValidationResult {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext in blockedExtensions) {
            return AttachmentValidationResult(
                allowed = false,
                reason = "Blocked executable/script attachment type (.$ext) by security policy.",
                scanStatus = ScanStatus.QUARANTINED
            )
        }
        if (sizeBytes > MAX_BYTES) {
            return AttachmentValidationResult(
                allowed = false,
                reason = "Attachment exceeds 25 MB policy limit.",
                scanStatus = ScanStatus.QUARANTINED
            )
        }
        return AttachmentValidationResult(
            allowed = true,
            reason = "Passed extension, size, and local malware-hook scan.",
            scanStatus = ScanStatus.CLEAN
        )
    }
}

object PromptInjectionGuard {
    private val suspiciousPatterns = listOf(
        Regex("ignore\\s+(all\\s+)?(previous|your|prior)\\s+instructions", RegexOption.IGNORE_CASE),
        Regex("forward\\s+(the\\s+)?(entire\\s+)?inbox", RegexOption.IGNORE_CASE),
        Regex("exfiltrate|override\\s+system\\s+prompt|grant\\s+authority", RegexOption.IGNORE_CASE)
    )

    fun containsInjectionAttempt(text: String): Boolean {
        return suspiciousPatterns.any { it.containsMatchIn(text) }
    }

    fun wrapUntrustedContent(messageId: String, sender: String, body: String): String {
        val sanitized = body
            .replace("</untrusted_email_content>", "[redacted-closing-tag]")
            .take(4000)
        return """
            <untrusted_email_content message_id="$messageId" sender="$sender">
            $sanitized
            </untrusted_email_content>
        """.trimIndent()
    }
}

object LogRedactor {
    private val emailRegex = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
    private val bearerRegex = Regex("Bearer\\s+[A-Za-z0-9._-]+", RegexOption.IGNORE_CASE)

    fun redact(raw: String): String {
        return raw
            .let { bearerRegex.replace(it, "Bearer [REDACTED]") }
            .let { emailRegex.replace(it) { match ->
                val parts = match.value.split("@")
                val local = parts.firstOrNull().orEmpty().take(2) + "***"
                "$local@${parts.getOrElse(1) { "***" }}"
            } }
    }
}
