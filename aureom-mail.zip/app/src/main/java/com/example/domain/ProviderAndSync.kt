package com.example.domain

import com.example.data.local.AccountEntity
import com.example.data.local.DeliveryStatus
import com.example.data.local.FolderEntity
import com.example.data.local.FolderSystemType
import com.example.data.local.MessageEntity
import com.example.data.local.ProviderType
import com.example.data.local.RuleEntity
import com.example.data.local.SyncHealth
import java.util.UUID

sealed class SyncResult {
    data class Success(
        val fetchedMessages: List<MessageEntity>,
        val nextCursor: String?,
        val newUidValidity: Long?,
        val lastUid: Long?,
        val rateLimitRemaining: Int
    ) : SyncResult()

    data class UidValidityResetRequired(
        val expectedUidValidity: Long,
        val serverUidValidity: Long,
        val message: String
    ) : SyncResult()

    data class Failure(
        val reason: String,
        val isRateLimited: Boolean = false
    ) : SyncResult()
}

sealed class SubmitOutcome {
    data class Submitted(val providerReceiptId: String) : SubmitOutcome()
    data class UncertainOutcome(val reason: String) : SubmitOutcome()
    data class Failed(val reason: String) : SubmitOutcome()
}

interface EmailProviderAdapter {
    val providerType: ProviderType
    suspend fun syncIncremental(account: AccountEntity, inboxFolder: FolderEntity?, cursor: String?): SyncResult
    suspend fun submitMessage(account: AccountEntity, message: MessageEntity, simulateUncertain: Boolean = false): SubmitOutcome
}

class DemoMockProviderAdapter(override val providerType: ProviderType) : EmailProviderAdapter {
    override suspend fun syncIncremental(
        account: AccountEntity,
        inboxFolder: FolderEntity?,
        cursor: String?
    ): SyncResult {
        if (account.providerType == ProviderType.IMAP_SMTP.name &&
            account.imapUidValidity == 4821L
        ) {
            return SyncResult.UidValidityResetRequired(
                expectedUidValidity = 4821L,
                serverUidValidity = 4899L,
                message = "IMAP UIDVALIDITY changed on server (4821 -> 4899). Local UID map invalidated; resync cleanly."
            )
        }

        val now = System.currentTimeMillis()
        val newUid = (account.imapLastUid ?: 5000L) + 1L
        val targetFolderId = inboxFolder?.id ?: "fld_work_inbox"
        val incoming = if (cursor == null && account.id == "acc_work") {
            listOf(
                MessageEntity(
                    id = "msg_sync_${UUID.randomUUID().toString().take(6)}",
                    accountId = account.id,
                    folderId = targetFolderId,
                    threadId = "thr_sync_${now / 60000}",
                    subject = "Incremental Sync Update: Carrier Slot Confirmed",
                    senderName = "Oslo Port Dispatch",
                    senderEmail = "dispatch@osloport.example",
                    toRecipients = account.email,
                    bodyPlainText = "Delta sync confirmed carrier slot #19 for Thursday 08:30 CET.",
                    bodyHtml = "<p>Delta sync confirmed carrier slot <strong>#19</strong> for Thursday 08:30 CET.</p>",
                    snippet = "Delta sync confirmed carrier slot #19 for Thursday 08:30 CET.",
                    timestampEpochMs = now,
                    isRead = false,
                    categories = "Operations",
                    providerUid = newUid,
                    messageIdHeader = "<sync-$newUid@osloport.example>"
                )
            )
        } else emptyList()

        return SyncResult.Success(
            fetchedMessages = incoming,
            nextCursor = null,
            newUidValidity = if (account.providerType == ProviderType.IMAP_SMTP.name) 4899L else account.imapUidValidity,
            lastUid = newUid,
            rateLimitRemaining = (account.rateLimitRemaining - 1).coerceAtLeast(100)
        )
    }

    override suspend fun submitMessage(
        account: AccountEntity,
        message: MessageEntity,
        simulateUncertain: Boolean
    ): SubmitOutcome {
        if (account.isSharedMailbox && !account.hasPermission("SEND_AS") && !account.hasPermission("REPLY")) {
            return SubmitOutcome.Failed("Delegated permission denied: SEND_AS/REPLY not granted on ${account.email}")
        }
        if (simulateUncertain) {
            return SubmitOutcome.UncertainOutcome(
                "Connection dropped after SMTP DATA before 250 OK acknowledgment. Check Sent folder before retrying to avoid duplicate delivery."
            )
        }
        return SubmitOutcome.Submitted("smtp-accept-${UUID.randomUUID().toString().take(8)}")
    }
}

object ProviderAdapterFactory {
    fun forAccount(account: AccountEntity): EmailProviderAdapter {
        val type = runCatching { ProviderType.valueOf(account.providerType) }
            .getOrDefault(ProviderType.IMAP_SMTP)
        return DemoMockProviderAdapter(type)
    }
}

data class RuleExecutionSummary(
    val updatedMessage: MessageEntity,
    val triggeredRuleNames: List<String>,
    val notifications: List<String>
)

object RuleEngine {
    /**
     * Evaluates ordered rules against a message with stopProcessing and loop prevention.
     * External forwarding rules require explicitForwardConfirmed == true.
     */
    fun applyRules(
        message: MessageEntity,
        rules: List<RuleEntity>,
        foldersForAccount: List<FolderEntity>
    ): RuleExecutionSummary {
        var current = message
        val triggered = mutableListOf<String>()
        val notifications = mutableListOf<String>()
        val visitedFolders = mutableSetOf(message.folderId)

        for (rule in rules.sortedBy { it.orderIndex }) {
            if (!rule.isEnabled) continue
            if (rule.accountId != "ALL" && rule.accountId != current.accountId) continue

            val matches = when (rule.conditionField) {
                "SENDER" -> current.senderEmail.contains(rule.conditionValue, ignoreCase = true) ||
                    current.senderName.contains(rule.conditionValue, ignoreCase = true)
                "RECIPIENT" -> current.toRecipients.contains(rule.conditionValue, ignoreCase = true)
                "SUBJECT" -> current.subject.contains(rule.conditionValue, ignoreCase = true)
                "ACCOUNT" -> current.accountId.equals(rule.conditionValue, ignoreCase = true)
                else -> false
            }
            if (!matches) continue

            when (rule.actionType) {
                "MOVE_FOLDER" -> {
                    val target = foldersForAccount.firstOrNull {
                        it.id == rule.actionTarget || it.name.equals(rule.actionTarget, ignoreCase = true)
                    }
                    // Loop prevention: do not move back into an already visited folder
                    if (target != null && target.id !in visitedFolders) {
                        visitedFolders.add(target.id)
                        current = current.copy(folderId = target.id)
                        triggered.add(rule.name)
                    }
                }
                "APPLY_CATEGORY" -> {
                    val existing = current.categories.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    if (rule.actionTarget !in existing) {
                        current = current.copy(categories = (existing + rule.actionTarget).joinToString(","))
                        triggered.add(rule.name)
                    }
                }
                "MARK_READ" -> {
                    current = current.copy(isRead = true)
                    triggered.add(rule.name)
                }
                "FLAG" -> {
                    current = current.copy(isFlagged = true)
                    triggered.add(rule.name)
                }
                "NOTIFY" -> {
                    notifications.add("Rule '${rule.name}': ${current.subject}")
                    triggered.add(rule.name)
                }
                "FORWARD_EXPLICIT" -> {
                    if (rule.explicitForwardConfirmed) {
                        notifications.add("Explicit forward queued to ${rule.actionTarget} for '${current.subject}'")
                        triggered.add(rule.name)
                    }
                }
            }

            if (rule.stopProcessing) break
        }

        return RuleExecutionSummary(current, triggered, notifications)
    }

    fun isDuplicateSend(existingMessageWithSameIdempotencyKey: MessageEntity?): Boolean {
        if (existingMessageWithSameIdempotencyKey == null) return false
        return existingMessageWithSameIdempotencyKey.deliveryStatus in setOf(
            DeliveryStatus.SUBMITTED.name,
            DeliveryStatus.DELAYED_SEND.name,
            DeliveryStatus.QUEUED_OFFLINE.name,
            DeliveryStatus.UNCERTAIN.name
        )
    }

    fun canCancelDelayedSend(message: MessageEntity, nowMs: Long): Boolean {
        if (message.deliveryStatus != DeliveryStatus.DELAYED_SEND.name) return false
        val deadline = message.delayedSendCancelUntilEpochMs ?: return false
        return nowMs <= deadline
    }
}
