package com.example.domain

import com.example.data.local.CalendarEventEntity
import com.example.data.local.InvitationSendState
import com.example.data.local.MessageEntity
import com.example.data.local.RsvpStatus
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID

data class ExpandedEventOccurrence(
    val occurrenceId: String,
    val sourceEvent: CalendarEventEntity,
    val startEpochMs: Long,
    val endEpochMs: Long,
    val isRecurringInstance: Boolean
)

object CalendarMath {
    private val dateFormatter = DateTimeFormatter.ISO_LOCAL_DATE

    fun formatInZone(epochMs: Long, zoneIdStr: String, pattern: String = "EEE, MMM d · HH:mm z"): String {
        val zone = runCatching { ZoneId.of(zoneIdStr) }.getOrElse { ZoneId.systemDefault() }
        val zdt = ZonedDateTime.ofInstant(Instant.ofEpochMilli(epochMs), zone)
        return zdt.format(DateTimeFormatter.ofPattern(pattern))
    }

    fun isDaylightSavingTime(epochMs: Long, zoneIdStr: String): Boolean {
        val zone = runCatching { ZoneId.of(zoneIdStr) }.getOrElse { ZoneId.systemDefault() }
        return zone.rules.isDaylightSavings(Instant.ofEpochMilli(epochMs))
    }

    /**
     * Expands events into occurrences within [rangeStartMs, rangeEndMs], preserving
     * wall-clock time across DST transitions using ZonedDateTime plusDays/plusWeeks/plusMonths.
     */
    fun expandOccurrences(
        events: List<CalendarEventEntity>,
        rangeStartMs: Long,
        rangeEndMs: Long
    ): List<ExpandedEventOccurrence> {
        val result = mutableListOf<ExpandedEventOccurrence>()
        for (event in events) {
            val zone = runCatching { ZoneId.of(event.timezoneId) }.getOrElse { ZoneId.systemDefault() }
            val startZdt = ZonedDateTime.ofInstant(Instant.ofEpochMilli(event.startEpochMs), zone)
            val durationMs = (event.endEpochMs - event.startEpochMs).coerceAtLeast(15 * 60_000L)
            val exceptions = event.exceptionDatesCsv
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .toSet()

            if (event.recurrenceRule == "NONE") {
                if (event.endEpochMs >= rangeStartMs && event.startEpochMs <= rangeEndMs) {
                    result.add(
                        ExpandedEventOccurrence(
                            occurrenceId = event.id,
                            sourceEvent = event,
                            startEpochMs = event.startEpochMs,
                            endEpochMs = event.endEpochMs,
                            isRecurringInstance = event.seriesMasterId != null
                        )
                    )
                }
                continue
            }

            var cursor = startZdt
            var safety = 0
            while (cursor.toInstant().toEpochMilli() <= rangeEndMs && safety < 90) {
                safety++
                val occStart = cursor.toInstant().toEpochMilli()
                val occEnd = occStart + durationMs
                val occDateKey = cursor.toLocalDate().format(dateFormatter)
                if (occEnd >= rangeStartMs && occDateKey !in exceptions) {
                    result.add(
                        ExpandedEventOccurrence(
                            occurrenceId = "${event.id}__$occDateKey",
                            sourceEvent = event,
                            startEpochMs = occStart,
                            endEpochMs = occEnd,
                            isRecurringInstance = true
                        )
                    )
                }
                cursor = when (event.recurrenceRule) {
                    "DAILY" -> cursor.plusDays(1)
                    "WEEKLY" -> cursor.plusWeeks(1)
                    "MONTHLY" -> cursor.plusMonths(1)
                    else -> break
                }
            }
        }
        return result.sortedBy { it.startEpochMs }
    }

    /**
     * Edits only a single occurrence of a recurring series without altering the series master:
     * adds the occurrence's local date to the master's exceptionDatesCsv and creates an override event.
     */
    fun createSingleOccurrenceException(
        seriesMaster: CalendarEventEntity,
        occurrenceStartMs: Long,
        newTitle: String,
        newStartMs: Long,
        newEndMs: Long,
        newLocation: String
    ): Pair<CalendarEventEntity, CalendarEventEntity> {
        val zone = runCatching { ZoneId.of(seriesMaster.timezoneId) }.getOrElse { ZoneId.systemDefault() }
        val exceptionDate = ZonedDateTime.ofInstant(Instant.ofEpochMilli(occurrenceStartMs), zone)
            .toLocalDate()
            .format(dateFormatter)

        val updatedExceptions = (seriesMaster.exceptionDatesCsv.split(",").map { it.trim() }
            .filter { it.isNotEmpty() } + exceptionDate).distinct().joinToString(",")

        val updatedMaster = seriesMaster.copy(exceptionDatesCsv = updatedExceptions)
        val overrideEvent = seriesMaster.copy(
            id = "evt_exc_${UUID.randomUUID().toString().take(8)}",
            seriesMasterId = seriesMaster.id,
            title = newTitle,
            startEpochMs = newStartMs,
            endEpochMs = newEndMs,
            location = newLocation,
            recurrenceRule = "NONE",
            exceptionDatesCsv = ""
        )
        return updatedMaster to overrideEvent
    }
}

object IcsCodec {
    private val icsUtcFmt = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'")

    fun exportEventsToIcs(events: List<CalendarEventEntity>): String {
        val sb = StringBuilder()
        sb.appendLine("BEGIN:VCALENDAR")
        sb.appendLine("VERSION:2.0")
        sb.appendLine("PRODID:-//Aureom Mail//Calendar Engine 1.0//EN")
        for (evt in events) {
            val startUtc = ZonedDateTime.ofInstant(Instant.ofEpochMilli(evt.startEpochMs), ZoneId.of("UTC"))
            val endUtc = ZonedDateTime.ofInstant(Instant.ofEpochMilli(evt.endEpochMs), ZoneId.of("UTC"))
            sb.appendLine("BEGIN:VEVENT")
            sb.appendLine("UID:${evt.id}@aureom.example")
            sb.appendLine("DTSTART:${startUtc.format(icsUtcFmt)}")
            sb.appendLine("DTEND:${endUtc.format(icsUtcFmt)}")
            sb.appendLine("SUMMARY:${evt.title.replace("\n", " ")}")
            if (evt.location.isNotBlank()) sb.appendLine("LOCATION:${evt.location}")
            if (evt.description.isNotBlank()) sb.appendLine("DESCRIPTION:${evt.description.replace("\n", "\\n")}")
            if (evt.recurrenceRule != "NONE") sb.appendLine("RRULE:FREQ=${evt.recurrenceRule}")
            sb.appendLine("X-AUREOM-TZ:${evt.timezoneId}")
            sb.appendLine("END:VEVENT")
        }
        sb.appendLine("END:VCALENDAR")
        return sb.toString()
    }

    fun importIcs(icsText: String, targetCalendarId: String, targetAccountId: String): List<CalendarEventEntity> {
        val blocks = icsText.split("BEGIN:VEVENT").drop(1)
        return blocks.mapNotNull { block ->
            val lines = block.substringBefore("END:VEVENT").lines().map { it.trim() }
            val summary = lines.firstOrNull { it.startsWith("SUMMARY:") }?.substringAfter("SUMMARY:")
                ?: return@mapNotNull null
            val location = lines.firstOrNull { it.startsWith("LOCATION:") }?.substringAfter("LOCATION:").orEmpty()
            val description = lines.firstOrNull { it.startsWith("DESCRIPTION:") }
                ?.substringAfter("DESCRIPTION:")?.replace("\\n", "\n").orEmpty()
            val tz = lines.firstOrNull { it.startsWith("X-AUREOM-TZ:") }
                ?.substringAfter("X-AUREOM-TZ:") ?: ZoneId.systemDefault().id

            val dtStartRaw = lines.firstOrNull { it.startsWith("DTSTART") }?.substringAfter(":")
            val dtEndRaw = lines.firstOrNull { it.startsWith("DTEND") }?.substringAfter(":")
            val startMs = parseIcsDate(dtStartRaw) ?: (System.currentTimeMillis() + 3_600_000L)
            val endMs = parseIcsDate(dtEndRaw) ?: (startMs + 3_600_000L)
            val rrule = lines.firstOrNull { it.startsWith("RRULE:FREQ=") }
                ?.substringAfter("RRULE:FREQ=")?.substringBefore(";") ?: "NONE"

            CalendarEventEntity(
                id = "evt_imp_${UUID.randomUUID().toString().take(8)}",
                calendarId = targetCalendarId,
                accountId = targetAccountId,
                title = summary,
                description = description,
                location = location,
                startEpochMs = startMs,
                endEpochMs = endMs,
                timezoneId = tz,
                recurrenceRule = if (rrule in setOf("DAILY", "WEEKLY", "MONTHLY")) rrule else "NONE",
                rsvpStatus = RsvpStatus.ACCEPTED.name,
                invitationSendState = InvitationSendState.LOCAL_ONLY.name
            )
        }
    }

    private fun parseIcsDate(raw: String?): Long? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            if (raw.endsWith("Z")) {
                val ldt = java.time.LocalDateTime.parse(raw, icsUtcFmt)
                ldt.atZone(ZoneId.of("UTC")).toInstant().toEpochMilli()
            } else if (raw.length == 8) {
                LocalDate.parse(raw, DateTimeFormatter.BASIC_ISO_DATE)
                    .atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
            } else null
        }.getOrNull()
    }

    fun exportMessageToEml(message: MessageEntity): String {
        return buildString {
            appendLine("Message-ID: ${message.messageIdHeader}")
            appendLine("From: ${message.senderName} <${message.senderEmail}>")
            if (!message.replyToEmail.isNullOrBlank()) {
                appendLine("Reply-To: ${message.replyToEmail}")
            }
            appendLine("To: ${message.toRecipients}")
            if (message.ccRecipients.isNotBlank()) appendLine("Cc: ${message.ccRecipients}")
            appendLine("Subject: ${message.subject}")
            appendLine("Date: ${Instant.ofEpochMilli(message.timestampEpochMs)}")
            appendLine("Authentication-Results: spf=${message.authSpf}; dkim=${message.authDkim}; dmarc=${message.authDmarc}")
            appendLine("Content-Type: text/plain; charset=UTF-8")
            appendLine()
            appendLine(message.bodyPlainText)
        }
    }
}
