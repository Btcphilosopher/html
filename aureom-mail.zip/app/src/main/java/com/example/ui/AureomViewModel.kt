package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiActionLogStatus
import com.example.ai.AureomCopilotService
import com.example.ai.CopilotResult
import com.example.ai.CopilotTaskType
import com.example.ai.CopilotUiState
import com.example.ai.ProposedCopilotAction
import com.example.data.local.AccountEntity
import com.example.data.local.AiActionLogEntity
import com.example.data.local.AttachmentEntity
import com.example.data.local.AureomDatabase
import com.example.data.local.CalendarEntity
import com.example.data.local.CalendarEventEntity
import com.example.data.local.ContactEntity
import com.example.data.local.DeliveryStatus
import com.example.data.local.FolderEntity
import com.example.data.local.FolderSystemType
import com.example.data.local.InvitationSendState
import com.example.data.local.MessageEntity
import com.example.data.local.OutboxOperationEntity
import com.example.data.local.RsvpStatus
import com.example.data.local.RuleEntity
import com.example.data.local.SavedSearchEntity
import com.example.data.local.TaskEntity
import com.example.data.prefs.WorkspacePreferences
import com.example.data.prefs.WorkspaceSettings
import com.example.data.repository.AureomRepository
import com.example.domain.IcsCodec
import com.example.ui.theme.DensityMode
import com.example.ui.theme.ReadingPanePosition
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppRailSection { MAIL, CALENDAR, PEOPLE, TASKS, FILES, COPILOT }
enum class MailSortOrder { NEWEST, UNREAD_FIRST, SENDER }
enum class MailFilterChip { ALL, UNREAD, FLAGGED, PINNED, SNOOZED, HAS_ATTACHMENTS }
enum class CalendarViewMode { DAY, WORK_WEEK, WEEK, MONTH, AGENDA }

data class ComposerDraftState(
    val isOpen: Boolean = false,
    val messageId: String = "",
    val accountId: String = "acc_work",
    val sendingIdentityEmail: String = "elena.vance@aureom-corp.example",
    val toRecipients: String = "",
    val ccRecipients: String = "",
    val bccRecipients: String = "",
    val subject: String = "",
    val body: String = "",
    val isRichText: Boolean = true,
    val threadId: String = "",
    val scheduledOffsetMinutes: Int? = null,
    val simulateUncertainOutcome: Boolean = false,
    val idempotencyKey: String = ""
)

data class PendingDelayedSendBanner(
    val messageId: String,
    val subject: String,
    val secondsRemaining: Int,
    val isScheduled: Boolean
)

data class AureomUiState(
    val activeSection: AppRailSection = AppRailSection.MAIL,
    val settings: WorkspaceSettings = WorkspaceSettings(),
    val accounts: List<AccountEntity> = emptyList(),
    val folders: List<FolderEntity> = emptyList(),
    val allMessages: List<MessageEntity> = emptyList(),
    val visibleMessages: List<MessageEntity> = emptyList(),
    val selectedFolderId: String? = null,
    val selectedThreadId: String? = null,
    val selectedMessageId: String? = null,
    val selectedBulkIds: Set<String> = emptySet(),
    val sortOrder: MailSortOrder = MailSortOrder.NEWEST,
    val filterChip: MailFilterChip = MailFilterChip.ALL,
    val showPlainTextBody: Boolean = false,
    val showExpandedHeaders: Boolean = false,
    val attachments: List<AttachmentEntity> = emptyList(),
    val calendars: List<CalendarEntity> = emptyList(),
    val events: List<CalendarEventEntity> = emptyList(),
    val calendarViewMode: CalendarViewMode = CalendarViewMode.WEEK,
    val selectedTimezoneId: String = "America/New_York",
    val contacts: List<ContactEntity> = emptyList(),
    val tasks: List<TaskEntity> = emptyList(),
    val rules: List<RuleEntity> = emptyList(),
    val outboxOps: List<OutboxOperationEntity> = emptyList(),
    val savedSearches: List<SavedSearchEntity> = emptyList(),
    val aiLogs: List<AiActionLogEntity> = emptyList(),
    val searchQuery: String = "",
    val searchResults: List<MessageEntity> = emptyList(),
    val isSearchActive: Boolean = false,
    val composer: ComposerDraftState = ComposerDraftState(),
    val pendingDelayedSend: PendingDelayedSendBanner? = null,
    val copilotState: CopilotUiState = CopilotUiState.Idle,
    val notifications: List<String> = emptyList(),
    val statusSnackbar: String? = null,
    val exportedTextPreview: String? = null,
    val showSettingsDialog: Boolean = false,
    val showDemoGuideSheet: Boolean = false,
    val showNotificationsSheet: Boolean = false
)

class AureomViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AureomDatabase.getInstance(application)
    private val repository = AureomRepository(db)
    private val prefs = WorkspacePreferences(application)
    private val copilotService = AureomCopilotService()

    private val _activeSection = MutableStateFlow(AppRailSection.MAIL)
    private val _selectedFolderId = MutableStateFlow<String?>(null)
    private val _selectedThreadId = MutableStateFlow<String?>(null)
    private val _selectedMessageId = MutableStateFlow<String?>(null)
    private val _selectedBulkIds = MutableStateFlow<Set<String>>(emptySet())
    private val _sortOrder = MutableStateFlow(MailSortOrder.NEWEST)
    private val _filterChip = MutableStateFlow(MailFilterChip.ALL)
    private val _showPlainText = MutableStateFlow(false)
    private val _showExpandedHeaders = MutableStateFlow(false)
    private val _calendarViewMode = MutableStateFlow(CalendarViewMode.WEEK)
    private val _selectedTimezoneId = MutableStateFlow("America/New_York")
    private val _searchQuery = MutableStateFlow("")
    private val _searchResults = MutableStateFlow<List<MessageEntity>>(emptyList())
    private val _isSearchActive = MutableStateFlow(false)
    private val _composer = MutableStateFlow(ComposerDraftState())
    private val _pendingDelayedSend = MutableStateFlow<PendingDelayedSendBanner?>(null)
    private val _copilotState = MutableStateFlow<CopilotUiState>(CopilotUiState.Idle)
    private val _notifications = MutableStateFlow(
        listOf(
            "IMAP sync alert: Personal account UIDVALIDITY mismatch (4821 -> 4899).",
            "Security notice: Reply-To mismatch & blocked tracker on 'Urgent Vendor Wire Update'."
        )
    )
    private val _statusSnackbar = MutableStateFlow<String?>(null)
    private val _exportedPreview = MutableStateFlow<String?>(null)
    private val _showSettings = MutableStateFlow(false)
    private val _showDemoGuide = MutableStateFlow(false)
    private val _showNotifications = MutableStateFlow(false)

    private var delayedSendJob: Job? = null
    private var copilotJob: Job? = null
    private var autosaveJob: Job? = null

    private data class CoreDataBundle(
        val settings: WorkspaceSettings,
        val accounts: List<AccountEntity>,
        val folders: List<FolderEntity>,
        val messages: List<MessageEntity>,
        val attachments: List<AttachmentEntity>
    )

    private data class SecondaryDataBundle(
        val calendars: List<CalendarEntity>,
        val events: List<CalendarEventEntity>,
        val contacts: List<ContactEntity>,
        val tasks: List<TaskEntity>,
        val rules: List<RuleEntity>
    )

    private data class MetaDataBundle(
        val outbox: List<OutboxOperationEntity>,
        val savedSearches: List<SavedSearchEntity>,
        val aiLogs: List<AiActionLogEntity>
    )

    private val coreBundleFlow = combine(
        prefs.settingsFlow,
        repository.accounts,
        repository.folders,
        repository.messages,
        repository.attachments
    ) { settings, accounts, folders, messages, attachments ->
        CoreDataBundle(settings, accounts, folders, messages, attachments)
    }

    private val secondaryBundleFlow = combine(
        repository.calendars,
        repository.events,
        repository.contacts,
        repository.tasks,
        repository.rules
    ) { calendars, events, contacts, tasks, rules ->
        SecondaryDataBundle(calendars, events, contacts, tasks, rules)
    }

    private val metaBundleFlow = combine(
        repository.outboxOperations,
        repository.savedSearches,
        repository.aiLogs
    ) { outbox, savedSearches, aiLogs ->
        MetaDataBundle(outbox, savedSearches, aiLogs)
    }

    private data class UiLocalControls(
        val activeSection: AppRailSection,
        val selectedFolderId: String?,
        val selectedThreadId: String?,
        val selectedMessageId: String?,
        val selectedBulkIds: Set<String>,
        val sortOrder: MailSortOrder,
        val filterChip: MailFilterChip,
        val showPlainText: Boolean,
        val showExpandedHeaders: Boolean
    )

    private val uiControlsFlow = combine(
        _activeSection,
        _selectedFolderId,
        _selectedThreadId,
        _selectedMessageId,
        _selectedBulkIds
    ) { section, folderId, threadId, msgId, bulkIds ->
        listOf(section, folderId, threadId, msgId, bulkIds)
    }.combine(
        combine(_sortOrder, _filterChip, _showPlainText, _showExpandedHeaders) { sort, filter, plain, headers ->
            listOf(sort, filter, plain, headers)
        }
    ) { a, b ->
        UiLocalControls(
            activeSection = a[0] as AppRailSection,
            selectedFolderId = a[1] as String?,
            selectedThreadId = a[2] as String?,
            selectedMessageId = a[3] as String?,
            selectedBulkIds = @Suppress("UNCHECKED_CAST") (a[4] as Set<String>),
            sortOrder = b[0] as MailSortOrder,
            filterChip = b[1] as MailFilterChip,
            showPlainText = b[2] as Boolean,
            showExpandedHeaders = b[3] as Boolean
        )
    }

    private data class ModalAndCopilotState(
        val calendarViewMode: CalendarViewMode,
        val timezoneId: String,
        val searchQuery: String,
        val searchResults: List<MessageEntity>,
        val isSearchActive: Boolean,
        val composer: ComposerDraftState,
        val pendingDelayedSend: PendingDelayedSendBanner?,
        val copilotState: CopilotUiState,
        val notifications: List<String>,
        val statusSnackbar: String?,
        val exportedPreview: String?,
        val showSettings: Boolean,
        val showDemoGuide: Boolean,
        val showNotifications: Boolean
    )

    private val modalStateFlow = combine(
        _calendarViewMode,
        _selectedTimezoneId,
        _searchQuery,
        _searchResults,
        _isSearchActive
    ) { calMode, tz, q, res, active ->
        listOf(calMode, tz, q, res, active)
    }.combine(
        combine(_composer, _pendingDelayedSend, _copilotState, _notifications) { comp, delayed, copilot, notifs ->
            listOf(comp, delayed, copilot, notifs)
        }
    ) { a, b -> a + b }
        .combine(
            combine(_statusSnackbar, _exportedPreview, _showSettings, _showDemoGuide, _showNotifications) { snack, exp, set, demo, notifSheet ->
                listOf(snack, exp, set, demo, notifSheet)
            }
        ) { ab, c ->
            val all = ab + c
            ModalAndCopilotState(
                calendarViewMode = all[0] as CalendarViewMode,
                timezoneId = all[1] as String,
                searchQuery = all[2] as String,
                searchResults = @Suppress("UNCHECKED_CAST") (all[3] as List<MessageEntity>),
                isSearchActive = all[4] as Boolean,
                composer = all[5] as ComposerDraftState,
                pendingDelayedSend = all[6] as PendingDelayedSendBanner?,
                copilotState = all[7] as CopilotUiState,
                notifications = @Suppress("UNCHECKED_CAST") (all[8] as List<String>),
                statusSnackbar = all[9] as String?,
                exportedPreview = all[10] as String?,
                showSettings = all[11] as Boolean,
                showDemoGuide = all[12] as Boolean,
                showNotifications = all[13] as Boolean
            )
        }

    val uiState: StateFlow<AureomUiState> = combine(
        coreBundleFlow,
        secondaryBundleFlow,
        metaBundleFlow,
        uiControlsFlow,
        modalStateFlow
    ) { core, sec, meta, ctrl, modal ->
        val settings = core.settings
        val accountFilter = settings.selectedAccountId
        val folderTypeFilter = settings.selectedFolderSystemType
        val attachmentMessageIds = core.attachments.map { it.messageId }.toSet()

        val accountFilteredFolders = if (accountFilter == "UNIFIED") {
            core.folders.filter { it.systemType == folderTypeFilter }.map { it.id }.toSet()
        } else {
            val targetFolderId = ctrl.selectedFolderId
                ?: core.folders.firstOrNull { it.accountId == accountFilter && it.systemType == folderTypeFilter }?.id
            setOfNotNull(targetFolderId)
        }

        val folderFiltered = core.messages.filter { msg ->
            val accMatch = accountFilter == "UNIFIED" || msg.accountId == accountFilter
            val fldMatch = if (ctrl.selectedFolderId != null && accountFilter != "UNIFIED") {
                msg.folderId == ctrl.selectedFolderId
            } else {
                msg.folderId in accountFilteredFolders
            }
            accMatch && fldMatch
        }

        val chipFiltered = folderFiltered.filter { msg ->
            when (ctrl.filterChip) {
                MailFilterChip.ALL -> true
                MailFilterChip.UNREAD -> !msg.isRead
                MailFilterChip.FLAGGED -> msg.isFlagged
                MailFilterChip.PINNED -> msg.isPinned
                MailFilterChip.SNOOZED -> msg.snoozedUntilEpochMs != null
                MailFilterChip.HAS_ATTACHMENTS -> msg.id in attachmentMessageIds
            }
        }

        val sorted = when (ctrl.sortOrder) {
            MailSortOrder.NEWEST -> chipFiltered.sortedWith(
                compareByDescending<MessageEntity> { it.isPinned }.thenByDescending { it.timestampEpochMs }
            )
            MailSortOrder.UNREAD_FIRST -> chipFiltered.sortedWith(
                compareBy<MessageEntity> { it.isRead }.thenByDescending { it.timestampEpochMs }
            )
            MailSortOrder.SENDER -> chipFiltered.sortedBy { it.senderName.lowercase() }
        }

        val groupedVisible = if (settings.conversationGrouping) {
            sorted.groupBy { it.threadId }.values.map { threadMsgs ->
                threadMsgs.maxByOrNull { it.timestampEpochMs } ?: threadMsgs.first()
            }
        } else sorted

        val effectiveSelectedMsgId = ctrl.selectedMessageId ?: groupedVisible.firstOrNull()?.id
        val effectiveThreadId = ctrl.selectedThreadId
            ?: core.messages.firstOrNull { it.id == effectiveSelectedMsgId }?.threadId

        AureomUiState(
            activeSection = ctrl.activeSection,
            settings = settings,
            accounts = core.accounts,
            folders = core.folders,
            allMessages = core.messages,
            visibleMessages = groupedVisible,
            selectedFolderId = ctrl.selectedFolderId,
            selectedThreadId = effectiveThreadId,
            selectedMessageId = effectiveSelectedMsgId,
            selectedBulkIds = ctrl.selectedBulkIds,
            sortOrder = ctrl.sortOrder,
            filterChip = ctrl.filterChip,
            showPlainTextBody = ctrl.showPlainText,
            showExpandedHeaders = ctrl.showExpandedHeaders,
            attachments = core.attachments,
            calendars = sec.calendars,
            events = sec.events,
            calendarViewMode = modal.calendarViewMode,
            selectedTimezoneId = modal.timezoneId,
            contacts = sec.contacts,
            tasks = sec.tasks,
            rules = sec.rules,
            outboxOps = meta.outbox,
            savedSearches = meta.savedSearches,
            aiLogs = meta.aiLogs,
            searchQuery = modal.searchQuery,
            searchResults = modal.searchResults,
            isSearchActive = modal.isSearchActive,
            composer = modal.composer,
            pendingDelayedSend = modal.pendingDelayedSend,
            copilotState = modal.copilotState,
            notifications = modal.notifications,
            statusSnackbar = modal.statusSnackbar,
            exportedTextPreview = modal.exportedPreview,
            showSettingsDialog = modal.showSettings,
            showDemoGuideSheet = modal.showDemoGuide,
            showNotificationsSheet = modal.showNotifications
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AureomUiState()
    )

    init {
        viewModelScope.launch {
            repository.ensureSeeded()
        }
    }

    // Navigation & Selection
    fun selectSection(section: AppRailSection) {
        _activeSection.value = section
    }

    fun selectAccount(accountId: String) {
        viewModelScope.launch {
            prefs.setSelectedAccount(accountId)
            _selectedFolderId.value = null
            _selectedBulkIds.value = emptySet()
            _selectedMessageId.value = null
            _selectedThreadId.value = null
        }
    }

    fun selectSystemFolder(systemType: FolderSystemType) {
        viewModelScope.launch {
            prefs.setSelectedFolderType(systemType.name)
            _selectedFolderId.value = null
            _selectedBulkIds.value = emptySet()
            _selectedMessageId.value = null
            _selectedThreadId.value = null
        }
    }

    fun selectCustomFolder(accountId: String, folderId: String) {
        viewModelScope.launch {
            prefs.setSelectedAccount(accountId)
            prefs.setSelectedFolderType(FolderSystemType.CUSTOM.name)
            _selectedFolderId.value = folderId
            _selectedMessageId.value = null
            _selectedThreadId.value = null
        }
    }

    fun selectMessage(message: MessageEntity?) {
        _selectedMessageId.value = message?.id
        _selectedThreadId.value = message?.threadId
        if (message != null && !message.isRead) {
            viewModelScope.launch {
                repository.markRead(message.id, isRead = true, isOffline = uiState.value.settings.isOfflineMode)
            }
        }
    }

    fun toggleBulkSelection(messageId: String) {
        _selectedBulkIds.update { set ->
            if (messageId in set) set - messageId else set + messageId
        }
    }

    fun clearBulkSelection() {
        _selectedBulkIds.value = emptySet()
    }

    fun setSortOrder(order: MailSortOrder) { _sortOrder.value = order }
    fun setFilterChip(chip: MailFilterChip) { _filterChip.value = chip }
    fun togglePlainTextBody() { _showPlainText.update { !it } }
    fun toggleExpandedHeaders() { _showExpandedHeaders.update { !it } }

    // Mail Actions
    fun toggleRead(message: MessageEntity) {
        viewModelScope.launch {
            repository.markRead(message.id, !message.isRead, uiState.value.settings.isOfflineMode)
        }
    }

    fun toggleFlag(message: MessageEntity) {
        viewModelScope.launch {
            repository.toggleFlag(message.id, isOffline = uiState.value.settings.isOfflineMode)
        }
    }

    fun togglePin(message: MessageEntity) {
        viewModelScope.launch {
            repository.togglePin(message.id)
        }
    }

    fun snoozeMessage(messageId: String, hoursAhead: Long) {
        viewModelScope.launch {
            val until = System.currentTimeMillis() + hoursAhead * 3_600_000L
            repository.snoozeMessage(messageId, until)
            _statusSnackbar.value = "Snoozed for ${hoursAhead}h."
        }
    }

    fun unsnoozeMessage(messageId: String) {
        viewModelScope.launch {
            repository.snoozeMessage(messageId, null)
            _statusSnackbar.value = "Unsnoozed back to active view."
        }
    }

    fun moveMessageToSystemFolder(messageId: String, systemType: FolderSystemType) {
        viewModelScope.launch {
            try {
                repository.moveMessageToSystemFolder(messageId, systemType, uiState.value.settings.isOfflineMode)
                _statusSnackbar.value = "Moved to ${systemType.name.lowercase().replaceFirstChar { it.uppercase() }}."
            } catch (e: Exception) {
                _statusSnackbar.value = e.message ?: "Move failed."
            }
        }
    }

    fun moveMessageToFolder(messageId: String, folderId: String) {
        viewModelScope.launch {
            try {
                repository.moveMessageToFolder(messageId, folderId, uiState.value.settings.isOfflineMode)
                _statusSnackbar.value = "Message filed."
            } catch (e: Exception) {
                _statusSnackbar.value = e.message ?: "Filing failed."
            }
        }
    }

    fun bulkMarkRead(isRead: Boolean) {
        val ids = _selectedBulkIds.value.toList()
        viewModelScope.launch {
            val offline = uiState.value.settings.isOfflineMode
            ids.forEach { repository.markRead(it, isRead, offline) }
            _selectedBulkIds.value = emptySet()
            _statusSnackbar.value = "Updated ${ids.size} message(s)."
        }
    }

    fun bulkArchive() {
        val ids = _selectedBulkIds.value.toList()
        viewModelScope.launch {
            val offline = uiState.value.settings.isOfflineMode
            ids.forEach {
                runCatching { repository.moveMessageToSystemFolder(it, FolderSystemType.ARCHIVE, offline) }
            }
            _selectedBulkIds.value = emptySet()
            _statusSnackbar.value = "Archived ${ids.size} message(s)."
        }
    }

    fun createCustomFolder(accountId: String, name: String, parentFolderId: String? = null) {
        viewModelScope.launch {
            repository.createCustomFolder(accountId, name, parentFolderId)
            _statusSnackbar.value = "Created folder '$name'."
        }
    }

    fun setRemoteImagesBlocked(messageId: String, blocked: Boolean) {
        viewModelScope.launch {
            repository.setRemoteImagesBlocked(messageId, blocked)
        }
    }

    fun addCategory(messageId: String, category: String) {
        viewModelScope.launch {
            repository.addCategoryToMessage(messageId, category)
        }
    }

    fun saveSharedMailboxNote(messageId: String, note: String, owner: String?) {
        viewModelScope.launch {
            repository.updateSharedMailboxNote(messageId, note, owner)
            _statusSnackbar.value = "Saved internal shared-mailbox note (not sent externally)."
        }
    }

    fun createTaskFromMessage(message: MessageEntity) {
        viewModelScope.launch {
            repository.createTaskFromMessage(message)
            _statusSnackbar.value = "Created linked task in My Day (original email preserved)."
        }
    }

    fun exportMessageEml(message: MessageEntity) {
        _exportedPreview.value = IcsCodec.exportMessageToEml(message)
    }

    fun dismissExportedPreview() {
        _exportedPreview.value = null
    }

    // Composer & Delayed Send / Undo / Autosave
    fun openNewComposer(accountId: String? = null) {
        val accounts = uiState.value.accounts
        val acc = accounts.firstOrNull { it.id == accountId }
            ?: accounts.firstOrNull { !it.isSharedMailbox }
            ?: accounts.firstOrNull()
        val accId = acc?.id ?: "acc_work"
        val sig = acc?.signature.orEmpty()
        _composer.value = ComposerDraftState(
            isOpen = true,
            messageId = "msg_cmp_${UUID.randomUUID().toString().take(8)}",
            accountId = accId,
            sendingIdentityEmail = acc?.email ?: "elena.vance@aureom-corp.example",
            body = if (sig.isNotBlank()) "\n\n$sig" else "",
            threadId = "thr_${UUID.randomUUID().toString().take(8)}",
            idempotencyKey = "idem_${UUID.randomUUID().toString().take(12)}"
        )
    }

    fun openReplyComposer(source: MessageEntity, replyAll: Boolean = false, forward: Boolean = false) {
        val acc = uiState.value.accounts.firstOrNull { it.id == source.accountId }
        val sig = acc?.signature.orEmpty()
        val to = when {
            forward -> ""
            replyAll -> listOf(source.senderEmail, source.toRecipients)
                .joinToString(", ")
                .split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.equals(acc?.email, ignoreCase = true) }
                .distinct()
                .joinToString(", ")
            else -> source.replyToEmail?.takeIf { it.isNotBlank() } ?: source.senderEmail
        }
        val prefix = if (forward) "Fwd: " else "Re: "
        val subject = if (source.subject.startsWith(prefix, ignoreCase = true)) source.subject else "$prefix${source.subject}"
        val quoted = "\n\n--- On ${source.senderName} <${source.senderEmail}> wrote ---\n${source.bodyPlainText}"
        _composer.value = ComposerDraftState(
            isOpen = true,
            messageId = "msg_cmp_${UUID.randomUUID().toString().take(8)}",
            accountId = source.accountId,
            sendingIdentityEmail = acc?.email ?: "elena.vance@aureom-corp.example",
            toRecipients = to,
            ccRecipients = if (replyAll && !forward) source.ccRecipients else "",
            subject = subject,
            body = "\n\n$sig$quoted",
            threadId = source.threadId,
            idempotencyKey = "idem_${UUID.randomUUID().toString().take(12)}"
        )
    }

    fun openExistingDraft(draft: MessageEntity) {
        val acc = uiState.value.accounts.firstOrNull { it.id == draft.accountId }
        _composer.value = ComposerDraftState(
            isOpen = true,
            messageId = draft.id,
            accountId = draft.accountId,
            sendingIdentityEmail = draft.sendingIdentityEmail ?: acc?.email ?: "elena.vance@aureom-corp.example",
            toRecipients = draft.toRecipients,
            ccRecipients = draft.ccRecipients,
            bccRecipients = draft.bccRecipients,
            subject = draft.subject,
            body = draft.bodyPlainText,
            threadId = draft.threadId,
            idempotencyKey = draft.idempotencyKey ?: "idem_${UUID.randomUUID().toString().take(12)}"
        )
    }

    fun updateComposer(transform: (ComposerDraftState) -> ComposerDraftState) {
        _composer.update(transform)
        scheduleDraftAutosave()
    }

    fun switchComposerIdentity(account: AccountEntity) {
        _composer.update {
            it.copy(
                accountId = account.id,
                sendingIdentityEmail = account.email
            )
        }
        scheduleDraftAutosave()
    }

    private fun scheduleDraftAutosave() {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(800L)
            val draft = _composer.value
            if (!draft.isOpen) return@launch
            if (draft.subject.isBlank() && draft.body.isBlank() && draft.toRecipients.isBlank()) return@launch
            val acc = uiState.value.accounts.firstOrNull { it.id == draft.accountId }
            val entity = MessageEntity(
                id = draft.messageId,
                accountId = draft.accountId,
                folderId = "fld_work_drafts",
                threadId = draft.threadId.ifBlank { "thr_${draft.messageId}" },
                subject = draft.subject.ifBlank { "(No subject)" },
                senderName = acc?.displayName ?: "Elena Vance",
                senderEmail = draft.sendingIdentityEmail,
                toRecipients = draft.toRecipients,
                ccRecipients = draft.ccRecipients,
                bccRecipients = draft.bccRecipients,
                bodyPlainText = draft.body,
                bodyHtml = "<p>${draft.body.replace("\n", "<br/>")}</p>",
                snippet = draft.body.take(90),
                timestampEpochMs = System.currentTimeMillis(),
                isRead = true,
                deliveryStatus = DeliveryStatus.DRAFT.name,
                sendingIdentityEmail = draft.sendingIdentityEmail,
                messageIdHeader = "<${draft.messageId}@aureom-corp.example>",
                idempotencyKey = draft.idempotencyKey
            )
            repository.saveDraft(entity)
        }
    }

    fun attachSampleToDraft(fileName: String, mimeType: String, sizeBytes: Long) {
        val draft = _composer.value
        viewModelScope.launch {
            val result = repository.attachDemoFile(draft.messageId, draft.accountId, fileName, mimeType, sizeBytes)
            _statusSnackbar.value = result
        }
    }

    fun closeComposer(saveAsDraft: Boolean = true) {
        if (saveAsDraft) {
            scheduleDraftAutosave()
        }
        _composer.update { it.copy(isOpen = false) }
    }

    fun sendComposerMessage() {
        val draft = _composer.value
        if (draft.toRecipients.isBlank()) {
            _statusSnackbar.value = "Please enter at least one recipient in To."
            return
        }
        autosaveJob?.cancel()
        viewModelScope.launch {
            val settings = uiState.value.settings
            val acc = uiState.value.accounts.firstOrNull { it.id == draft.accountId }
            val scheduledMs = draft.scheduledOffsetMinutes?.let {
                System.currentTimeMillis() + it * 60_000L
            }
            val entity = MessageEntity(
                id = draft.messageId,
                accountId = draft.accountId,
                folderId = "fld_work_drafts",
                threadId = draft.threadId.ifBlank { "thr_${draft.messageId}" },
                subject = draft.subject.ifBlank { "(No subject)" },
                senderName = acc?.displayName ?: "Elena Vance",
                senderEmail = draft.sendingIdentityEmail,
                toRecipients = draft.toRecipients,
                ccRecipients = draft.ccRecipients,
                bccRecipients = draft.bccRecipients,
                bodyPlainText = draft.body,
                bodyHtml = "<p>${draft.body.replace("\n", "<br/>")}</p>",
                snippet = draft.body.take(90),
                timestampEpochMs = System.currentTimeMillis(),
                isRead = true,
                sendingIdentityEmail = draft.sendingIdentityEmail,
                messageIdHeader = "<${draft.messageId}@aureom-corp.example>",
                idempotencyKey = draft.idempotencyKey
            )
            try {
                val res = repository.queueOrSendMessage(
                    draft = entity,
                    delayWindowSeconds = settings.delayedSendSeconds,
                    scheduledEpochMs = scheduledMs,
                    isOffline = settings.isOfflineMode,
                    simulateUncertain = draft.simulateUncertainOutcome
                )
                _composer.update { it.copy(isOpen = false) }
                when (res.deliveryStatus) {
                    DeliveryStatus.QUEUED_OFFLINE.name ->
                        _statusSnackbar.value = "Offline: Message queued in Outbox (not sent)."
                    DeliveryStatus.DELAYED_SEND.name -> {
                        val isScheduled = scheduledMs != null
                        val windowSec = if (isScheduled) (draft.scheduledOffsetMinutes ?: 15) * 60 else settings.delayedSendSeconds
                        startDelayedSendCountdown(res.id, res.subject, windowSec, isScheduled, draft.simulateUncertainOutcome)
                    }
                    DeliveryStatus.UNCERTAIN.name ->
                        _statusSnackbar.value = "Uncertain submission outcome: check Outbox before retrying."
                    DeliveryStatus.SUBMITTED.name ->
                        _statusSnackbar.value = "Submitted to provider (SMTP/API accepted; delivery not read-receipted)."
                    else ->
                        _statusSnackbar.value = "Status: ${res.deliveryStatus}"
                }
            } catch (e: Exception) {
                _statusSnackbar.value = e.message ?: "Send failed."
            }
        }
    }

    private fun startDelayedSendCountdown(
        messageId: String,
        subject: String,
        seconds: Int,
        isScheduled: Boolean,
        simulateUncertain: Boolean
    ) {
        delayedSendJob?.cancel()
        delayedSendJob = viewModelScope.launch {
            var remaining = seconds
            while (remaining > 0) {
                _pendingDelayedSend.value = PendingDelayedSendBanner(messageId, subject, remaining, isScheduled)
                delay(1_000L)
                remaining--
                if (isScheduled && remaining < seconds - 12) {
                    // Keep scheduled item cancellable in Drafts/Outbox without blocking forever
                    _pendingDelayedSend.value = null
                    _statusSnackbar.value = "Scheduled '$subject'. You can cancel it anytime before send."
                    return@launch
                }
            }
            _pendingDelayedSend.value = null
            val finalized = repository.finalizeDelayedSendIfNotCancelled(messageId, simulateUncertain)
            if (finalized?.deliveryStatus == DeliveryStatus.UNCERTAIN.name) {
                _statusSnackbar.value = "Submission outcome uncertain! Inspect Outbox before retrying."
            } else if (finalized?.deliveryStatus == DeliveryStatus.SUBMITTED.name) {
                _statusSnackbar.value = "Submitted '$subject' to provider."
            }
        }
    }

    fun undoDelayedSend() {
        val pending = _pendingDelayedSend.value ?: return
        delayedSendJob?.cancel()
        _pendingDelayedSend.value = null
        viewModelScope.launch {
            val cancelled = repository.cancelDelayedSend(pending.messageId)
            if (cancelled) {
                val restored = uiState.value.allMessages.firstOrNull { it.id == pending.messageId }
                if (restored != null) {
                    openExistingDraft(restored)
                }
                _statusSnackbar.value = "Send cancelled during local delay window. Restored to Drafts."
            }
        }
    }

    // Sync & Offline Reconciliation
    fun syncAccount(accountId: String, recoverUidValidity: Boolean = false) {
        viewModelScope.launch {
            val result = repository.syncAccount(accountId, recoverUidValidity, uiState.value.settings.isOfflineMode)
            _statusSnackbar.value = result
        }
    }

    fun setOfflineMode(offline: Boolean) {
        viewModelScope.launch {
            prefs.setOfflineMode(offline)
            if (!offline) {
                val count = repository.reconcileOutboxWhenOnline()
                _statusSnackbar.value = if (count > 0) {
                    "Reconnected: reconciled $count queued operation(s)."
                } else {
                    "Online: all accounts ready."
                }
            } else {
                _statusSnackbar.value = "Offline mode enabled: local cache active, changes queued to Outbox."
            }
        }
    }

    fun reconcileOutbox() {
        viewModelScope.launch {
            val count = repository.reconcileOutboxWhenOnline()
            _statusSnackbar.value = "Reconciled $count queued operation(s)."
        }
    }

    fun resolveUncertainOperation(opId: String, markDelivered: Boolean) {
        viewModelScope.launch {
            repository.resolveUncertainOutbox(opId, markDelivered)
            _statusSnackbar.value = if (markDelivered) {
                "Marked message as already delivered (no duplicate sent)."
            } else {
                "Re-queued cleanly with new idempotency key."
            }
        }
    }

    // Search & Files
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isBlank()) {
            _isSearchActive.value = false
            _searchResults.value = emptyList()
            return
        }
        _isSearchActive.value = true
        viewModelScope.launch {
            _searchResults.value = repository.searchMessages(query)
        }
    }

    fun saveCurrentSearch(name: String) {
        val q = _searchQuery.value.trim()
        if (q.isBlank() || name.isBlank()) return
        viewModelScope.launch {
            repository.saveSearch(
                SavedSearchEntity(
                    id = "srch_${UUID.randomUUID().toString().take(6)}",
                    name = name.trim(),
                    query = q
                )
            )
            _statusSnackbar.value = "Saved search '$name'."
        }
    }

    fun runSavedSearch(saved: SavedSearchEntity) {
        updateSearchQuery(saved.query)
    }

    // Calendar Actions
    fun setCalendarViewMode(mode: CalendarViewMode) { _calendarViewMode.value = mode }
    fun setSelectedTimezone(tzId: String) { _selectedTimezoneId.value = tzId }

    fun createCalendarEvent(
        title: String,
        description: String,
        location: String,
        startEpochMs: Long,
        endEpochMs: Long,
        timezoneId: String,
        recurrenceRule: String,
        attendeesCsv: String,
        sendInvite: Boolean
    ) {
        viewModelScope.launch {
            val cal = uiState.value.calendars.firstOrNull()
            val offline = uiState.value.settings.isOfflineMode
            val sendState = when {
                !sendInvite || attendeesCsv.isBlank() -> InvitationSendState.LOCAL_ONLY.name
                offline -> InvitationSendState.PENDING_OFFLINE.name
                else -> InvitationSendState.INVITE_SENT.name
            }
            repository.upsertCalendarEvent(
                CalendarEventEntity(
                    id = "evt_${UUID.randomUUID().toString().take(8)}",
                    calendarId = cal?.id ?: "cal_work",
                    accountId = cal?.accountId ?: "acc_work",
                    title = title.ifBlank { "Untitled Meeting" },
                    description = description,
                    location = location,
                    startEpochMs = startEpochMs,
                    endEpochMs = endEpochMs,
                    timezoneId = timezoneId,
                    recurrenceRule = recurrenceRule,
                    attendeesCsv = attendeesCsv,
                    rsvpStatus = RsvpStatus.ORGANIZER.name,
                    invitationSendState = sendState,
                    conferencingJoinUrl = "https://meet.aureom.example/${UUID.randomUUID().toString().take(6)}"
                )
            )
            _statusSnackbar.value = when (sendState) {
                InvitationSendState.LOCAL_ONLY.name -> "Saved local appointment (no invites sent)."
                InvitationSendState.PENDING_OFFLINE.name -> "Saved locally; invite queued in Outbox."
                else -> "Meeting invitation sent to attendees."
            }
        }
    }

    fun rsvpEvent(eventId: String, status: RsvpStatus) {
        viewModelScope.launch {
            repository.updateRsvp(eventId, status.name)
            _statusSnackbar.value = "RSVP updated: ${status.name}"
        }
    }

    fun editSingleOccurrenceOnly(
        masterEventId: String,
        occurrenceStartMs: Long,
        newTitle: String,
        shiftHours: Long,
        newLocation: String
    ) {
        viewModelScope.launch {
            val shiftMs = shiftHours * 3_600_000L
            repository.editSingleRecurringOccurrence(
                masterEventId = masterEventId,
                occurrenceStartMs = occurrenceStartMs,
                newTitle = newTitle,
                newStartMs = occurrenceStartMs + shiftMs,
                newEndMs = occurrenceStartMs + shiftMs + 3_600_000L,
                newLocation = newLocation
            )
            _statusSnackbar.value = "Updated only this occurrence; recurring series preserved."
        }
    }

    fun exportCalendarIcs() {
        _exportedPreview.value = IcsCodec.exportEventsToIcs(uiState.value.events)
    }

    fun importCalendarIcs(icsText: String) {
        viewModelScope.launch {
            val cal = uiState.value.calendars.firstOrNull()
            val count = repository.importIcsText(icsText, cal?.id ?: "cal_work", cal?.accountId ?: "acc_work")
            _statusSnackbar.value = "Imported $count event(s) from ICS."
        }
    }

    // Contacts Actions
    fun addContact(name: String, email: String, org: String, title: String, phone: String) {
        if (name.isBlank() || email.isBlank()) return
        viewModelScope.launch {
            repository.upsertContact(
                ContactEntity(
                    id = "cnt_${UUID.randomUUID().toString().take(8)}",
                    accountId = "acc_work",
                    fullName = name.trim(),
                    primaryEmail = email.trim(),
                    phoneNumbersCsv = phone.trim(),
                    organization = org.trim(),
                    jobTitle = title.trim(),
                    isTrustedSavedContact = true,
                    lastInteractionEpochMs = System.currentTimeMillis()
                )
            )
            _statusSnackbar.value = "Saved contact '$name'."
        }
    }

    fun toggleContactFavorite(id: String) {
        viewModelScope.launch { repository.toggleContactFavorite(id) }
    }

    fun promoteContact(id: String) {
        viewModelScope.launch {
            repository.promoteToTrustedContact(id)
            _statusSnackbar.value = "Promoted suggestion to trusted saved contact."
        }
    }

    fun mergeDuplicateContacts(primaryId: String, duplicateId: String) {
        viewModelScope.launch {
            repository.mergeContacts(primaryId, duplicateId)
            _statusSnackbar.value = "Merged duplicate contact and preserved email/note records."
        }
    }

    // Tasks Actions
    fun addTask(title: String, listName: String, priority: String, dueHours: Long, recurrence: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.upsertTask(
                TaskEntity(
                    id = "tsk_${UUID.randomUUID().toString().take(8)}",
                    accountId = "acc_work",
                    listName = listName.ifBlank { "Personal" },
                    title = title.trim(),
                    dueEpochMs = System.currentTimeMillis() + dueHours * 3_600_000L,
                    priority = priority,
                    recurrenceRule = recurrence,
                    isInMyDay = true
                )
            )
        }
    }

    fun toggleTaskComplete(id: String) {
        viewModelScope.launch { repository.toggleTaskComplete(id) }
    }

    fun toggleTaskMyDay(id: String) {
        viewModelScope.launch { repository.toggleTaskMyDay(id) }
    }

    fun toggleTaskChecklistItem(taskId: String, lineIndex: Int) {
        viewModelScope.launch { repository.toggleChecklistItem(taskId, lineIndex) }
    }

    // Rules Actions
    fun addRule(
        name: String,
        accountId: String,
        scope: String,
        field: String,
        value: String,
        actionType: String,
        actionTarget: String,
        stopProcessing: Boolean,
        explicitForwardConfirmed: Boolean
    ) {
        if (name.isBlank() || value.isBlank()) return
        if (actionType == "FORWARD_EXPLICIT" && !explicitForwardConfirmed) {
            _statusSnackbar.value = "External forwarding rules require explicit confirmation."
            return
        }
        viewModelScope.launch {
            val nextOrder = (uiState.value.rules.maxOfOrNull { it.orderIndex } ?: 0) + 1
            repository.upsertRule(
                RuleEntity(
                    id = "rul_${UUID.randomUUID().toString().take(6)}",
                    accountId = accountId,
                    name = name.trim(),
                    orderIndex = nextOrder,
                    isEnabled = true,
                    scope = scope,
                    conditionField = field,
                    conditionValue = value.trim(),
                    actionType = actionType,
                    actionTarget = actionTarget.trim(),
                    stopProcessing = stopProcessing,
                    explicitForwardConfirmed = explicitForwardConfirmed
                )
            )
            _statusSnackbar.value = "Rule '$name' saved."
        }
    }

    fun toggleRuleEnabled(rule: RuleEntity) {
        viewModelScope.launch { repository.upsertRule(rule.copy(isEnabled = !rule.isEnabled)) }
    }

    fun deleteRule(id: String) {
        viewModelScope.launch { repository.deleteRule(id) }
    }

    // Settings & Preferences
    fun setThemeMode(mode: ThemeMode) { viewModelScope.launch { prefs.updateThemeMode(mode) } }
    fun setDensityMode(mode: DensityMode) { viewModelScope.launch { prefs.updateDensityMode(mode) } }
    fun setReadingPanePosition(pos: ReadingPanePosition) { viewModelScope.launch { prefs.updateReadingPanePosition(pos) } }
    fun toggleCalendarSidebar() { viewModelScope.launch { prefs.setShowCalendarSidebar(!uiState.value.settings.showCalendarSidebar) } }
    fun toggleConversationGrouping() { viewModelScope.launch { prefs.setConversationGrouping(!uiState.value.settings.conversationGrouping) } }
    fun setDelayedSendSeconds(sec: Int) { viewModelScope.launch { prefs.setDelayedSendSeconds(sec) } }
    fun setRemoteImagesDefault(blocked: Boolean) { viewModelScope.launch { prefs.setRemoteImagesBlockedByDefault(blocked) } }
    fun setRetentionDays(days: Int) { viewModelScope.launch { prefs.setRetentionDays(days) } }
    fun setAiMockMode(mock: Boolean) { viewModelScope.launch { prefs.setAiMockMode(mock) } }
    fun setReducedMotion(reduced: Boolean) { viewModelScope.launch { prefs.setReducedMotion(reduced) } }

    fun purgeLocalCache() {
        viewModelScope.launch {
            repository.purgeCacheOlderThan(uiState.value.settings.retentionDays)
            _statusSnackbar.value = "Purged local cached messages older than ${uiState.value.settings.retentionDays} days (server copies unaffected)."
        }
    }

    fun resetDemoWorkspace() {
        viewModelScope.launch {
            repository.resetDemoData()
            _selectedFolderId.value = null
            _selectedMessageId.value = null
            _selectedThreadId.value = null
            _copilotState.value = CopilotUiState.Idle
            _statusSnackbar.value = "Demonstration workspace restored to clean synthetic seed."
        }
    }

    fun setShowSettings(show: Boolean) { _showSettings.value = show }
    fun setShowDemoGuide(show: Boolean) { _showDemoGuide.value = show }
    fun setShowNotifications(show: Boolean) { _showNotifications.value = show }
    fun clearSnackbar() { _statusSnackbar.value = null }

    // Aureom Copilot Actions
    fun runCopilot(
        taskType: CopilotTaskType,
        draftInput: String = "",
        targetLanguage: String = "French",
        toneStyle: String = "Executive & Concise",
        userInstruction: String = ""
    ) {
        val state = uiState.value
        val settings = state.settings
        if (settings.aiDailyUsedCount >= settings.aiDailyBudgetLimit) {
            _copilotState.value = CopilotUiState.Error("Daily Aureom Copilot budget (${settings.aiDailyBudgetLimit} actions) reached.")
            return
        }

        // Scope strictly to authorized accounts & selected thread/message
        val authorizedAccountIds = state.accounts.filter { it.hasPermission("READ") && it.isSearchIndexedForUser }.map { it.id }.toSet()
        val selectedMsg = state.allMessages.firstOrNull { it.id == state.selectedMessageId }
        val threadMessages = if (selectedMsg != null && selectedMsg.accountId in authorizedAccountIds) {
            state.allMessages.filter { it.threadId == selectedMsg.threadId && it.accountId in authorizedAccountIds }
                .sortedBy { it.timestampEpochMs }
        } else {
            state.visibleMessages.filter { it.accountId in authorizedAccountIds }.take(3)
        }

        copilotJob?.cancel()
        copilotJob = viewModelScope.launch {
            _copilotState.value = CopilotUiState.Loading
            try {
                val result = copilotService.runTask(
                    taskType = taskType,
                    authorizedMessages = threadMessages,
                    upcomingEvents = state.events,
                    userInstruction = userInstruction,
                    draftInput = draftInput,
                    targetLanguage = targetLanguage,
                    toneStyle = toneStyle,
                    useMockMode = settings.aiMockMode,
                    isOffline = settings.isOfflineMode
                )
                prefs.incrementAiUsage()
                _copilotState.value = CopilotUiState.Success(result)
                repository.logAiAction(
                    actionType = taskType.name,
                    promptSummary = "Copilot ${taskType.name} on ${threadMessages.size} msg(s)",
                    resultPreview = result.title,
                    sourceIds = result.sourceMessageIds,
                    status = if (result.proposedActions.isNotEmpty()) AiActionLogStatus.AWAITING_APPROVAL else AiActionLogStatus.COMPLETED,
                    mode = result.modeUsed
                )
            } catch (e: Exception) {
                val msg = e.message ?: "Copilot inference failed."
                _copilotState.value = CopilotUiState.Error(msg)
                repository.logAiAction(
                    actionType = taskType.name,
                    promptSummary = "Copilot ${taskType.name}",
                    resultPreview = msg,
                    sourceIds = threadMessages.map { it.id },
                    status = AiActionLogStatus.ERROR,
                    mode = if (settings.aiMockMode) "LOCAL_MOCK" else "FIREBASE_AI"
                )
            }
        }
    }

    fun cancelCopilot() {
        copilotJob?.cancel()
        _copilotState.value = CopilotUiState.Idle
        viewModelScope.launch {
            repository.logAiAction(
                actionType = "CANCELLED",
                promptSummary = "User cancelled in-flight Copilot request",
                resultPreview = "Cancelled",
                sourceIds = emptyList(),
                status = AiActionLogStatus.CANCELLED,
                mode = if (uiState.value.settings.aiMockMode) "LOCAL_MOCK" else "FIREBASE_AI"
            )
        }
    }

    fun approveCopilotAction(action: ProposedCopilotAction) {
        viewModelScope.launch {
            when (action) {
                is ProposedCopilotAction.CreateTask -> {
                    val msg = uiState.value.allMessages.firstOrNull { it.id == action.linkedMessageId }
                    if (msg != null) {
                        repository.createTaskFromMessage(msg, listName = "Copilot Extracted")
                    } else {
                        repository.upsertTask(
                            TaskEntity(
                                id = "tsk_${UUID.randomUUID().toString().take(8)}",
                                accountId = "acc_work",
                                listName = "Copilot Extracted",
                                title = action.title,
                                notes = action.notes,
                                isInMyDay = true
                            )
                        )
                    }
                    _statusSnackbar.value = "Approved: Task created in My Day."
                }
                is ProposedCopilotAction.ProposeMeeting -> {
                    val start = System.currentTimeMillis() + 86_400_000L
                    createCalendarEvent(
                        title = action.title,
                        description = "Proposed by Aureom Copilot (approved by user).",
                        location = "Aureom Meet",
                        startEpochMs = start,
                        endEpochMs = start + 1_800_000L,
                        timezoneId = action.suggestedTimezone,
                        recurrenceRule = "NONE",
                        attendeesCsv = action.attendees,
                        sendInvite = false
                    )
                }
                is ProposedCopilotAction.ApplyCategory -> {
                    repository.addCategoryToMessage(action.messageId, action.category)
                    val msg = uiState.value.allMessages.firstOrNull { it.id == action.messageId }
                    val targetFolder = uiState.value.folders.firstOrNull {
                        it.accountId == msg?.accountId && it.name.equals(action.targetFolderName, ignoreCase = true)
                    }
                    if (targetFolder != null && msg != null) {
                        repository.moveMessageToFolder(msg.id, targetFolder.id, uiState.value.settings.isOfflineMode)
                    }
                    _statusSnackbar.value = "Approved: Applied category '${action.category}'."
                }
                is ProposedCopilotAction.InsertDraftReply -> {
                    _composer.value = ComposerDraftState(
                        isOpen = true,
                        messageId = "msg_cmp_${UUID.randomUUID().toString().take(8)}",
                        accountId = "acc_work",
                        sendingIdentityEmail = "elena.vance@aureom-corp.example",
                        toRecipients = action.toEmail,
                        subject = action.subject,
                        body = action.replyBody,
                        threadId = uiState.value.selectedThreadId ?: "thr_reply",
                        idempotencyKey = "idem_${UUID.randomUUID().toString().take(12)}"
                    )
                    _statusSnackbar.value = "Approved: Draft loaded into Composer for your review."
                }
            }
            repository.logAiAction(
                actionType = "USER_APPROVED_ACTION",
                promptSummary = action.toString().take(80),
                resultPreview = "Executed with explicit user approval",
                sourceIds = emptyList(),
                status = AiActionLogStatus.APPROVED,
                mode = if (uiState.value.settings.aiMockMode) "LOCAL_MOCK" else "FIREBASE_AI"
            )
        }
    }

    // 10-step Interactive Demo Walkthrough helper
    fun runDemoScenarioStep(stepIndex: Int) {
        _showDemoGuide.value = false
        when (stepIndex) {
            1 -> { // Open conversation
                selectSection(AppRailSection.MAIL)
                selectAccount("UNIFIED")
                selectSystemFolder(FolderSystemType.INBOX)
                uiState.value.allMessages.firstOrNull { it.id == "msg_02" }?.let { selectMessage(it) }
            }
            2 -> { // Search for related attachment
                selectSection(AppRailSection.FILES)
                updateSearchQuery("Budget")
            }
            3 -> { // Generate cited thread summary
                val msg = uiState.value.allMessages.firstOrNull { it.id == "msg_02" }
                if (msg != null) selectMessage(msg)
                selectSection(AppRailSection.COPILOT)
                runCopilot(CopilotTaskType.SUMMARIZE_THREAD)
            }
            4 -> { // Edit AI-drafted reply
                val msg = uiState.value.allMessages.firstOrNull { it.id == "msg_02" }
                if (msg != null) selectMessage(msg)
                selectSection(AppRailSection.COPILOT)
                runCopilot(CopilotTaskType.DRAFT_REPLY)
            }
            5 -> { // Schedule a message
                openNewComposer("acc_work")
                updateComposer {
                    it.copy(
                        toRecipients = "m.sterling@northstar-partners.example",
                        subject = "Scheduled Q4 Launch Contingency Confirmation",
                        body = "Hi Marcus,\n\nConfirming the $48,000 contingency cap ahead of Tuesday's Steering Committee.\n\nBest,\nElena",
                        scheduledOffsetMinutes = 15
                    )
                }
            }
            6 -> { // Test delayed-send cancellation (8s window)
                openNewComposer("acc_work")
                updateComposer {
                    it.copy(
                        toRecipients = "claire.dubois@aureom-corp.example",
                        subject = "Quick London Customs Note",
                        body = "Testing local delayed-send cancellation window before provider submission.",
                        scheduledOffsetMinutes = null
                    )
                }
            }
            7 -> { // Create task from original email
                val msg = uiState.value.allMessages.firstOrNull { it.id == "msg_01" }
                if (msg != null) createTaskFromMessage(msg)
                selectSection(AppRailSection.TASKS)
            }
            8 -> { // Propose meeting across timezones
                selectSection(AppRailSection.CALENDAR)
                setSelectedTimezone("Europe/London")
            }
            9 -> { // Handle offline operation
                setOfflineMode(true)
                selectSection(AppRailSection.MAIL)
            }
            10 -> { // Review failed sync & recover
                setOfflineMode(false)
                selectSection(AppRailSection.MAIL)
                selectAccount("acc_personal")
                setShowSettings(true)
            }
        }
    }
}
