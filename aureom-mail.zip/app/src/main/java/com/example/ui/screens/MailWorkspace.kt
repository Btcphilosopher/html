package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Forward
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.ReplyAll
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.DeliveryStatus
import com.example.data.local.FolderEntity
import com.example.data.local.FolderSystemType
import com.example.data.local.MessageEntity
import com.example.data.local.SyncHealth
import com.example.domain.CalendarMath
import com.example.domain.HtmlSanitizer
import com.example.domain.SenderSecurityAnalyzer
import com.example.ui.AureomUiState
import com.example.ui.AureomViewModel
import com.example.ui.MailFilterChip
import com.example.ui.MailSortOrder
import com.example.ui.theme.DensityMode
import com.example.ui.theme.LocalAureomColors
import com.example.ui.theme.ReadingPanePosition

@Composable
fun MailWorkspace(
    state: AureomUiState,
    viewModel: AureomViewModel,
    isExpanded: Boolean,
    isMedium: Boolean,
    compactShowReader: Boolean,
    onCompactOpenReader: () -> Unit,
    onCompactCloseReader: () -> Unit,
    onOpenCopilotSummary: () -> Unit
) {
    val ext = LocalAureomColors.current
    var showCreateFolderDialog by remember { mutableStateOf(false) }

    if (!isExpanded && !isMedium && compactShowReader) {
        BackHandler { onCompactCloseReader() }
        ReadingPane(
            state = state,
            viewModel = viewModel,
            showBackButton = true,
            onBack = onCompactCloseReader,
            onOpenCopilotSummary = onOpenCopilotSummary,
            modifier = Modifier.fillMaxSize()
        )
        return
    }

    Row(modifier = Modifier.fillMaxSize()) {
        if (isExpanded) {
            FolderNavigationPane(
                state = state,
                onSelectAccount = viewModel::selectAccount,
                onSelectSystemFolder = viewModel::selectSystemFolder,
                onSelectCustomFolder = viewModel::selectCustomFolder,
                onSyncAccount = { viewModel.syncAccount(it, recoverUidValidity = false) },
                onRecoverImap = { viewModel.syncAccount(it, recoverUidValidity = true) },
                onNewFolderClick = { showCreateFolderDialog = true },
                modifier = Modifier
                    .width(235.dp)
                    .fillMaxHeight()
            )
        }

        val panePos = state.settings.readingPanePosition
        if (isExpanded || isMedium) {
            when (panePos) {
                ReadingPanePosition.RIGHT -> {
                    MessageListPane(
                        state = state,
                        viewModel = viewModel,
                        onMessageClick = { msg ->
                            if (msg.deliveryStatus == DeliveryStatus.DRAFT.name) {
                                viewModel.openExistingDraft(msg)
                            } else {
                                viewModel.selectMessage(msg)
                            }
                        },
                        modifier = Modifier
                            .weight(0.44f)
                            .fillMaxHeight()
                    )
                    ReadingPane(
                        state = state,
                        viewModel = viewModel,
                        showBackButton = false,
                        onBack = {},
                        onOpenCopilotSummary = onOpenCopilotSummary,
                        modifier = Modifier
                            .weight(0.56f)
                            .fillMaxHeight()
                    )
                }
                ReadingPanePosition.BELOW -> {
                    Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                        MessageListPane(
                            state = state,
                            viewModel = viewModel,
                            onMessageClick = { msg ->
                                if (msg.deliveryStatus == DeliveryStatus.DRAFT.name) {
                                    viewModel.openExistingDraft(msg)
                                } else {
                                    viewModel.selectMessage(msg)
                                }
                            },
                            modifier = Modifier
                                .weight(0.46f)
                                .fillMaxWidth()
                        )
                        ReadingPane(
                            state = state,
                            viewModel = viewModel,
                            showBackButton = false,
                            onBack = {},
                            onOpenCopilotSummary = onOpenCopilotSummary,
                            modifier = Modifier
                                .weight(0.54f)
                                .fillMaxWidth()
                        )
                    }
                }
                ReadingPanePosition.HIDDEN -> {
                    MessageListPane(
                        state = state,
                        viewModel = viewModel,
                        onMessageClick = { msg ->
                            if (msg.deliveryStatus == DeliveryStatus.DRAFT.name) {
                                viewModel.openExistingDraft(msg)
                            } else {
                                viewModel.selectMessage(msg)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        } else {
            // Compact Phone List View
            MessageListPane(
                state = state,
                viewModel = viewModel,
                onMessageClick = { msg ->
                    if (msg.deliveryStatus == DeliveryStatus.DRAFT.name) {
                        viewModel.openExistingDraft(msg)
                    } else {
                        viewModel.selectMessage(msg)
                        onCompactOpenReader()
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    if (showCreateFolderDialog) {
        CreateFolderDialog(
            state = state,
            onDismiss = { showCreateFolderDialog = false },
            onCreate = { accId, name, parentId ->
                viewModel.createCustomFolder(accId, name, parentId)
                showCreateFolderDialog = false
            }
        )
    }
}

@Composable
fun FolderNavigationPane(
    state: AureomUiState,
    onSelectAccount: (String) -> Unit,
    onSelectSystemFolder: (FolderSystemType) -> Unit,
    onSelectCustomFolder: (String, String) -> Unit,
    onSyncAccount: (String) -> Unit,
    onRecoverImap: (String) -> Unit,
    onNewFolderClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalAureomColors.current
    val systemFolders = listOf(
        Triple(FolderSystemType.INBOX, "Inbox", Icons.Filled.Inbox),
        Triple(FolderSystemType.DRAFTS, "Drafts", Icons.Filled.Edit),
        Triple(FolderSystemType.SENT, "Sent", Icons.Filled.Schedule),
        Triple(FolderSystemType.ARCHIVE, "Archive", Icons.Filled.Archive),
        Triple(FolderSystemType.JUNK, "Junk", Icons.Filled.Report),
        Triple(FolderSystemType.DELETED, "Deleted", Icons.Filled.Delete)
    )
    val customFolders = state.folders.filter { it.systemType == FolderSystemType.CUSTOM.name }

    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier.border(1.dp, ext.borderSubtle)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            item {
                Text(
                    "FOLDERS",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            items(systemFolders) { (type, label, icon) ->
                val selected = state.settings.selectedFolderSystemType == type.name && state.selectedFolderId == null
                val unread = state.allMessages.count { m ->
                    val folder = state.folders.firstOrNull { it.id == m.folderId }
                    folder?.systemType == type.name &&
                        (state.settings.selectedAccountId == "UNIFIED" || m.accountId == state.settings.selectedAccountId) &&
                        !m.isRead
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                        .clickable { onSelectSystemFolder(type) }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                        .testTag("folder_${type.name.lowercase()}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.weight(1f)
                    )
                    if (unread > 0) {
                        Text(
                            text = "$unread",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "CUSTOM & NESTED",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    IconButton(onClick = onNewFolderClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Filled.CreateNewFolder, contentDescription = "Create folder", modifier = Modifier.size(16.dp))
                    }
                }
            }
            items(customFolders, key = { it.id }) { folder ->
                val isNested = folder.parentFolderId != null
                val selected = state.selectedFolderId == folder.id
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                        .clickable { onSelectCustomFolder(folder.accountId, folder.id) }
                        .padding(start = if (isNested) 24.dp else 10.dp, end = 10.dp, top = 7.dp, bottom = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Folder,
                        contentDescription = folder.name,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(folder.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = ext.borderSubtle)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "ACCOUNTS & SHARED MAILBOXES",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            item {
                val unifiedSelected = state.settings.selectedAccountId == "UNIFIED"
                Surface(
                    color = if (unifiedSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectAccount("UNIFIED") }
                ) {
                    Text(
                        text = "Unified Inbox (All Permitted)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (unifiedSelected) FontWeight.SemiBold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    )
                }
            }
            items(state.accounts, key = { it.id }) { acc ->
                val selected = state.settings.selectedAccountId == acc.id
                val failed = acc.syncHealth == SyncHealth.FAILED.name
                Surface(
                    color = if (selected) MaterialTheme.colorScheme.primaryContainer else ext.surfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (failed) ext.danger else ext.borderSubtle, RoundedCornerShape(8.dp))
                        .clickable { onSelectAccount(acc.id) }
                        .testTag("account_card_${acc.id}")
                ) {
                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AvatarCircle(acc.displayName, acc.avatarColorHex, sizeDp = 24)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(acc.displayName, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(acc.email, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { onSyncAccount(acc.id) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Filled.Sync, contentDescription = "Sync ${acc.displayName}", modifier = Modifier.size(16.dp))
                            }
                        }
                        if (acc.isSharedMailbox) {
                            StatusChip(
                                text = "Shared · ${acc.sharedPermissions}",
                                containerColor = ext.copilotSoft,
                                contentColor = ext.copilotAccent
                            )
                        }
                        if (failed) {
                            Text(
                                text = acc.syncErrorMessage ?: "Sync error",
                                style = MaterialTheme.typography.bodySmall,
                                color = ext.danger,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            TextButton(
                                onClick = { onRecoverImap(acc.id) },
                                modifier = Modifier.testTag("recover_sync_${acc.id}")
                            ) {
                                Text("Recover IMAP UIDVALIDITY", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MessageListPane(
    state: AureomUiState,
    viewModel: AureomViewModel,
    onMessageClick: (MessageEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalAureomColors.current
    val compact = state.settings.densityMode == DensityMode.COMPACT
    val rowPadding = if (compact) 8.dp else 12.dp
    var sortMenuOpen by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .background(ext.surfaceElevated)
            .border(1.dp, ext.borderSubtle)
    ) {
        // Toolbar: Sort, Conversation Grouping, Bulk Actions
        if (state.selectedBulkIds.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    "${state.selectedBulkIds.size} selected",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { viewModel.bulkMarkRead(true) }) {
                    Icon(Icons.Filled.MarkEmailRead, contentDescription = "Bulk mark read")
                }
                IconButton(onClick = { viewModel.bulkArchive() }) {
                    Icon(Icons.Filled.Archive, contentDescription = "Bulk archive")
                }
                TextButton(onClick = viewModel::clearBulkSelection) {
                    Text("Clear")
                }
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${state.settings.selectedFolderSystemType.lowercase().replaceFirstChar { it.uppercase() }} (${state.visibleMessages.size})",
                    style = MaterialTheme.typography.titleMedium
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(
                        selected = state.settings.conversationGrouping,
                        onClick = viewModel::toggleConversationGrouping,
                        label = { Text("Threads", style = MaterialTheme.typography.labelMedium) }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box {
                        TextButton(onClick = { sortMenuOpen = true }) {
                            Text("Sort: ${state.sortOrder.name.lowercase()}", style = MaterialTheme.typography.labelMedium)
                        }
                        DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                            MailSortOrder.entries.forEach { order ->
                                DropdownMenuItem(
                                    text = { Text(order.name.replace('_', ' ')) },
                                    onClick = {
                                        viewModel.setSortOrder(order)
                                        sortMenuOpen = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Filter Chips row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MailFilterChip.entries.forEach { chip ->
                FilterChip(
                    selected = state.filterChip == chip,
                    onClick = { viewModel.setFilterChip(chip) },
                    label = {
                        Text(
                            chip.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                )
            }
        }
        HorizontalDivider(color = ext.borderSubtle)

        if (state.visibleMessages.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Inbox, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                    Text("No messages match this view", style = MaterialTheme.typography.titleMedium)
                    Text("Try switching folders, clearing filters, or syncing an account.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(state.visibleMessages, key = { it.id }) { msg ->
                    val selected = state.selectedMessageId == msg.id
                    val bulkChecked = msg.id in state.selectedBulkIds
                    val threadCount = state.allMessages.count { it.threadId == msg.threadId }
                    val hasAttach = state.attachments.any { it.messageId == msg.id }
                    val securityWarn = SenderSecurityAnalyzer.analyze(msg)

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                when {
                                    selected -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                                    !msg.isRead -> MaterialTheme.colorScheme.surface
                                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                }
                            )
                            .clickable { onMessageClick(msg) }
                            .padding(horizontal = 10.dp, vertical = rowPadding)
                            .testTag("message_row_${msg.id}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.toggleBulkSelection(msg.id) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = if (bulkChecked) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                                    contentDescription = "Select message",
                                    tint = if (bulkChecked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (!msg.isRead) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(MaterialTheme.colorScheme.primary)
                                        )
                                    }
                                    Text(
                                        text = msg.senderName,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = if (!msg.isRead) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (threadCount > 1 && state.settings.conversationGrouping) {
                                        StatusChip("$threadCount", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                                    }
                                    if (msg.isPinned) {
                                        Icon(Icons.Filled.PushPin, contentDescription = "Pinned", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                                    }
                                    if (msg.isFlagged) {
                                        Icon(Icons.Filled.Flag, contentDescription = "Flagged", tint = ext.warning, modifier = Modifier.size(14.dp))
                                    }
                                    if (hasAttach) {
                                        Icon(Icons.Filled.AttachFile, contentDescription = "Has attachments", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                                    }
                                }
                                Text(
                                    text = msg.subject,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (!msg.isRead) FontWeight.SemiBold else FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = msg.snippet,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = if (compact) 1 else 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(
                                    modifier = Modifier.padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = CalendarMath.formatInZone(msg.timestampEpochMs, state.selectedTimezoneId, "MMM d, HH:mm"),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (msg.snoozedUntilEpochMs != null) {
                                        StatusChip("Snoozed", ext.warningSoft, ext.warning)
                                    }
                                    if (msg.deliveryStatus != DeliveryStatus.RECEIVED.name) {
                                        StatusChip(msg.deliveryStatus, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary)
                                    }
                                    if (securityWarn != null) {
                                        StatusChip("Security Check", ext.dangerSoft, ext.danger)
                                    }
                                    msg.categories.split(",").filter { it.isNotBlank() }.take(2).forEach { cat ->
                                        StatusChip(cat.trim(), MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                    HorizontalDivider(color = ext.borderSubtle)
                }
            }
        }
    }
}

@Composable
fun ReadingPane(
    state: AureomUiState,
    viewModel: AureomViewModel,
    showBackButton: Boolean,
    onBack: () -> Unit,
    onOpenCopilotSummary: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalAureomColors.current
    val selected = state.allMessages.firstOrNull { it.id == state.selectedMessageId }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        if (selected == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Select a conversation to read", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            return@Surface
        }

        val threadMessages = if (state.settings.conversationGrouping) {
            state.allMessages.filter { it.threadId == selected.threadId }.sortedBy { it.timestampEpochMs }
        } else {
            listOf(selected)
        }
        val account = state.accounts.firstOrNull { it.id == selected.accountId }
        val accountFolders = state.folders.filter { it.accountId == selected.accountId }
        var moveMenuOpen by remember { mutableStateOf(false) }
        var snoozeMenuOpen by remember { mutableStateOf(false) }
        var categoryMenuOpen by remember { mutableStateOf(false) }
        var internalNoteDraft by remember(selected.id) { mutableStateOf(selected.internalNote.orEmpty()) }

        Column(modifier = Modifier.fillMaxSize()) {
            // Action Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                if (showBackButton) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to list")
                    }
                }
                IconButton(onClick = { viewModel.openReplyComposer(selected, replyAll = false) }, modifier = Modifier.testTag("reply_button")) {
                    Icon(Icons.AutoMirrored.Filled.Reply, contentDescription = "Reply")
                }
                IconButton(onClick = { viewModel.openReplyComposer(selected, replyAll = true) }) {
                    Icon(Icons.AutoMirrored.Filled.ReplyAll, contentDescription = "Reply All")
                }
                IconButton(onClick = { viewModel.openReplyComposer(selected, forward = true) }) {
                    Icon(Icons.AutoMirrored.Filled.Forward, contentDescription = "Forward")
                }
                IconButton(onClick = { viewModel.toggleRead(selected) }) {
                    Icon(
                        if (selected.isRead) Icons.Filled.MarkEmailUnread else Icons.Filled.MarkEmailRead,
                        contentDescription = "Toggle read"
                    )
                }
                IconButton(onClick = { viewModel.togglePin(selected) }) {
                    Icon(
                        if (selected.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                        contentDescription = "Pin message",
                        tint = if (selected.isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = { viewModel.toggleFlag(selected) }) {
                    Icon(
                        if (selected.isFlagged) Icons.Filled.Flag else Icons.Outlined.Flag,
                        contentDescription = "Flag for follow-up",
                        tint = if (selected.isFlagged) ext.warning else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Box {
                    IconButton(onClick = { snoozeMenuOpen = true }) {
                        Icon(Icons.Filled.Snooze, contentDescription = "Snooze message")
                    }
                    DropdownMenu(expanded = snoozeMenuOpen, onDismissRequest = { snoozeMenuOpen = false }) {
                        DropdownMenuItem(text = { Text("Snooze 4 hours") }, onClick = { viewModel.snoozeMessage(selected.id, 4); snoozeMenuOpen = false })
                        DropdownMenuItem(text = { Text("Snooze until tomorrow (24h)") }, onClick = { viewModel.snoozeMessage(selected.id, 24); snoozeMenuOpen = false })
                        if (selected.snoozedUntilEpochMs != null) {
                            DropdownMenuItem(text = { Text("Unsnooze now") }, onClick = { viewModel.unsnoozeMessage(selected.id); snoozeMenuOpen = false })
                        }
                    }
                }
                Box {
                    IconButton(onClick = { moveMenuOpen = true }) {
                        Icon(Icons.Filled.DriveFileMove, contentDescription = "Move to folder")
                    }
                    DropdownMenu(expanded = moveMenuOpen, onDismissRequest = { moveMenuOpen = false }) {
                        accountFolders.forEach { folder ->
                            DropdownMenuItem(
                                text = { Text("Move to ${folder.name}") },
                                onClick = {
                                    viewModel.moveMessageToFolder(selected.id, folder.id)
                                    moveMenuOpen = false
                                }
                            )
                        }
                    }
                }
                IconButton(onClick = { viewModel.createTaskFromMessage(selected) }, modifier = Modifier.testTag("convert_to_task_button")) {
                    Icon(Icons.Filled.TaskAlt, contentDescription = "Create task from email")
                }
                IconButton(onClick = { viewModel.exportMessageEml(selected) }) {
                    Icon(Icons.Filled.Download, contentDescription = "Export EML")
                }
                Spacer(modifier = Modifier.weight(1f))
                OutlinedButton(onClick = onOpenCopilotSummary, modifier = Modifier.testTag("copilot_summarize_button")) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copilot", style = MaterialTheme.typography.labelMedium)
                }
            }
            HorizontalDivider(color = ext.borderSubtle)

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Subject + Categories + Plain text toggle
                Text(selected.subject, style = MaterialTheme.typography.headlineMedium)

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    if (account != null) {
                        StatusChip(account.displayName, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary)
                    }
                    selected.categories.split(",").filter { it.isNotBlank() }.forEach { cat ->
                        StatusChip(cat.trim(), MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                    Box {
                        TextButton(onClick = { categoryMenuOpen = true }) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                            Text("Category", style = MaterialTheme.typography.labelMedium)
                        }
                        DropdownMenu(expanded = categoryMenuOpen, onDismissRequest = { categoryMenuOpen = false }) {
                            listOf("Executive", "Finance", "Q4 Launch", "Operations", "Security Review").forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat) },
                                    onClick = {
                                        viewModel.addCategory(selected.id, cat)
                                        categoryMenuOpen = false
                                    }
                                )
                            }
                        }
                    }
                    TextButton(onClick = viewModel::togglePlainTextBody) {
                        Icon(Icons.Filled.Code, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            if (state.showPlainTextBody) "Sanitized View" else "Plain-Text View",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }

                // Shared mailbox collaboration panel (notes kept strictly separate from outgoing mail!)
                if (account?.isSharedMailbox == true) {
                    Surface(
                        color = ext.copilotSoft,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ext.copilotAccent.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                "Shared Mailbox Collaboration · Owner: ${selected.assignedOwner ?: "Unassigned"}",
                                style = MaterialTheme.typography.labelLarge,
                                color = ext.copilotAccent
                            )
                            Text(
                                "Internal notes are never included in outgoing replies.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedTextField(
                                value = internalNoteDraft,
                                onValueChange = { internalNoteDraft = it },
                                label = { Text("Internal team note") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = { viewModel.saveSharedMailboxNote(selected.id, internalNoteDraft, "Elena Vance") }) {
                                    Text("Save Internal Note")
                                }
                            }
                        }
                    }
                }

                // Conversation messages
                threadMessages.forEach { msg ->
                    val securityWarning = SenderSecurityAnalyzer.analyze(msg)
                    val sanitized = remember(msg.id, msg.bodyHtml, msg.remoteImagesBlocked) {
                        HtmlSanitizer.sanitize(msg.bodyHtml, blockRemoteImages = msg.remoteImagesBlocked)
                    }
                    val msgAttachments = state.attachments.filter { it.messageId == msg.id }

                    Surface(
                        color = ext.surfaceElevated,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ext.borderSubtle, RoundedCornerShape(10.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AvatarCircle(msg.senderName, account?.avatarColorHex ?: 0xFF0F6CBD)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${msg.senderName} <${msg.senderEmail}>", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "To: ${msg.toRecipients}" + if (msg.ccRecipients.isNotBlank()) " · Cc: ${msg.ccRecipients}" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (!msg.replyToEmail.isNullOrBlank()) {
                                        Text(
                                            "Reply-To: ${msg.replyToEmail}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = ext.danger,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                                Text(
                                    CalendarMath.formatInZone(msg.timestampEpochMs, state.selectedTimezoneId),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                IconButton(onClick = viewModel::toggleExpandedHeaders, modifier = Modifier.size(30.dp)) {
                                    Icon(
                                        if (state.showExpandedHeaders) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                        contentDescription = "Toggle headers"
                                    )
                                }
                            }

                            if (state.showExpandedHeaders) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text("Message-ID: ${msg.messageIdHeader}", style = MaterialTheme.typography.labelSmall)
                                        Text("Provider-UID: ${msg.providerUid ?: "Local Draft"}", style = MaterialTheme.typography.labelSmall)
                                        Text(
                                            "Provider Auth Claims (unverified locally): SPF=${msg.authSpf} · DKIM=${msg.authDkim} · DMARC=${msg.authDmarc}",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }
                            }

                            // Security alerts (Reply-To mismatch, auth fail, stripped scripts, blocked remote images)
                            if (securityWarning != null) {
                                Surface(
                                    color = ext.dangerSoft,
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Warning, contentDescription = null, tint = ext.danger, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(securityWarning.summary, style = MaterialTheme.typography.bodySmall, color = ext.danger)
                                    }
                                }
                            }

                            if (sanitized.strippedDangerousTagsCount > 0 || sanitized.blockedRemoteImageCount > 0) {
                                Surface(
                                    color = ext.warningSoft,
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.Security, contentDescription = null, tint = ext.warning, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = buildString {
                                                    if (sanitized.strippedDangerousTagsCount > 0) {
                                                        append("Stripped ${sanitized.strippedDangerousTagsCount} active script/tag(s). ")
                                                    }
                                                    if (sanitized.blockedRemoteImageCount > 0) {
                                                        append("Blocked ${sanitized.blockedRemoteImageCount} remote tracking image(s).")
                                                    }
                                                },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = ext.warning
                                            )
                                        }
                                        if (sanitized.blockedRemoteImageCount > 0) {
                                            TextButton(onClick = { viewModel.setRemoteImagesBlocked(msg.id, false) }) {
                                                Text("Allow Images", style = MaterialTheme.typography.labelMedium)
                                            }
                                        }
                                    }
                                }
                            }

                            // Safe body rendering
                            Text(
                                text = if (state.showPlainTextBody) msg.bodyPlainText else sanitized.plainText,
                                style = MaterialTheme.typography.bodyLarge
                            )

                            if (sanitized.safeLinks.isNotEmpty()) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Extracted Safe Link Inspector:", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    sanitized.safeLinks.forEach { link ->
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Icon(Icons.Filled.Shield, contentDescription = null, tint = if (link.isHttpInsecure) ext.danger else ext.success, modifier = Modifier.size(14.dp))
                                            Text(
                                                "${link.host} (${if (link.isHttpInsecure) "Unencrypted HTTP" else "HTTPS"})",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = if (link.isHttpInsecure) ext.danger else MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }

                            if (msgAttachments.isNotEmpty()) {
                                HorizontalDivider(color = ext.borderSubtle)
                                Text("Attachments (${msgAttachments.size})", style = MaterialTheme.typography.labelLarge)
                                msgAttachments.forEach { att ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Column {
                                                    Text(att.fileName, style = MaterialTheme.typography.labelLarge)
                                                    Text(
                                                        "${att.sizeBytes / 1024} KB · Scan: ${att.scanStatus}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = ext.success
                                                    )
                                                }
                                            }
                                            TextButton(onClick = { viewModel.selectSection(com.example.ui.AppRailSection.FILES) }) {
                                                Text("View in Files")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateFolderDialog(
    state: AureomUiState,
    onDismiss: () -> Unit,
    onCreate: (String, String, String?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    val activeAcc = state.accounts.firstOrNull { it.id == state.settings.selectedAccountId } ?: state.accounts.firstOrNull()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Custom Folder") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Account: ${activeAcc?.displayName ?: "Work"}", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Folder name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onCreate(activeAcc?.id ?: "acc_work", name, null) }) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
