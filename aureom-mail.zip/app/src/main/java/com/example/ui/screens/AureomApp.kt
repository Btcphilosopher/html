package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ai.CopilotTaskType
import com.example.ui.AppRailSection
import com.example.ui.AureomUiState
import com.example.ui.AureomViewModel
import com.example.ui.theme.AureomMailTheme
import com.example.ui.theme.LocalAureomColors
import kotlinx.coroutines.launch

@Composable
fun AureomMailApp(viewModel: AureomViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.statusSnackbar) {
        val msg = state.statusSnackbar
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    AureomMailTheme(themeMode = state.settings.themeMode) {
        val ext = LocalAureomColors.current
        var compactShowReader by remember { mutableStateOf(false) }
        val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
        val scope = rememberCoroutineScope()

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpanded = maxWidth >= 840.dp
            val isMedium = maxWidth >= 600.dp && maxWidth < 840.dp
            val isCompact = maxWidth < 600.dp

            val unreadTotal = state.allMessages.count { !it.isRead }

            val contentScaffold: @Composable () -> Unit = {
                Scaffold(
                    containerColor = ext.workspaceBackground,
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    topBar = {
                        AureomTopHeader(
                            state = state,
                            isCompact = isCompact,
                            onSearchChange = { q ->
                                viewModel.updateSearchQuery(q)
                                if (q.isNotBlank() && state.activeSection != AppRailSection.FILES) {
                                    viewModel.selectSection(AppRailSection.FILES)
                                }
                            },
                            onSelectAccount = viewModel::selectAccount,
                            onComposeClick = { viewModel.openNewComposer() },
                            onToggleOffline = { viewModel.setOfflineMode(!state.settings.isOfflineMode) },
                            onToggleCalendarSidebar = viewModel::toggleCalendarSidebar,
                            onOpenNotifications = { viewModel.setShowNotifications(true) },
                            onOpenDemoGuide = { viewModel.setShowDemoGuide(true) },
                            onOpenSettings = { viewModel.setShowSettings(true) },
                            onOpenDrawerOrFolders = if (isCompact) {
                                { scope.launch { drawerState.open() } }
                            } else null
                        )
                    },
                    bottomBar = {
                        if (isCompact && !compactShowReader) {
                            Box(modifier = Modifier.navigationBarsPadding()) {
                                AureomBottomBar(
                                    activeSection = state.activeSection,
                                    onSelectSection = { section ->
                                        compactShowReader = false
                                        viewModel.selectSection(section)
                                    }
                                )
                            }
                        }
                    },
                    floatingActionButton = {
                        if (isCompact && state.activeSection == AppRailSection.MAIL && !compactShowReader) {
                            FloatingActionButton(
                                onClick = { viewModel.openNewComposer() },
                                containerColor = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.testTag("compact_new_mail_fab")
                            ) {
                                Icon(Icons.Filled.Edit, contentDescription = "Compose new email")
                            }
                        }
                    }
                ) { innerPadding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        state.pendingDelayedSend?.let { banner ->
                            DelayedSendCountdownBar(
                                banner = banner,
                                onCancelSend = viewModel::undoDelayedSend
                            )
                        }

                        if (state.settings.isOfflineMode) {
                            Surface(
                                color = ext.warningSoft,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Offline mode active — drafts and local actions are cached and queued in Outbox until reconnection.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ext.warning,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            if (!isCompact) {
                                AureomVerticalRail(
                                    activeSection = state.activeSection,
                                    unreadCount = unreadTotal,
                                    onSelectSection = { section ->
                                        viewModel.selectSection(section)
                                    }
                                )
                            }

                            Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                                when (state.activeSection) {
                                    AppRailSection.MAIL -> MailWorkspace(
                                        state = state,
                                        viewModel = viewModel,
                                        isExpanded = isExpanded,
                                        isMedium = isMedium,
                                        compactShowReader = compactShowReader,
                                        onCompactOpenReader = { compactShowReader = true },
                                        onCompactCloseReader = { compactShowReader = false },
                                        onOpenCopilotSummary = {
                                            viewModel.selectSection(AppRailSection.COPILOT)
                                            viewModel.runCopilot(CopilotTaskType.SUMMARIZE_THREAD)
                                        }
                                    )
                                    AppRailSection.CALENDAR -> CalendarWorkspace(state = state, viewModel = viewModel)
                                    AppRailSection.PEOPLE -> PeopleWorkspace(state = state, viewModel = viewModel)
                                    AppRailSection.TASKS -> TasksWorkspace(state = state, viewModel = viewModel)
                                    AppRailSection.FILES -> FilesAndSearchWorkspace(state = state, viewModel = viewModel)
                                    AppRailSection.COPILOT -> CopilotWorkspace(state = state, viewModel = viewModel)
                                }
                            }

                            if (isExpanded && state.settings.showCalendarSidebar) {
                                MyDaySidebar(
                                    state = state,
                                    onToggleTaskComplete = viewModel::toggleTaskComplete,
                                    onOpenMessage = { msgId ->
                                        val msg = state.allMessages.firstOrNull { it.id == msgId }
                                        if (msg != null) {
                                            viewModel.selectMessage(msg)
                                            viewModel.selectSection(AppRailSection.MAIL)
                                        }
                                    },
                                    onOpenCalendar = { viewModel.selectSection(AppRailSection.CALENDAR) }
                                )
                            }
                        }
                    }
                }
            }

            if (isCompact) {
                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet {
                            FolderNavigationPane(
                                state = state,
                                onSelectAccount = {
                                    viewModel.selectAccount(it)
                                    scope.launch { drawerState.close() }
                                },
                                onSelectSystemFolder = {
                                    viewModel.selectSystemFolder(it)
                                    compactShowReader = false
                                    scope.launch { drawerState.close() }
                                },
                                onSelectCustomFolder = { acc, fld ->
                                    viewModel.selectCustomFolder(acc, fld)
                                    compactShowReader = false
                                    scope.launch { drawerState.close() }
                                },
                                onSyncAccount = { viewModel.syncAccount(it, recoverUidValidity = false) },
                                onRecoverImap = { viewModel.syncAccount(it, recoverUidValidity = true) },
                                onNewFolderClick = {
                                    viewModel.createCustomFolder(
                                        state.settings.selectedAccountId.takeIf { it != "UNIFIED" } ?: "acc_work",
                                        "Executive Review"
                                    )
                                    scope.launch { drawerState.close() }
                                },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    },
                    content = contentScaffold
                )
            } else {
                contentScaffold()
            }
        }

        // Modals & Dialogs
        ComposerDialog(state = state, viewModel = viewModel)
        SettingsAndRulesDialog(state = state, viewModel = viewModel)
        DemoWalkthroughDialog(state = state, viewModel = viewModel)
        NotificationsAndExportDialogs(state = state, viewModel = viewModel)
    }
}
