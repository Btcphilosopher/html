package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.OutboxStatus
import com.example.data.local.RuleScope
import com.example.data.local.SyncHealth
import com.example.domain.CalendarMath
import com.example.ui.AureomUiState
import com.example.ui.AureomViewModel
import com.example.ui.theme.DensityMode
import com.example.ui.theme.LocalAureomColors
import com.example.ui.theme.ReadingPanePosition
import com.example.ui.theme.ThemeMode

@Composable
fun SettingsAndRulesDialog(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    if (!state.showSettingsDialog) return
    val ext = LocalAureomColors.current
    var activeTab by remember { mutableStateOf("LAYOUT") }

    Dialog(
        onDismissRequest = { viewModel.setShowSettings(false) },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 16.dp)
                .border(1.dp, ext.borderSubtle, RoundedCornerShape(12.dp))
                .testTag("settings_dialog")
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ext.railBackground)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Settings, Sync, Rules & Privacy", style = MaterialTheme.typography.titleMedium, color = ext.railOnBackground)
                    IconButton(onClick = { viewModel.setShowSettings(false) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Close settings", tint = ext.railOnBackground)
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "LAYOUT" to "Appearance & Layout",
                        "SYNC" to "Sync & Outbox",
                        "RULES" to "Rules Engine",
                        "PRIVACY" to "Privacy & Cache"
                    ).forEach { (key, label) ->
                        FilterChip(selected = activeTab == key, onClick = { activeTab = key }, label = { Text(label) })
                    }
                }
                HorizontalDivider(color = ext.borderSubtle)

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (activeTab) {
                        "LAYOUT" -> {
                            Text("Theme Mode", style = MaterialTheme.typography.titleSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ThemeMode.entries.forEach { mode ->
                                    FilterChip(
                                        selected = state.settings.themeMode == mode,
                                        onClick = { viewModel.setThemeMode(mode) },
                                        label = { Text(mode.name) }
                                    )
                                }
                            }
                            Text("Density", style = MaterialTheme.typography.titleSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DensityMode.entries.forEach { d ->
                                    FilterChip(
                                        selected = state.settings.densityMode == d,
                                        onClick = { viewModel.setDensityMode(d) },
                                        label = { Text(d.name) }
                                    )
                                }
                            }
                            Text("Reading Pane Position (Desktop/Tablet)", style = MaterialTheme.typography.titleSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                ReadingPanePosition.entries.forEach { pos ->
                                    FilterChip(
                                        selected = state.settings.readingPanePosition == pos,
                                        onClick = { viewModel.setReadingPanePosition(pos) },
                                        label = { Text(pos.name) }
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Reduced Motion", style = MaterialTheme.typography.bodyMedium)
                                Switch(checked = state.settings.reducedMotion, onCheckedChange = viewModel::setReducedMotion)
                            }
                            Text("Local Delayed-Send Window: ${state.settings.delayedSendSeconds}s", style = MaterialTheme.typography.titleSmall)
                            Slider(
                                value = state.settings.delayedSendSeconds.toFloat(),
                                onValueChange = { viewModel.setDelayedSendSeconds(it.toInt()) },
                                valueRange = 0f..20f
                            )
                        }

                        "SYNC" -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Offline Mode Simulation", style = MaterialTheme.typography.titleSmall)
                                    Text("Caches mail locally and queues outgoing changes to durable Outbox.", style = MaterialTheme.typography.bodySmall)
                                }
                                Switch(checked = state.settings.isOfflineMode, onCheckedChange = viewModel::setOfflineMode)
                            }
                            HorizontalDivider(color = ext.borderSubtle)
                            Text("Connected Accounts & Adapter Health", style = MaterialTheme.typography.titleSmall)
                            state.accounts.forEach { acc ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("${acc.displayName} (${acc.providerType})", style = MaterialTheme.typography.labelLarge)
                                            StatusChip(
                                                acc.syncHealth,
                                                if (acc.syncHealth == SyncHealth.FAILED.name) ext.dangerSoft else ext.successSoft,
                                                if (acc.syncHealth == SyncHealth.FAILED.name) ext.danger else ext.success
                                            )
                                        }
                                        Text(
                                            "OAuth: ${acc.oauthTokenStatus} · Rate Limit Remaining: ${acc.rateLimitRemaining} · Last Sync: ${CalendarMath.formatInZone(acc.lastSyncEpochMs, state.selectedTimezoneId)}",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                        acc.imapUidValidity?.let {
                                            Text("IMAP UIDVALIDITY: $it · Last UID: ${acc.imapLastUid ?: 0}", style = MaterialTheme.typography.labelSmall)
                                        }
                                        acc.syncErrorMessage?.let { err ->
                                            Text(err, style = MaterialTheme.typography.bodySmall, color = ext.danger)
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OutlinedButton(onClick = { viewModel.syncAccount(acc.id, recoverUidValidity = false) }) {
                                                Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Sync Now")
                                            }
                                            if (acc.syncHealth == SyncHealth.FAILED.name) {
                                                Button(onClick = { viewModel.syncAccount(acc.id, recoverUidValidity = true) }) {
                                                    Text("Reset UIDVALIDITY & Recover")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(color = ext.borderSubtle)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Durable Outbox Queue (${state.outboxOps.size})", style = MaterialTheme.typography.titleSmall)
                                OutlinedButton(onClick = viewModel::reconcileOutbox) { Text("Reconcile Pending") }
                            }
                            state.outboxOps.forEach { op ->
                                Surface(
                                    color = if (op.status == OutboxStatus.UNCERTAIN_OUTCOME.name) ext.dangerSoft else MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("${op.operationType} · ${op.payloadSummary}", style = MaterialTheme.typography.labelLarge)
                                        Text("Status: ${op.status} · Idempotency: ${op.idempotencyKey}", style = MaterialTheme.typography.labelSmall)
                                        op.errorMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = ext.danger) }
                                        if (op.status == OutboxStatus.UNCERTAIN_OUTCOME.name) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                OutlinedButton(onClick = { viewModel.resolveUncertainOperation(op.id, markDelivered = true) }) {
                                                    Text("Confirm Delivered (No Retry)")
                                                }
                                                Button(onClick = { viewModel.resolveUncertainOperation(op.id, markDelivered = false) }) {
                                                    Text("Retry with New Key")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        "RULES" -> {
                            RulesBuilderSection(state, viewModel)
                        }

                        "PRIVACY" -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Block Remote Images by Default", style = MaterialTheme.typography.titleSmall)
                                    Text("Prevents external pixel tracking until explicitly allowed per message.", style = MaterialTheme.typography.bodySmall)
                                }
                                Switch(checked = state.settings.remoteImagesBlockedByDefault, onCheckedChange = viewModel::setRemoteImagesDefault)
                            }
                            Text("Local Cache Retention: ${state.settings.retentionDays} days", style = MaterialTheme.typography.titleSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(30, 90, 365).forEach { d ->
                                    FilterChip(selected = state.settings.retentionDays == d, onClick = { viewModel.setRetentionDays(d) }, label = { Text("${d}d") })
                                }
                            }
                            Surface(color = ext.warningSoft, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    "Disclosure: Purging local cache or removing an account locally clears on-device SQLite data only. It does not delete provider-held or recipient-held copies.",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = viewModel::purgeLocalCache) { Text("Purge Expired Local Cache") }
                                Button(onClick = viewModel::resetDemoWorkspace) {
                                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reset Demo Seed Data")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RulesBuilderSection(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    val ext = LocalAureomColors.current
    var name by remember { mutableStateOf("") }
    var condField by remember { mutableStateOf("SUBJECT") }
    var condValue by remember { mutableStateOf("") }
    var actionType by remember { mutableStateOf("APPLY_CATEGORY") }
    var actionTarget by remember { mutableStateOf("Executive") }
    var scope by remember { mutableStateOf(RuleScope.APP_SIDE.name) }
    var stopProcessing by remember { mutableStateOf(true) }
    var confirmForward by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            "App-side rules run locally during incremental sync & offline reconciliation; Provider-side rules execute on server even when the app is closed. Loop prevention blocks cyclic moves.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        state.rules.forEach { rule ->
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("#${rule.orderIndex} · ${rule.name}", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "${rule.scope} · IF ${rule.conditionField} contains '${rule.conditionValue}' -> ${rule.actionType} (${rule.actionTarget})" +
                                if (rule.stopProcessing) " · [Stop Processing]" else "",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Switch(checked = rule.isEnabled, onCheckedChange = { viewModel.toggleRuleEnabled(rule) })
                    IconButton(onClick = { viewModel.deleteRule(rule.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete rule", tint = ext.danger)
                    }
                }
            }
        }

        HorizontalDivider(color = ext.borderSubtle)
        Text("Create Rule", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Rule name") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf("SUBJECT", "SENDER", "RECIPIENT").forEach { f ->
                FilterChip(selected = condField == f, onClick = { condField = f }, label = { Text(f) })
            }
        }
        OutlinedTextField(value = condValue, onValueChange = { condValue = it }, label = { Text("Condition contains") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf("APPLY_CATEGORY", "MOVE_FOLDER", "MARK_READ", "FLAG", "NOTIFY", "FORWARD_EXPLICIT").forEach { a ->
                FilterChip(selected = actionType == a, onClick = { actionType = a }, label = { Text(a) })
            }
        }
        OutlinedTextField(value = actionTarget, onValueChange = { actionTarget = it }, label = { Text("Action target (category / folder / email)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = scope == RuleScope.APP_SIDE.name, onClick = { scope = RuleScope.APP_SIDE.name }, label = { Text("App-Side") })
            FilterChip(selected = scope == RuleScope.PROVIDER_SIDE.name, onClick = { scope = RuleScope.PROVIDER_SIDE.name }, label = { Text("Provider-Side") })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = stopProcessing, onCheckedChange = { stopProcessing = it })
            Text("Stop processing subsequent rules", style = MaterialTheme.typography.bodySmall)
        }
        if (actionType == "FORWARD_EXPLICIT") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = confirmForward, onCheckedChange = { confirmForward = it })
                Text("I explicitly confirm external forwarding to $actionTarget", style = MaterialTheme.typography.bodySmall, color = ext.danger)
            }
        }
        Button(onClick = {
            viewModel.addRule(name, "ALL", scope, condField, condValue, actionType, actionTarget, stopProcessing, confirmForward)
            name = ""
            condValue = ""
        }) { Text("Save Rule") }
    }
}

@Composable
fun DemoWalkthroughDialog(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    if (!state.showDemoGuideSheet) return
    val scenarios = listOf(
        1 to "1. Open a multi-message conversation (Q4 Nordic Launch)",
        2 to "2. Search for a related attachment (Budget / SLA)",
        3 to "3. Generate a cited thread summary with Aureom Copilot",
        4 to "4. Edit an AI-drafted reply & inspect approval gate",
        5 to "5. Schedule a message (+15 min)",
        6 to "6. Trigger local delayed-send & cancel before submission",
        7 to "7. Create a tracked task from an email without moving it",
        8 to "8. Propose a meeting across NY & London timezones",
        9 to "9. Queue an offline operation in durable Outbox",
        10 to "10. Review failed IMAP UIDVALIDITY sync & recover"
    )
    AlertDialog(
        onDismissRequest = { viewModel.setShowDemoGuide(false) },
        title = { Text("Aureom Mail Demonstration Scenarios") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "All accounts, emails, meetings, contacts, and files are 100% synthetic demonstration data persisted locally in SQLite.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                scenarios.forEach { (idx, label) ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.runDemoScenarioStep(idx) }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Launch step $idx", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { viewModel.setShowDemoGuide(false) }) { Text("Close") }
        }
    )
}

@Composable
fun NotificationsAndExportDialogs(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    if (state.showNotificationsSheet) {
        AlertDialog(
            onDismissRequest = { viewModel.setShowNotifications(false) },
            title = { Text("Notifications & Sync Alerts") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    state.notifications.forEach { note ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(note, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(10.dp))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.setShowNotifications(false) }) { Text("Close") }
            }
        )
    }

    state.exportedTextPreview?.let { exported ->
        AlertDialog(
            onDismissRequest = viewModel::dismissExportedPreview,
            title = { Text("Exported RFC Standard Payload") },
            text = {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    Text(
                        text = exported,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .padding(10.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = viewModel::dismissExportedPreview) { Text("Done") }
            }
        )
    }
}
