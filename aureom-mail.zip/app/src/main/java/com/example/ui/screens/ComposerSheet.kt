package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.AureomUiState
import com.example.ui.AureomViewModel
import com.example.ui.theme.LocalAureomColors

@Composable
fun ComposerDialog(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    val draft = state.composer
    if (!draft.isOpen) return

    val ext = LocalAureomColors.current
    var identityMenuOpen by remember { mutableStateOf(false) }
    var templateMenuOpen by remember { mutableStateOf(false) }
    var scheduleMenuOpen by remember { mutableStateOf(false) }
    var attachMenuOpen by remember { mutableStateOf(false) }
    var showCcBcc by remember { mutableStateOf(draft.ccRecipients.isNotBlank() || draft.bccRecipients.isNotBlank()) }

    val sendableAccounts = state.accounts.filter {
        !it.isSharedMailbox || it.hasPermission("SEND_AS") || it.hasPermission("REPLY")
    }
    val draftAttachments = state.attachments.filter { it.messageId == draft.messageId }

    val toToken = draft.toRecipients.substringAfterLast(",").trim()
    val suggestions = remember(toToken, state.contacts) {
        if (toToken.length < 2) emptyList()
        else state.contacts.filter {
            it.fullName.contains(toToken, ignoreCase = true) ||
                it.primaryEmail.contains(toToken, ignoreCase = true)
        }.take(4)
    }

    Dialog(
        onDismissRequest = { viewModel.closeComposer(saveAsDraft = true) },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(12.dp),
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 16.dp)
                .border(1.dp, ext.borderSubtle, RoundedCornerShape(12.dp))
                .testTag("composer_dialog")
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ext.railBackground)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (draft.subject.isBlank()) "New Message" else draft.subject,
                            style = MaterialTheme.typography.titleMedium,
                            color = ext.railOnBackground
                        )
                        Text(
                            text = "Draft autosave enabled · Idempotency key active",
                            style = MaterialTheme.typography.labelMedium,
                            color = ext.railOnBackground.copy(alpha = 0.75f)
                        )
                    }
                    IconButton(onClick = { viewModel.closeComposer(saveAsDraft = true) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Save draft and close", tint = ext.railOnBackground)
                    }
                }

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Sending Identity Selector (supports shared mailboxes with explicit identity display)
                    Box {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { identityMenuOpen = true }
                                .testTag("composer_identity_selector")
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("From (Sending Identity)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    Text(draft.sendingIdentityEmail, style = MaterialTheme.typography.titleSmall)
                                }
                                Text("Switch Identity", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        DropdownMenu(expanded = identityMenuOpen, onDismissRequest = { identityMenuOpen = false }) {
                            sendableAccounts.forEach { acc ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(acc.displayName, fontWeight = FontWeight.SemiBold)
                                            Text(
                                                if (acc.isSharedMailbox) "${acc.email} (Shared · ${acc.sharedPermissions})" else acc.email,
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.switchComposerIdentity(acc)
                                        identityMenuOpen = false
                                    }
                                )
                            }
                        }
                    }

                    // To + Autocomplete
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = draft.toRecipients,
                            onValueChange = { valStr -> viewModel.updateComposer { it.copy(toRecipients = valStr) } },
                            label = { Text("To") },
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("composer_to_input")
                        )
                        TextButton(onClick = { showCcBcc = !showCcBcc }) {
                            Text(if (showCcBcc) "Hide Cc/Bcc" else "Cc / Bcc")
                        }
                    }

                    if (suggestions.isNotEmpty()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("Contact Suggestions (Saved vs Unverified)", style = MaterialTheme.typography.labelMedium)
                                suggestions.forEach { contact ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                val prefix = draft.toRecipients.substringBeforeLast(",", "").trim()
                                                val updated = if (prefix.isEmpty() || !draft.toRecipients.contains(",")) {
                                                    contact.primaryEmail
                                                } else {
                                                    "$prefix, ${contact.primaryEmail}"
                                                }
                                                viewModel.updateComposer { it.copy(toRecipients = updated) }
                                            }
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(contact.fullName, style = MaterialTheme.typography.labelLarge)
                                            Text(contact.primaryEmail, style = MaterialTheme.typography.bodySmall)
                                        }
                                        StatusChip(
                                            text = if (contact.isTrustedSavedContact) "Trusted Contact" else "Autocomplete Only",
                                            containerColor = if (contact.isTrustedSavedContact) ext.successSoft else ext.warningSoft,
                                            contentColor = if (contact.isTrustedSavedContact) ext.success else ext.warning
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (showCcBcc) {
                        OutlinedTextField(
                            value = draft.ccRecipients,
                            onValueChange = { valStr -> viewModel.updateComposer { it.copy(ccRecipients = valStr) } },
                            label = { Text("Cc") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = draft.bccRecipients,
                            onValueChange = { valStr -> viewModel.updateComposer { it.copy(bccRecipients = valStr) } },
                            label = { Text("Bcc") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    OutlinedTextField(
                        value = draft.subject,
                        onValueChange = { valStr -> viewModel.updateComposer { it.copy(subject = valStr) } },
                        label = { Text("Subject") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("composer_subject_input")
                    )

                    // Rich/Plain + Templates + Attachments
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = draft.isRichText,
                            onClick = { viewModel.updateComposer { it.copy(isRichText = !it.isRichText) } },
                            label = { Text(if (draft.isRichText) "Rich Text" else "Plain Text") }
                        )
                        Box {
                            OutlinedButton(onClick = { templateMenuOpen = true }) {
                                Text("Templates")
                            }
                            DropdownMenu(expanded = templateMenuOpen, onDismissRequest = { templateMenuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("Executive Status Update") },
                                    onClick = {
                                        viewModel.updateComposer {
                                            it.copy(
                                                subject = "Weekly Executive Readiness Update",
                                                body = "Hi team,\n\nKey highlights:\n• Milestone status: On track\n• Risks & mitigations: None blocking\n• Next checkpoint: Thursday 14:00 GMT\n\nBest regards,\nElena"
                                            )
                                        }
                                        templateMenuOpen = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Cross-Timezone Meeting Proposal") },
                                    onClick = {
                                        viewModel.updateComposer {
                                            it.copy(
                                                subject = "Proposed Sync (New York / London)",
                                                body = "Hi,\n\nCould we meet on Thursday at 09:30 America/New_York (14:30 Europe/London) for 30 minutes?\n\nBest,\nElena"
                                            )
                                        }
                                        templateMenuOpen = false
                                    }
                                )
                            }
                        }
                        Box {
                            OutlinedButton(onClick = { attachMenuOpen = true }) {
                                Icon(Icons.Filled.AttachFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Attach")
                            }
                            DropdownMenu(expanded = attachMenuOpen, onDismissRequest = { attachMenuOpen = false }) {
                                DropdownMenuItem(
                                    text = { Text("Attach Vendor_Schedule_Q4.pdf (420 KB)") },
                                    onClick = {
                                        viewModel.attachSampleToDraft("Vendor_Schedule_Q4.pdf", "application/pdf", 430_080L)
                                        attachMenuOpen = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Attach Inline Chart_Preview.png (180 KB)") },
                                    onClick = {
                                        viewModel.attachSampleToDraft("Chart_Preview.png", "image/png", 184_320L)
                                        attachMenuOpen = false
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Test Blocked Malware Policy (.exe)") },
                                    onClick = {
                                        viewModel.attachSampleToDraft("invoice_viewer.exe", "application/octet-stream", 102_400L)
                                        attachMenuOpen = false
                                    }
                                )
                            }
                        }
                    }

                    if (draftAttachments.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                            draftAttachments.forEach { att ->
                                StatusChip(
                                    text = "${att.fileName} (${att.scanStatus})",
                                    containerColor = ext.successSoft,
                                    contentColor = ext.success
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = draft.body,
                        onValueChange = { valStr -> viewModel.updateComposer { it.copy(body = valStr) } },
                        label = { Text("Message body") },
                        minLines = 7,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("composer_body_input")
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = draft.simulateUncertainOutcome,
                            onCheckedChange = { checked -> viewModel.updateComposer { it.copy(simulateUncertainOutcome = checked) } }
                        )
                        Text(
                            "Simulate uncertain SMTP acknowledgment (tests duplicate-send protection)",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                HorizontalDivider(color = ext.borderSubtle)
                // Footer Actions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box {
                        OutlinedButton(onClick = { scheduleMenuOpen = true }, modifier = Modifier.testTag("schedule_send_button")) {
                            Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                draft.scheduledOffsetMinutes?.let { "Scheduled +${it}m" }
                                    ?: "Delay: ${state.settings.delayedSendSeconds}s"
                            )
                        }
                        DropdownMenu(expanded = scheduleMenuOpen, onDismissRequest = { scheduleMenuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Send immediately after ${state.settings.delayedSendSeconds}s undo window") },
                                onClick = { viewModel.updateComposer { it.copy(scheduledOffsetMinutes = null) }; scheduleMenuOpen = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Schedule +15 minutes") },
                                onClick = { viewModel.updateComposer { it.copy(scheduledOffsetMinutes = 15) }; scheduleMenuOpen = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Schedule +60 minutes") },
                                onClick = { viewModel.updateComposer { it.copy(scheduledOffsetMinutes = 60) }; scheduleMenuOpen = false }
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { viewModel.closeComposer(saveAsDraft = true) }) {
                            Text("Save Draft")
                        }
                        Button(
                            onClick = viewModel::sendComposerMessage,
                            modifier = Modifier.testTag("composer_send_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (draft.scheduledOffsetMinutes != null) "Schedule Send" else "Send")
                        }
                    }
                }
            }
        }
    }
}
