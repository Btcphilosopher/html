package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.VideoCall
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.RsvpStatus
import com.example.domain.CalendarMath
import com.example.domain.ExpandedEventOccurrence
import com.example.ui.AureomUiState
import com.example.ui.AureomViewModel
import com.example.ui.CalendarViewMode
import com.example.ui.theme.LocalAureomColors

@Composable
fun CalendarWorkspace(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    val ext = LocalAureomColors.current
    var showCreateEvent by remember { mutableStateOf(false) }
    var showImportIcs by remember { mutableStateOf(false) }
    var editingOccurrence by remember { mutableStateOf<ExpandedEventOccurrence?>(null) }
    var tzMenuOpen by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val rangeDays = when (state.calendarViewMode) {
        CalendarViewMode.DAY -> 1L
        CalendarViewMode.WORK_WEEK -> 5L
        CalendarViewMode.WEEK -> 7L
        CalendarViewMode.MONTH -> 30L
        CalendarViewMode.AGENDA -> 14L
    }
    val occurrences = remember(state.events, state.calendarViewMode, now) {
        CalendarMath.expandOccurrences(
            events = state.events,
            rangeStartMs = now - 86_400_000L,
            rangeEndMs = now + rangeDays * 86_400_000L
        )
    }

    val isDst = remember(state.selectedTimezoneId, now) {
        CalendarMath.isDaylightSavingTime(now, state.selectedTimezoneId)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ext.workspaceBackground)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Calendar & Meetings", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Active Zone: ${state.selectedTimezoneId} (${if (isDst) "DST Active" else "Standard Time"})",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box {
                    OutlinedButton(onClick = { tzMenuOpen = true }, modifier = Modifier.testTag("timezone_selector")) {
                        Icon(Icons.Filled.Public, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(state.selectedTimezoneId.substringAfterLast('/'))
                    }
                    DropdownMenu(expanded = tzMenuOpen, onDismissRequest = { tzMenuOpen = false }) {
                        listOf("America/New_York", "Europe/London", "America/Los_Angeles", "Europe/Oslo", "UTC").forEach { tz ->
                            DropdownMenuItem(
                                text = { Text(tz) },
                                onClick = {
                                    viewModel.setSelectedTimezone(tz)
                                    tzMenuOpen = false
                                }
                            )
                        }
                    }
                }
                OutlinedButton(onClick = viewModel::exportCalendarIcs) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(".ICS Export")
                }
                OutlinedButton(onClick = { showImportIcs = true }) {
                    Icon(Icons.Filled.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Import")
                }
                Button(onClick = { showCreateEvent = true }, modifier = Modifier.testTag("new_event_button")) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New Event")
                }
            }
        }

        // View Switcher (Day, Work-Week, Week, Month, Agenda)
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CalendarViewMode.entries.forEach { mode ->
                FilterChip(
                    selected = state.calendarViewMode == mode,
                    onClick = { viewModel.setCalendarViewMode(mode) },
                    label = { Text(mode.name.replace('_', ' ')) }
                )
            }
        }

        // Multi-Calendar legend
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            state.calendars.forEach { cal ->
                StatusChip(
                    text = "${cal.name} (${cal.timezoneId.substringAfterLast('/')})",
                    containerColor = Color(cal.colorHex).copy(alpha = 0.16f),
                    contentColor = Color(cal.colorHex)
                )
            }
        }

        // Events List / Schedule Grid
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(occurrences, key = { it.occurrenceId }) { occ ->
                val evt = occ.sourceEvent
                val cal = state.calendars.firstOrNull { it.id == evt.calendarId }
                val accent = Color(cal?.colorHex ?: 0xFF0F6CBD)
                Surface(
                    color = ext.surfaceElevated,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ext.borderSubtle, RoundedCornerShape(10.dp))
                ) {
                    Row(modifier = Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier
                                .width(5.dp)
                                .height(68.dp)
                                .background(accent, RoundedCornerShape(3.dp))
                        )
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(evt.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                StatusChip(evt.invitationSendState, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary)
                                if (evt.recurrenceRule != "NONE") {
                                    StatusChip("Series: ${evt.recurrenceRule}", ext.copilotSoft, ext.copilotAccent)
                                }
                            }
                            Text(
                                text = "${CalendarMath.formatInZone(occ.startEpochMs, state.selectedTimezoneId)} · Original TZ: ${evt.timezoneId}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (evt.location.isNotBlank()) {
                                Text("Location: ${evt.location}", style = MaterialTheme.typography.bodySmall)
                            }
                            if (evt.attendeesCsv.isNotBlank()) {
                                Text("Attendees: ${evt.attendeesCsv}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (!evt.conferencingJoinUrl.isNullOrBlank()) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Filled.VideoCall, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    Text(
                                        "${evt.conferencingProvider}: ${evt.conferencingJoinUrl}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            HorizontalDivider(color = ext.borderSubtle, modifier = Modifier.padding(vertical = 4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("RSVP (${evt.rsvpStatus}):", style = MaterialTheme.typography.labelMedium)
                                    listOf(RsvpStatus.ACCEPTED, RsvpStatus.TENTATIVE, RsvpStatus.DECLINED).forEach { status ->
                                        Text(
                                            text = status.name.lowercase().replaceFirstChar { it.uppercase() },
                                            style = MaterialTheme.typography.labelMedium,
                                            color = if (evt.rsvpStatus == status.name) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = if (evt.rsvpStatus == status.name) FontWeight.Bold else FontWeight.Normal,
                                            modifier = Modifier
                                                .clickable { viewModel.rsvpEvent(evt.id, status) }
                                                .padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (evt.recurrenceRule != "NONE") {
                                    TextButton(onClick = { editingOccurrence = occ }) {
                                        Icon(Icons.Filled.EditCalendar, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Edit Single Occurrence")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateEvent) {
        CreateEventDialog(
            defaultTimezone = state.selectedTimezoneId,
            onDismiss = { showCreateEvent = false },
            onCreate = { title, desc, loc, tz, recurrence, attendees, sendInvite ->
                val start = System.currentTimeMillis() + 7_200_000L
                viewModel.createCalendarEvent(
                    title = title,
                    description = desc,
                    location = loc,
                    startEpochMs = start,
                    endEpochMs = start + 3_600_000L,
                    timezoneId = tz,
                    recurrenceRule = recurrence,
                    attendeesCsv = attendees,
                    sendInvite = sendInvite
                )
                showCreateEvent = false
            }
        )
    }

    editingOccurrence?.let { occ ->
        EditSingleOccurrenceDialog(
            occurrence = occ,
            onDismiss = { editingOccurrence = null },
            onSaveException = { newTitle, shiftHours, newLoc ->
                viewModel.editSingleOccurrenceOnly(
                    masterEventId = occ.sourceEvent.id,
                    occurrenceStartMs = occ.startEpochMs,
                    newTitle = newTitle,
                    shiftHours = shiftHours,
                    newLocation = newLoc
                )
                editingOccurrence = null
            }
        )
    }

    if (showImportIcs) {
        var icsText by remember {
            mutableStateOf(
                "BEGIN:VCALENDAR\nBEGIN:VEVENT\nSUMMARY:Imported Oslo Partner Sync\nLOCATION:Aureom Meet\nDTSTART:20261115T140000Z\nDTEND:20261115T150000Z\nX-AUREOM-TZ:Europe/Oslo\nEND:VEVENT\nEND:VCALENDAR"
            )
        }
        AlertDialog(
            onDismissRequest = { showImportIcs = false },
            title = { Text("Import RFC-5545 .ICS Calendar") },
            text = {
                OutlinedTextField(
                    value = icsText,
                    onValueChange = { icsText = it },
                    minLines = 6,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.importCalendarIcs(icsText)
                    showImportIcs = false
                }) { Text("Import Events") }
            },
            dismissButton = {
                TextButton(onClick = { showImportIcs = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun CreateEventDialog(
    defaultTimezone: String,
    onDismiss: () -> Unit,
    onCreate: (String, String, String, String, String, String, Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("Aureom Meet") }
    var timezone by remember { mutableStateOf(defaultTimezone) }
    var recurrence by remember { mutableStateOf("NONE") }
    var attendees by remember { mutableStateOf("claire.dubois@aureom-corp.example") }
    var sendInvite by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Meeting / Appointment") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Location") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = timezone, onValueChange = { timezone = it }, label = { Text("Timezone (IANA)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = attendees, onValueChange = { attendees = it }, label = { Text("Attendees (CSV)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("NONE", "DAILY", "WEEKLY").forEach { r ->
                        FilterChip(selected = recurrence == r, onClick = { recurrence = r }, label = { Text(r) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = sendInvite, onCheckedChange = { sendInvite = it })
                    Text("Send meeting invitation to attendees (unchecked = local appointment only)", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = { onCreate(title, description, location, timezone, recurrence, attendees, sendInvite) }) {
                Text(if (sendInvite) "Save & Send Invite" else "Save Local Appointment")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun EditSingleOccurrenceDialog(
    occurrence: ExpandedEventOccurrence,
    onDismiss: () -> Unit,
    onSaveException: (String, Long, String) -> Unit
) {
    var title by remember { mutableStateOf("${occurrence.sourceEvent.title} (Moved)") }
    var location by remember { mutableStateOf(occurrence.sourceEvent.location) }
    var shiftHours by remember { mutableStateOf("2") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Single Occurrence Only") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("This creates an exception for this occurrence without modifying the rest of the recurring series.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Occurrence title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = shiftHours, onValueChange = { shiftHours = it }, label = { Text("Shift start by hours") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Location") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = { onSaveException(title, shiftHours.toLongOrNull() ?: 1L, location) }) {
                Text("Save Exception")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
