package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

enum class ThemeMode { LIGHT, DARK, SYSTEM }
enum class DensityMode { COMFORTABLE, COMPACT }
enum class ReadingPanePosition { RIGHT, BELOW, HIDDEN }

data class AureomExtendedColors(
    val railBackground: Color,
    val railSelected: Color,
    val railOnBackground: Color,
    val borderSubtle: Color,
    val workspaceBackground: Color,
    val surfaceElevated: Color,
    val success: Color,
    val successSoft: Color,
    val warning: Color,
    val warningSoft: Color,
    val danger: Color,
    val dangerSoft: Color,
    val copilotAccent: Color,
    val copilotSoft: Color
)

val LocalAureomColors = staticCompositionLocalOf {
    AureomExtendedColors(
        railBackground = AureomNavy,
        railSelected = AureomNavySurface,
        railOnBackground = Color.White,
        borderSubtle = WorkspaceLightBorder,
        workspaceBackground = WorkspaceLightBg,
        surfaceElevated = WorkspaceLightSurface,
        success = AureomEmerald,
        successSoft = AureomEmeraldSoft,
        warning = AureomAmber,
        warningSoft = AureomAmberSoft,
        danger = AureomCrimson,
        dangerSoft = AureomCrimsonSoft,
        copilotAccent = AureomViolet,
        copilotSoft = AureomVioletSoft
    )
}

private val LightColorScheme = lightColorScheme(
    primary = AureomAzure,
    onPrimary = Color.White,
    primaryContainer = AureomAzureSoft,
    onPrimaryContainer = AureomNavy,
    secondary = AureomNavy,
    onSecondary = Color.White,
    secondaryContainer = WorkspaceLightSurfaceAlt,
    onSecondaryContainer = InkPrimaryLight,
    tertiary = AureomViolet,
    onTertiary = Color.White,
    background = WorkspaceLightBg,
    onBackground = InkPrimaryLight,
    surface = WorkspaceLightSurface,
    onSurface = InkPrimaryLight,
    surfaceVariant = WorkspaceLightSurfaceAlt,
    onSurfaceVariant = InkSecondaryLight,
    outline = WorkspaceLightBorder,
    outlineVariant = WorkspaceLightBorder,
    error = AureomCrimson,
    onError = Color.White,
    errorContainer = AureomCrimsonSoft,
    onErrorContainer = AureomCrimson
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF4DA3FF),
    onPrimary = Color(0xFF06203D),
    primaryContainer = AureomAzureDarkSoft,
    onPrimaryContainer = Color(0xFFD6EBFF),
    secondary = AureomAzureBright,
    onSecondary = Color.White,
    secondaryContainer = WorkspaceDarkSurfaceAlt,
    onSecondaryContainer = InkPrimaryDark,
    tertiary = Color(0xFFB794F4),
    onTertiary = Color(0xFF230F42),
    background = WorkspaceDarkBg,
    onBackground = InkPrimaryDark,
    surface = WorkspaceDarkSurface,
    onSurface = InkPrimaryDark,
    surfaceVariant = WorkspaceDarkSurfaceAlt,
    onSurfaceVariant = InkSecondaryDark,
    outline = WorkspaceDarkBorder,
    outlineVariant = WorkspaceDarkBorder,
    error = Color(0xFFF48791),
    onError = Color(0xFF4A060E),
    errorContainer = Color(0xFF48171E),
    onErrorContainer = Color(0xFFFFDADE)
)

private val AureomShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(12.dp),
    extraLarge = RoundedCornerShape(16.dp)
)

@Composable
fun AureomMailTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) DarkColorScheme else LightColorScheme
    val extendedColors = if (isDark) {
        AureomExtendedColors(
            railBackground = AureomNavyDark,
            railSelected = AureomNavySurface,
            railOnBackground = Color(0xFFEAF2FF),
            borderSubtle = WorkspaceDarkBorder,
            workspaceBackground = WorkspaceDarkBg,
            surfaceElevated = WorkspaceDarkSurface,
            success = Color(0xFF54B054),
            successSoft = Color(0xFF123018),
            warning = Color(0xFFF5A623),
            warningSoft = Color(0xFF33230A),
            danger = Color(0xFFF48791),
            dangerSoft = Color(0xFF3E151B),
            copilotAccent = Color(0xFFB794F4),
            copilotSoft = Color(0xFF2A1D3D)
        )
    } else {
        AureomExtendedColors(
            railBackground = AureomNavy,
            railSelected = AureomNavySurface,
            railOnBackground = Color.White,
            borderSubtle = WorkspaceLightBorder,
            workspaceBackground = WorkspaceLightBg,
            surfaceElevated = WorkspaceLightSurface,
            success = AureomEmerald,
            successSoft = AureomEmeraldSoft,
            warning = AureomAmber,
            warningSoft = AureomAmberSoft,
            danger = AureomCrimson,
            dangerSoft = AureomCrimsonSoft,
            copilotAccent = AureomViolet,
            copilotSoft = AureomVioletSoft
        )
    }

    CompositionLocalProvider(LocalAureomColors provides extendedColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AureomTypography,
            shapes = AureomShapes,
            content = content
        )
    }
}
