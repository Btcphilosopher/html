package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.ContactEntity
import com.example.data.local.TaskPriority
import com.example.domain.CalendarMath
import com.example.ui.AppRailSection
import com.example.ui.AureomUiState
import com.example.ui.AureomViewModel
import com.example.ui.theme.LocalAureomColors

@Composable
fun PeopleWorkspace(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    val ext = LocalAureomColors.current
    var showAddContact by remember { mutableStateOf(false) }
    var filterMode by remember { mutableStateOf("ALL") }

    val duplicatePairs = remember(state.contacts) {
        state.contacts
            .filter { it.isTrustedSavedContact }
            .groupBy { it.primaryEmail.lowercase() }
            .values
            .filter { it.size > 1 }
    }

    val filtered = state.contacts.filter { c ->
        when (filterMode) {
            "FAVORITES" -> c.isFavorite
            "TRUSTED" -> c.isTrustedSavedContact
            "SUGGESTIONS" -> !c.isTrustedSavedContact
            else -> true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ext.workspaceBackground)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("People & Organisations", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Saved contacts are strictly separated from unverified autocomplete senders.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(onClick = { showAddContact = true }, modifier = Modifier.testTag("add_contact_button")) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Contact")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf("ALL" to "All (${state.contacts.size})", "FAVORITES" to "Favorites", "TRUSTED" to "Trusted Saved", "SUGGESTIONS" to "Autocomplete Only").forEach { (key, label) ->
                FilterChip(selected = filterMode == key, onClick = { filterMode = key }, label = { Text(label) })
            }
        }

        // Duplicate Merge Review Banner
        duplicatePairs.forEach { group ->
            val primary = group.first()
            val dup = group.last()
            Surface(
                color = ext.warningSoft,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ext.warning.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Duplicate Contact Detected: ${primary.primaryEmail}", style = MaterialTheme.typography.titleSmall, color = ext.warning)
                        Text(
                            "Merge '${dup.fullName}' into '${primary.fullName}' while preserving secondary emails & notes.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Button(
                        onClick = { viewModel.mergeDuplicateContacts(primary.id, dup.id) },
                        modifier = Modifier.testTag("merge_duplicate_button")
                    ) {
                        Icon(Icons.Filled.MergeType, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Review & Merge")
                    }
                }
            }
        }

        LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(filtered, key = { it.id }) { contact ->
                val interactionCount = state.allMessages.count {
                    it.senderEmail.equals(contact.primaryEmail, ignoreCase = true) ||
                        it.toRecipients.contains(contact.primaryEmail, ignoreCase = true)
                }
                ContactCard(
                    contact = contact,
                    interactionCount = interactionCount,
                    onToggleFav = { viewModel.toggleContactFavorite(contact.id) },
                    onPromote = { viewModel.promoteContact(contact.id) },
                    onComposeTo = {
                        viewModel.openNewComposer()
                        viewModel.updateComposer { it.copy(toRecipients = contact.primaryEmail) }
                    }
                )
            }
        }
    }

    if (showAddContact) {
        AddContactDialog(
            onDismiss = { showAddContact = false },
            onAdd = { name, email, org, title, phone ->
                viewModel.addContact(name, email, org, title, phone)
                showAddContact = false
            }
        )
    }
}

@Composable
private fun ContactCard(
    contact: ContactEntity,
    interactionCount: Int,
    onToggleFav: () -> Unit,
    onPromote: () -> Unit,
    onComposeTo: () -> Unit
) {
    val ext = LocalAureomColors.current
    Surface(
        color = ext.surfaceElevated,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ext.borderSubtle, RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AvatarCircle(contact.fullName, if (contact.isTrustedSavedContact) 0xFF0F6CBD else 0xFFC86A00)
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(contact.fullName, style = MaterialTheme.typography.titleMedium)
                        StatusChip(
                            text = if (contact.isTrustedSavedContact) "Trusted Contact" else "Autocomplete Suggestion",
                            containerColor = if (contact.isTrustedSavedContact) ext.successSoft else ext.warningSoft,
                            contentColor = if (contact.isTrustedSavedContact) ext.success else ext.warning
                        )
                    }
                    Text(
                        "${contact.jobTitle.ifBlank { "Member" }} · ${contact.organization.ifBlank { "Independent" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onToggleFav) {
                    Icon(
                        if (contact.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Favorite contact",
                        tint = if (contact.isFavorite) ext.warning else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Text("Primary: ${contact.primaryEmail}", style = MaterialTheme.typography.bodySmall)
            if (contact.secondaryEmailsCsv.isNotBlank()) {
                Text("Secondary: ${contact.secondaryEmailsCsv}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (contact.phoneNumbersCsv.isNotBlank()) {
                Text("Phone: ${contact.phoneNumbersCsv}", style = MaterialTheme.typography.bodySmall)
            }
            if (contact.notes.isNotBlank()) {
                Text("Notes: ${contact.notes}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Permitted interactions: $interactionCount message(s)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!contact.isTrustedSavedContact) {
                        OutlinedButton(onClick = onPromote) { Text("Trust & Save") }
                    }
                    Button(onClick = onComposeTo) { Text("Email") }
                }
            }
        }
    }
}

@Composable
private fun AddContactDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var org by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Trusted Contact") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email address") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = org, onValueChange = { org = it }, label = { Text("Organisation") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Job title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone number") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = { Button(onClick = { onAdd(name, email, org, title, phone) }) { Text("Save Contact") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun TasksWorkspace(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    val ext = LocalAureomColors.current
    var showNewTask by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("MY_DAY") }

    val activeTasks = state.tasks.filter { !it.isCompleted }
    val completedTasks = state.tasks.filter { it.isCompleted }
    val flaggedMessages = state.allMessages.filter { it.isFlagged }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ext.workspaceBackground)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Tasks & My Day", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Combines tasks, flagged follow-up mail, and upcoming meetings without moving your emails.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(onClick = { showNewTask = true }, modifier = Modifier.testTag("new_task_button")) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Task")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tab == "MY_DAY", onClick = { tab = "MY_DAY" }, label = { Text("My Day") })
            FilterChip(selected = tab == "ALL", onClick = { tab = "ALL" }, label = { Text("All Open (${activeTasks.size})") })
            FilterChip(selected = tab == "HISTORY", onClick = { tab = "HISTORY" }, label = { Text("Completion History (${completedTasks.size})") })
        }

        LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            val listToShow = when (tab) {
                "MY_DAY" -> activeTasks.filter { it.isInMyDay }
                "HISTORY" -> completedTasks
                else -> activeTasks
            }

            items(listToShow, key = { it.id }) { task ->
                Surface(
                    color = ext.surfaceElevated,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ext.borderSubtle, RoundedCornerShape(10.dp))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.toggleTaskComplete(task.id) }) {
                                Icon(
                                    if (task.isCompleted) Icons.Filled.CheckCircle else Icons.Outlined.TaskAlt,
                                    contentDescription = "Complete task",
                                    tint = if (task.isCompleted) ext.success else MaterialTheme.colorScheme.primary
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(task.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 2.dp)) {
                                    StatusChip(task.listName, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                                    StatusChip(
                                        task.priority,
                                        if (task.priority == TaskPriority.HIGH.name) ext.dangerSoft else MaterialTheme.colorScheme.primaryContainer,
                                        if (task.priority == TaskPriority.HIGH.name) ext.danger else MaterialTheme.colorScheme.primary
                                    )
                                    if (task.recurrenceRule != "NONE") {
                                        StatusChip("Repeats ${task.recurrenceRule}", ext.copilotSoft, ext.copilotAccent)
                                    }
                                    if (task.linkedMessageId != null) {
                                        StatusChip("Email Linked", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary)
                                    }
                                    if (task.linkedEventId != null) {
                                        StatusChip("Meeting Linked", ext.successSoft, ext.success)
                                    }
                                }
                            }
                            IconButton(onClick = { viewModel.toggleTaskMyDay(task.id) }) {
                                Icon(
                                    Icons.Filled.WbSunny,
                                    contentDescription = "Toggle My Day",
                                    tint = if (task.isInMyDay) ext.warning else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (task.notes.isNotBlank()) {
                            Text(task.notes, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        if (task.checklistSerialized.isNotBlank()) {
                            HorizontalDivider(color = ext.borderSubtle)
                            task.checklistSerialized.lines().forEachIndexed { idx, line ->
                                val checked = line.startsWith("[x] ")
                                val label = line.removePrefix("[x] ").removePrefix("[ ] ")
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.toggleTaskChecklistItem(task.id, idx) }
                                        .padding(vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        if (checked) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                                        contentDescription = "Checklist item",
                                        tint = if (checked) ext.success else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(label, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            task.dueEpochMs?.let {
                                Text(
                                    "Due: ${CalendarMath.formatInZone(it, state.selectedTimezoneId)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            task.linkedMessageId?.let { msgId ->
                                TextButton(onClick = {
                                    val msg = state.allMessages.firstOrNull { it.id == msgId }
                                    if (msg != null) {
                                        viewModel.selectMessage(msg)
                                        viewModel.selectSection(AppRailSection.MAIL)
                                    }
                                }) {
                                    Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Open Source Email")
                                }
                            }
                        }
                    }
                }
            }

            if (tab == "MY_DAY" && flaggedMessages.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Flagged Follow-Up Emails", style = MaterialTheme.typography.titleMedium)
                }
                items(flaggedMessages, key = { "flg_${it.id}" }) { msg ->
                    Surface(
                        color = ext.warningSoft,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectMessage(msg)
                                viewModel.selectSection(AppRailSection.MAIL)
                            }
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Email, contentDescription = null, tint = ext.warning, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(msg.subject, style = MaterialTheme.typography.labelLarge)
                                Text(msg.senderName, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { viewModel.createTaskFromMessage(msg) }) { Text("+ Convert to Task") }
                        }
                    }
                }
            }

            if (tab == "MY_DAY" && state.events.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Upcoming Meetings", style = MaterialTheme.typography.titleMedium)
                }
                items(state.events.take(3), key = { "myday_evt_${it.id}" }) { evt ->
                    Surface(
                        color = ext.surfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ext.borderSubtle, RoundedCornerShape(8.dp))
                            .clickable { viewModel.selectSection(AppRailSection.CALENDAR) }
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Event, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(evt.title, style = MaterialTheme.typography.labelLarge)
                                Text(CalendarMath.formatInZone(evt.startEpochMs, state.selectedTimezoneId), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewTask) {
        NewTaskDialog(
            onDismiss = { showNewTask = false },
            onCreate = { title, listName, priority, recurrence ->
                viewModel.addTask(title, listName, priority, 24L, recurrence)
                showNewTask = false
            }
        )
    }
}

@Composable
private fun NewTaskDialog(
    onDismiss: () -> Unit,
    onCreate: (String, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var listName by remember { mutableStateOf("Executive") }
    var priority by remember { mutableStateOf("HIGH") }
    var recurrence by remember { mutableStateOf("NONE") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Task") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = listName, onValueChange = { listName = it }, label = { Text("List name") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("HIGH", "NORMAL", "LOW").forEach { p ->
                        FilterChip(selected = priority == p, onClick = { priority = p }, label = { Text(p) })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("NONE", "DAILY", "WEEKLY").forEach { r ->
                        FilterChip(selected = recurrence == r, onClick = { recurrence = r }, label = { Text(r) })
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onCreate(title, listName, priority, recurrence) }) { Text("Create Task") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
