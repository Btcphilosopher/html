package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ai.CopilotTaskType
import com.example.ai.CopilotUiState
import com.example.ai.ProposedCopilotAction
import com.example.domain.CalendarMath
import com.example.ui.AppRailSection
import com.example.ui.AureomUiState
import com.example.ui.AureomViewModel
import com.example.ui.theme.LocalAureomColors

@Composable
fun FilesAndSearchWorkspace(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    val ext = LocalAureomColors.current
    var groupBy by remember { mutableStateOf("DATE") }
    var saveSearchTitle by remember { mutableStateOf("") }

    // Exclude attachments from non-indexed restricted accounts
    val indexedAccountIds = state.accounts.filter { it.isSearchIndexedForUser }.map { it.id }.toSet()
    val accessibleAttachments = state.attachments.filter { att ->
        att.accountId in indexedAccountIds &&
            (state.searchQuery.isBlank() || att.fileName.contains(state.searchQuery, ignoreCase = true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ext.workspaceBackground)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Files & Permission-Aware Search", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Restricted shared mailboxes (e.g. Board Audit) are excluded from personal search indexing.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Saved Searches bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Saved:", style = MaterialTheme.typography.labelLarge)
            state.savedSearches.forEach { saved ->
                FilterChip(
                    selected = state.searchQuery.equals(saved.query, ignoreCase = true),
                    onClick = { viewModel.runSavedSearch(saved) },
                    leadingIcon = { Icon(Icons.Filled.Bookmark, contentDescription = null, modifier = Modifier.size(14.dp)) },
                    label = { Text(saved.name) }
                )
            }
            if (state.searchQuery.isNotBlank()) {
                OutlinedTextField(
                    value = saveSearchTitle,
                    onValueChange = { saveSearchTitle = it },
                    label = { Text("Name this search") },
                    singleLine = true,
                    modifier = Modifier.width(180.dp)
                )
                OutlinedButton(onClick = {
                    viewModel.saveCurrentSearch(saveSearchTitle.ifBlank { state.searchQuery })
                    saveSearchTitle = ""
                }) { Text("Save") }
            }
        }

        // Grouping selector
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("DATE" to "Group by Date", "TYPE" to "Group by Type", "SENDER" to "Group by Sender").forEach { (key, label) ->
                FilterChip(selected = groupBy == key, onClick = { groupBy = key }, label = { Text(label) })
            }
        }

        LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (state.isSearchActive) {
                item {
                    Text(
                        "Authorized Message Matches (${state.searchResults.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                items(state.searchResults, key = { "srch_${it.id}" }) { msg ->
                    Surface(
                        color = ext.surfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ext.borderSubtle, RoundedCornerShape(8.dp))
                            .clickable {
                                viewModel.selectMessage(msg)
                                viewModel.selectSection(AppRailSection.MAIL)
                            }
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(msg.subject, style = MaterialTheme.typography.titleSmall)
                            Text("${msg.senderName} <${msg.senderEmail}>", style = MaterialTheme.typography.bodySmall)
                            Text(msg.snippet, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            item {
                Text(
                    "Accessible Attachments (${accessibleAttachments.size}) · Grouped by $groupBy",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            val sortedAttachments = when (groupBy) {
                "TYPE" -> accessibleAttachments.sortedBy { it.fileName.substringAfterLast('.', "") }
                "SENDER" -> accessibleAttachments.sortedBy { att ->
                    state.allMessages.firstOrNull { it.id == att.messageId }?.senderName.orEmpty()
                }
                else -> accessibleAttachments.sortedByDescending { it.createdEpochMs }
            }

            items(sortedAttachments, key = { it.id }) { att ->
                val sourceMsg = state.allMessages.firstOrNull { it.id == att.messageId }
                Surface(
                    color = ext.surfaceElevated,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ext.borderSubtle, RoundedCornerShape(10.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Filled.Description, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(att.fileName, style = MaterialTheme.typography.titleSmall)
                            Text(
                                "${att.sizeBytes / 1024} KB · ${att.mimeType.substringAfterLast('/')} · Scan: ${att.scanStatus}",
                                style = MaterialTheme.typography.bodySmall,
                                color = ext.success
                            )
                            if (sourceMsg != null) {
                                Text(
                                    "From: ${sourceMsg.senderName} · ${sourceMsg.subject}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        if (sourceMsg != null) {
                            OutlinedButton(onClick = {
                                viewModel.selectMessage(sourceMsg)
                                viewModel.selectSection(AppRailSection.MAIL)
                            }) {
                                Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Source Mail")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CopilotWorkspace(
    state: AureomUiState,
    viewModel: AureomViewModel
) {
    val ext = LocalAureomColors.current
    var customInstruction by remember { mutableStateOf("") }
    var draftToRewrite by remember { mutableStateOf("") }
    var targetLanguage by remember { mutableStateOf("French") }
    val selectedMsg = state.allMessages.firstOrNull { it.id == state.selectedMessageId }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ext.workspaceBackground)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            // Hero Banner with generated image polish
            Surface(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ext.borderSubtle, RoundedCornerShape(12.dp))
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(124.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.aureom_workspace_banner_1794654721515),
                        contentDescription = "Aureom Copilot workspace banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ext.railBackground.copy(alpha = 0.72f))
                            .padding(16.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primaryContainer)
                                    Text("Aureom Copilot", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimary)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        if (state.settings.aiMockMode) "Mock Mode" else "Firebase AI (Gemini)",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Switch(
                                        checked = state.settings.aiMockMode,
                                        onCheckedChange = viewModel::setAiMockMode,
                                        modifier = Modifier.testTag("copilot_mock_switch")
                                    )
                                }
                            }
                            Text(
                                "Read-only by default · Prompt-injection isolated · Explicit approval required before mutating mail, tasks, or calendar",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.86f)
                            )
                        }
                    }
                }
            }
        }

        // Budget & Active Context
        item {
            Surface(
                color = ext.surfaceElevated,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ext.borderSubtle, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "Scope: ${selectedMsg?.subject ?: "Active Inbox Thread"}",
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            "Daily Budget: ${state.settings.aiDailyUsedCount} / ${state.settings.aiDailyBudgetLimit}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (state.settings.aiDailyUsedCount.toFloat() / state.settings.aiDailyBudgetLimit.coerceAtLeast(1)).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.runCopilot(CopilotTaskType.SUMMARIZE_THREAD) },
                            modifier = Modifier.testTag("copilot_btn_summarize")
                        ) { Text("Summarise Thread") }
                        OutlinedButton(
                            onClick = { viewModel.runCopilot(CopilotTaskType.DRAFT_REPLY, userInstruction = customInstruction) },
                            modifier = Modifier.testTag("copilot_btn_draft")
                        ) { Text("Draft Reply") }
                        OutlinedButton(
                            onClick = { viewModel.runCopilot(CopilotTaskType.EXTRACT_TASKS_MEETINGS) },
                            modifier = Modifier.testTag("copilot_btn_extract")
                        ) { Text("Extract Tasks & Meetings") }
                        OutlinedButton(
                            onClick = { viewModel.runCopilot(CopilotTaskType.MEETING_BRIEF) }
                        ) { Text("Cited Meeting Brief") }
                        OutlinedButton(
                            onClick = { viewModel.runCopilot(CopilotTaskType.SUGGEST_FILING) }
                        ) { Text("Suggest Filing") }
                        OutlinedButton(
                            onClick = { viewModel.runCopilot(CopilotTaskType.REWRITE_TONE, draftInput = draftToRewrite) }
                        ) { Text("Rewrite Tone") }
                        OutlinedButton(
                            onClick = { viewModel.runCopilot(CopilotTaskType.TRANSLATE_DRAFT, draftInput = draftToRewrite, targetLanguage = targetLanguage) }
                        ) { Text("Translate ($targetLanguage)") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = customInstruction,
                            onValueChange = { customInstruction = it },
                            label = { Text("Optional guidance / draft text to rewrite or translate") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = targetLanguage,
                            onValueChange = { targetLanguage = it },
                            label = { Text("Lang") },
                            modifier = Modifier.width(100.dp)
                        )
                    }
                    draftToRewrite = customInstruction
                }
            }
        }

        // Copilot Result / Loading / Error
        item {
            when (val ui = state.copilotState) {
                CopilotUiState.Idle -> {
                    Surface(
                        color = ext.surfaceElevated,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ext.borderSubtle, RoundedCornerShape(10.dp))
                    ) {
                        Text(
                            "Select a Copilot capability above. All outputs distinguish verified source citations from inferences and require your explicit approval for any change.",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
                CopilotUiState.Loading -> {
                    Surface(
                        color = ext.surfaceElevated,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                CircularProgressIndicator(modifier = Modifier.size(22.dp))
                                Text("Running Aureom Copilot safely...")
                            }
                            TextButton(onClick = viewModel::cancelCopilot) {
                                Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text("Cancel")
                            }
                        }
                    }
                }
                is CopilotUiState.Error -> {
                    Surface(
                        color = ext.dangerSoft,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Copilot Error", style = MaterialTheme.typography.titleSmall, color = ext.danger)
                            Text(ui.message, style = MaterialTheme.typography.bodySmall, color = ext.danger)
                            TextButton(onClick = { viewModel.setAiMockMode(true) }) {
                                Text("Switch to Local Mock Mode")
                            }
                        }
                    }
                }
                is CopilotUiState.Success -> {
                    val res = ui.result
                    Surface(
                        color = ext.surfaceElevated,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .testTag("copilot_result_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(res.title, style = MaterialTheme.typography.titleMedium)
                                StatusChip(res.modeUsed, ext.copilotSoft, ext.copilotAccent)
                            }

                            res.injectionBlockedNotice?.let { notice ->
                                Surface(color = ext.warningSoft, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Shield, contentDescription = null, tint = ext.warning, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(notice, style = MaterialTheme.typography.bodySmall, color = ext.warning)
                                    }
                                }
                            }

                            Text("CONFIRMED FACTS (WITH SOURCE CITATIONS)", style = MaterialTheme.typography.labelMedium, color = ext.success)
                            res.confirmedFacts.forEach { fact ->
                                Text("• $fact", style = MaterialTheme.typography.bodyMedium)
                            }

                            Text("INFERRED SUGGESTIONS", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            res.inferredSuggestions.forEach { inf ->
                                Text("• $inf", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }

                            res.draftedText?.let { draft ->
                                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                    Text(draft, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(12.dp))
                                }
                            }

                            if (res.sourceMessageIds.isNotEmpty()) {
                                Text(
                                    "Cited Source IDs: ${res.sourceMessageIds.joinToString(", ")}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (res.proposedActions.isNotEmpty()) {
                                HorizontalDivider(color = ext.borderSubtle)
                                Text("APPROVAL GATE (Explicit User Approval Required)", style = MaterialTheme.typography.labelMedium, color = ext.warning)
                                res.proposedActions.forEach { action ->
                                    val label = when (action) {
                                        is ProposedCopilotAction.CreateTask -> "Approve & Create Task: ${action.title}"
                                        is ProposedCopilotAction.ProposeMeeting -> "Approve & Draft Meeting: ${action.title}"
                                        is ProposedCopilotAction.ApplyCategory -> "Approve & File '${action.category}'"
                                        is ProposedCopilotAction.InsertDraftReply -> "Approve & Load Draft in Composer"
                                    }
                                    Button(
                                        onClick = { viewModel.approveCopilotAction(action) },
                                        modifier = Modifier.testTag("copilot_approve_action")
                                    ) {
                                        Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(label)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Action History Log
        item {
            Text("Copilot Action History (${state.aiLogs.size})", style = MaterialTheme.typography.titleMedium)
        }
        items(state.aiLogs, key = { it.id }) { log ->
            Surface(
                color = ext.surfaceElevated,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ext.borderSubtle, RoundedCornerShape(8.dp))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${log.actionType} · ${log.resultPreview}", style = MaterialTheme.typography.labelLarge)
                        Text(
                            "${CalendarMath.formatInZone(log.timestampEpochMs, state.selectedTimezoneId)} · ${log.mode}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    StatusChip(log.status, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                }
            }
        }
    }
}
