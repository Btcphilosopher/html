package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aureom Mail Brand & Fluent-Inspired Productivity Palette
val AureomNavy = Color(0xFF0F2A56)
val AureomNavyDark = Color(0xFF091B3A)
val AureomNavySurface = Color(0xFF163870)
val AureomAzure = Color(0xFF0F6CBD)
val AureomAzureBright = Color(0xFF2B88D8)
val AureomAzureSoft = Color(0xFFE8F3FC)
val AureomAzureDarkSoft = Color(0xFF16324F)

// Workspaces & Neutrals (Light)
val WorkspaceLightBg = Color(0xFFF3F5F8)
val WorkspaceLightSurface = Color(0xFFFFFFFF)
val WorkspaceLightSurfaceAlt = Color(0xFFF8FAFC)
val WorkspaceLightBorder = Color(0xFFDDE3EC)
val InkPrimaryLight = Color(0xFF18202C)
val InkSecondaryLight = Color(0xFF556173)
val InkMutedLight = Color(0xFF7B8798)

// Workspaces & Neutrals (Dark)
val WorkspaceDarkBg = Color(0xFF10141A)
val WorkspaceDarkSurface = Color(0xFF181E27)
val WorkspaceDarkSurfaceAlt = Color(0xFF1F2733)
val WorkspaceDarkBorder = Color(0xFF2C3646)
val InkPrimaryDark = Color(0xFFEBF0F7)
val InkSecondaryDark = Color(0xFFA7B3C5)
val InkMutedDark = Color(0xFF7D8A9E)

// Semantic Status Accents
val AureomEmerald = Color(0xFF107C10)
val AureomEmeraldSoft = Color(0xFFE6F4EA)
val AureomAmber = Color(0xFFC86A00)
val AureomAmberSoft = Color(0xFFFFF4E5)
val AureomCrimson = Color(0xFFC50F1F)
val AureomCrimsonSoft = Color(0xFFFDE7E9)
val AureomViolet = Color(0xFF5C2D91)
val AureomVioletSoft = Color(0xFFF2ECF9)
