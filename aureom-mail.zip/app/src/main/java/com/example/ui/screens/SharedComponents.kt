package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.ViewSidebar
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Mail
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.AccountEntity
import com.example.data.local.SyncHealth
import com.example.domain.CalendarMath
import com.example.ui.AppRailSection
import com.example.ui.AureomUiState
import com.example.ui.PendingDelayedSendBanner
import com.example.ui.theme.LocalAureomColors

@Composable
fun AureomTopHeader(
    state: AureomUiState,
    isCompact: Boolean,
    onSearchChange: (String) -> Unit,
    onSelectAccount: (String) -> Unit,
    onComposeClick: () -> Unit,
    onToggleOffline: () -> Unit,
    onToggleCalendarSidebar: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenDemoGuide: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenDrawerOrFolders: (() -> Unit)? = null
) {
    val ext = LocalAureomColors.current
    var accountMenuOpen by remember { mutableStateOf(false) }

    val selectedAccountLabel = if (state.settings.selectedAccountId == "UNIFIED") {
        "All Accounts"
    } else {
        state.accounts.firstOrNull { it.id == state.settings.selectedAccountId }?.displayName ?: "Account"
    }

    val failedSyncCount = state.accounts.count { it.syncHealth == SyncHealth.FAILED.name }
    val pendingOutboxCount = state.outboxOps.count { it.status != "COMPLETED" }

    Surface(
        color = ext.railBackground,
        contentColor = ext.railOnBackground,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.statusBarsPadding()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (onOpenDrawerOrFolders != null && isCompact) {
                    IconButton(
                        onClick = onOpenDrawerOrFolders,
                        modifier = Modifier.testTag("open_folders_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FolderOpen,
                            contentDescription = "Folders and accounts",
                            tint = Color.White
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "A",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (!isCompact) {
                        Text(
                            text = "AUREOM MAIL",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Unified Search Input
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White.copy(alpha = 0.14f))
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(modifier = Modifier.weight(1f)) {
                        if (state.searchQuery.isEmpty()) {
                            Text(
                                text = "Search mail, attachments, people...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.65f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        BasicTextField(
                            value = state.searchQuery,
                            onValueChange = onSearchChange,
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color.White),
                            cursorBrush = SolidColor(Color.White),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("unified_search_input")
                        )
                    }
                    if (state.searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { onSearchChange("") },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Clear search",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Account Switcher
                if (!isCompact) {
                    Box {
                        Surface(
                            color = Color.White.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier
                                .clickable { accountMenuOpen = true }
                                .testTag("account_switcher_button")
                        ) {
                            Text(
                                text = selectedAccountLabel,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                        AccountDropdownMenu(
                            expanded = accountMenuOpen,
                            accounts = state.accounts,
                            onDismiss = { accountMenuOpen = false },
                            onSelect = {
                                onSelectAccount(it)
                                accountMenuOpen = false
                            }
                        )
                    }
                }

                // Offline / Sync status pill
                Surface(
                    color = when {
                        state.settings.isOfflineMode -> ext.warning
                        failedSyncCount > 0 || pendingOutboxCount > 0 -> ext.danger
                        else -> Color.White.copy(alpha = 0.14f)
                    },
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .clickable { onToggleOffline() }
                        .testTag("offline_toggle_pill")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = when {
                                state.settings.isOfflineMode -> Icons.Filled.CloudOff
                                failedSyncCount > 0 -> Icons.Filled.ErrorOutline
                                else -> Icons.Filled.CloudQueue
                            },
                            contentDescription = "Sync status",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        if (!isCompact) {
                            Text(
                                text = when {
                                    state.settings.isOfflineMode -> "Offline ($pendingOutboxCount queued)"
                                    failedSyncCount > 0 -> "Sync Issue ($failedSyncCount)"
                                    else -> "Synced"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White
                            )
                        }
                    }
                }

                // Demo Walkthrough
                IconButton(
                    onClick = onOpenDemoGuide,
                    modifier = Modifier.testTag("demo_guide_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayCircleOutline,
                        contentDescription = "Interactive Demo Scenarios",
                        tint = Color.White
                    )
                }

                // Notifications
                IconButton(
                    onClick = onOpenNotifications,
                    modifier = Modifier.testTag("notifications_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (state.notifications.isNotEmpty() || failedSyncCount > 0) {
                                Badge {
                                    Text("${state.notifications.size}")
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Notifications,
                            contentDescription = "Notifications",
                            tint = Color.White
                        )
                    }
                }

                if (!isCompact) {
                    IconButton(
                        onClick = onToggleCalendarSidebar,
                        modifier = Modifier.testTag("toggle_my_day_sidebar_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ViewSidebar,
                            contentDescription = "Toggle My Day sidebar",
                            tint = Color.White
                        )
                    }
                }

                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Settings,
                        contentDescription = "Settings and Rules",
                        tint = Color.White
                    )
                }

                if (!isCompact) {
                    Button(
                        onClick = onComposeClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("new_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("New Mail", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
fun AccountDropdownMenu(
    expanded: Boolean,
    accounts: List<AccountEntity>,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Unified Inbox (All Permitted Accounts)", fontWeight = FontWeight.SemiBold) },
            onClick = { onSelect("UNIFIED") }
        )
        HorizontalDivider()
        accounts.forEach { acc ->
            DropdownMenuItem(
                text = {
                    Column {
                        Text(acc.displayName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                        Text(
                            "${acc.email} · ${acc.providerType}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                onClick = { onSelect(acc.id) }
            )
        }
    }
}

@Composable
fun AureomVerticalRail(
    activeSection: AppRailSection,
    unreadCount: Int,
    onSelectSection: (AppRailSection) -> Unit
) {
    val ext = LocalAureomColors.current
    Column(
        modifier = Modifier
            .width(68.dp)
            .fillMaxHeight()
            .background(ext.railBackground)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        val items = listOf(
            Triple(AppRailSection.MAIL, "Mail", Icons.Filled.Mail to Icons.Outlined.Mail),
            Triple(AppRailSection.CALENDAR, "Calendar", Icons.Filled.CalendarMonth to Icons.Outlined.CalendarMonth),
            Triple(AppRailSection.PEOPLE, "People", Icons.Filled.People to Icons.Outlined.People),
            Triple(AppRailSection.TASKS, "Tasks", Icons.Filled.TaskAlt to Icons.Outlined.TaskAlt),
            Triple(AppRailSection.FILES, "Files", Icons.Filled.FolderOpen to Icons.Outlined.FolderOpen),
            Triple(AppRailSection.COPILOT, "Copilot", Icons.Filled.AutoAwesome to Icons.Outlined.AutoAwesome)
        )
        items.forEach { (section, label, icons) ->
            val selected = section == activeSection
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) ext.railSelected else Color.Transparent)
                    .clickable { onSelectSection(section) }
                    .padding(vertical = 10.dp)
                    .testTag("rail_${section.name.lowercase()}"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BadgedBox(
                    badge = {
                        if (section == AppRailSection.MAIL && unreadCount > 0) {
                            Badge { Text("$unreadCount") }
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (selected) icons.first else icons.second,
                        contentDescription = label,
                        tint = if (selected) Color.White else Color.White.copy(alpha = 0.72f),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) Color.White else Color.White.copy(alpha = 0.72f),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
fun AureomBottomBar(
    activeSection: AppRailSection,
    onSelectSection: (AppRailSection) -> Unit
) {
    val ext = LocalAureomColors.current
    val navItems: List<Triple<AppRailSection, String, ImageVector>> = listOf(
        Triple(AppRailSection.MAIL, "Mail", Icons.Filled.Mail),
        Triple(AppRailSection.CALENDAR, "Calendar", Icons.Filled.CalendarMonth),
        Triple(AppRailSection.PEOPLE, "People", Icons.Filled.People),
        Triple(AppRailSection.TASKS, "Tasks", Icons.Filled.TaskAlt),
        Triple(AppRailSection.FILES, "Files", Icons.Filled.FolderOpen),
        Triple(AppRailSection.COPILOT, "Copilot", Icons.Filled.AutoAwesome)
    )
    NavigationBar(
        containerColor = ext.surfaceElevated,
        tonalElevation = 2.dp
    ) {
        navItems.forEach { (section, label, icon) ->
            val selected = activeSection == section
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectSection(section) },
                icon = { Icon(imageVector = icon, contentDescription = label, modifier = Modifier.size(20.dp)) },
                label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = MaterialTheme.colorScheme.primary,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.testTag("bottom_nav_${section.name.lowercase()}")
            )
        }
    }
}

@Composable
fun DelayedSendCountdownBar(
    banner: PendingDelayedSendBanner,
    onCancelSend: () -> Unit
) {
    val ext = LocalAureomColors.current
    Surface(
        color = ext.railBackground,
        contentColor = Color.White,
        shape = RoundedCornerShape(8.dp),
        tonalElevation = 4.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("delayed_send_banner")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (banner.isScheduled) {
                        "Scheduled send queued · ${banner.subject}"
                    } else {
                        "Local send delay: submitting in ${banner.secondsRemaining}s · ${banner.subject}"
                    },
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Cancelling now stops submission locally before leaving your device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.78f)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Button(
                onClick = onCancelSend,
                colors = ButtonDefaults.buttonColors(containerColor = ext.warning, contentColor = Color.White),
                modifier = Modifier.testTag("undo_send_button")
            ) {
                Text("Cancel Send")
            }
        }
    }
}

@Composable
fun MyDaySidebar(
    state: AureomUiState,
    onToggleTaskComplete: (String) -> Unit,
    onOpenMessage: (String) -> Unit,
    onOpenCalendar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ext = LocalAureomColors.current
    val myDayTasks = state.tasks.filter { it.isInMyDay || !it.isCompleted }.take(5)
    val flaggedMail = state.allMessages.filter { it.isFlagged }.take(4)
    val upcomingEvents = state.events.take(4)

    Surface(
        color = ext.surfaceElevated,
        modifier = modifier
            .width(275.dp)
            .fillMaxHeight()
            .border(1.dp, ext.borderSubtle)
    ) {
        LazyColumn(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("My Day", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    TextButton(onClick = onOpenCalendar) {
                        Text("Calendar", style = MaterialTheme.typography.labelLarge)
                    }
                }
                HorizontalDivider(color = ext.borderSubtle)
            }
            item {
                Text(
                    "UPCOMING AGENDA (${state.selectedTimezoneId.substringAfterLast('/')})",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            items(upcomingEvents, key = { it.id }) { evt ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(evt.title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            CalendarMath.formatInZone(evt.startEpochMs, state.selectedTimezoneId),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "TASKS & FOLLOW-UPS",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            items(myDayTasks, key = { it.id }) { task ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onToggleTaskComplete(task.id) }
                        .padding(vertical = 4.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (task.isCompleted) Icons.Filled.CheckCircle else Icons.Outlined.TaskAlt,
                        contentDescription = "Toggle task",
                        tint = if (task.isCompleted) ext.success else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "FLAGGED MAIL",
                    style = MaterialTheme.typography.labelMedium,
                    color = ext.warning
                )
            }
            items(flaggedMail, key = { it.id }) { msg ->
                Surface(
                    color = ext.warningSoft,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenMessage(msg.id) }
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(msg.subject, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(msg.senderName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun AvatarCircle(name: String, colorHex: Long, sizeDp: Int = 34) {
    val initials = name.split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercase() }
        .ifEmpty { "A" }
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .background(Color(colorHex)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = initials,
            style = MaterialTheme.typography.labelMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun StatusChip(text: String, containerColor: Color, contentColor: Color) {
    Surface(
        color = containerColor,
        shape = RoundedCornerShape(4.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = contentColor,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
