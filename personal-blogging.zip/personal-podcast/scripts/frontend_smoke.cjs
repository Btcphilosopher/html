/* Frontend smoke test: loads the real index.html from a running backend inside jsdom and drives it.
 * Usage:  npm i jsdom && BASE=http://127.0.0.1:8000 ADMIN_EMAIL=... ADMIN_PASSWORD=... node scripts/frontend_smoke.cjs
 * Covers navigation, rendering, player state, Bitcoin address flow, search, admin login, article create+publish, logout.
 * It does not cover layout/responsiveness, real audio decoding, CSP enforcement or upload progress (needs a real browser). */
const { JSDOM, VirtualConsole } = require('jsdom');
const BASE = process.env.BASE || 'http://127.0.0.1:8765';
const EMAIL = process.env.ADMIN_EMAIL || 'admin@example.test', PASSWORD = process.env.ADMIN_PASSWORD || 'correct horse battery staple';
const errors = [], vc = new VirtualConsole();
vc.on('jsdomError', e => errors.push('jsdomError: ' + (e.detail && e.detail.stack || e.message)));
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));
let cookie = '';
async function realFetch(url, opts = {}) {
  const { signal, credentials, ...rest } = opts, headers = { ...(rest.headers || {}) };
  if (cookie) headers.cookie = cookie;
  const res = await fetch(new URL(url, BASE), { ...rest, headers });
  for (const c of (res.headers.getSetCookie ? res.headers.getSetCookie() : [])) { const kv = c.split(';')[0], name = kv.split('=')[0]; cookie = cookie.split('; ').filter(x => x && !x.startsWith(name + '=')).concat([kv]).join('; '); }
  return res;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
let doc, win;
async function waitFor(fn, what, ms = 6000) { const t = Date.now(); for (;;) { try { const v = fn(); if (v) return v; } catch { /* retry */ } if (Date.now() - t > ms) throw new Error('Timed out waiting for: ' + what); await sleep(40); } }
const text = sel => (doc.querySelector(sel) || {}).textContent || '';
const check = (cond, msg) => { if (!cond) throw new Error('FAILED: ' + msg); console.log('  ok  ' + msg); };
const fire = (el, type) => el.dispatchEvent(new win.Event(type, { bubbles: true, cancelable: true }));
const setVal = (el, v) => { el.value = v; fire(el, 'input'); };
const h1 = () => text('#main h1');
(async () => {
  const dom = await JSDOM.fromURL(BASE + '/', { runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, virtualConsole: vc, beforeParse(w) {
    w.fetch = realFetch; w.scrollTo = () => {}; w.confirm = () => true;
    Object.defineProperty(w.HTMLMediaElement.prototype, 'paused', { get() { return this._paused !== false; } });
    w.HTMLMediaElement.prototype.play = function () { this._paused = false; this.dispatchEvent(new w.Event('play')); return Promise.resolve(); };
    w.HTMLMediaElement.prototype.pause = function () { this._paused = true; this.dispatchEvent(new w.Event('pause')); };
    w.HTMLMediaElement.prototype.load = function () {};
  } });
  win = dom.window; doc = win.document;
  console.log('Public site');
  await waitFor(() => h1().includes('[Sample] A five second test tone'), 'home lead episode');
  check(text('#masthead').includes('The Slow Journal'), 'masthead shows configured site title');
  check(doc.title.includes('The Slow Journal'), 'document title set');
  check(doc.querySelectorAll('#main h3').length >= 1, 'article list rendered on home');
  doc.querySelector('.play[data-ep]').click();
  await waitFor(() => !doc.querySelector('#player').hidden, 'player bar visible');
  check(text('#pl-title').includes('Sample'), 'player shows the episode title');
  check(doc.querySelector('.play[data-ep]').getAttribute('aria-label').startsWith('Pause'), 'play button reflects playing state');
  doc.querySelector('#main h1 a').click();
  await waitFor(() => win.location.pathname.startsWith('/episodes/sample'), 'navigation to episode page');
  await waitFor(() => doc.querySelector('a[download]'), 'download link');
  check(doc.querySelector('a[download]').getAttribute('href').includes('/media/'), 'episode page links to the MP3');
  check(!doc.querySelector('#player').hidden, 'player persisted across client-side navigation');
  doc.querySelector('#masthead nav a[href="/support"]').click();
  await waitFor(() => h1() === 'Support this work', 'support page');
  check(doc.querySelectorAll('.chips button').length === 3, 'suggested amounts rendered');
  check(!text('#main').includes('Create Lightning invoice'), 'Lightning is not offered when no provider is configured');
  [...doc.querySelectorAll('button')].find(b => b.textContent === 'Show Bitcoin address').click();
  await waitFor(() => doc.querySelector('textarea.codebox'), 'address box');
  check(text('textarea.codebox') === 'bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq', 'on-chain address shown from the server');
  check(doc.querySelector('img.qr').getAttribute('src').startsWith('/api/v1/payments/qr?data=bitcoin'), 'QR points at the server QR endpoint');
  check(text('#main').includes('does not track on-chain gifts'), 'on-chain page states that gifts are not tracked');
  const form = doc.querySelector('#masthead form'); setVal(form.elements.q, 'sample'); fire(form, 'submit');
  await waitFor(() => win.location.pathname === '/search', 'search navigation');
  await waitFor(() => text('#main').includes('1 episodes and 1 articles match'), 'search results');
  win.history.pushState({}, '', '/nope-nothing'); win.dispatchEvent(new win.PopStateEvent('popstate'));
  await waitFor(() => h1() === 'This page does not exist', 'not-found view');
  console.log('Administration');
  doc.querySelector('footer a[href="/admin/login"]').click();
  await waitFor(() => h1() === 'Administrator sign in', 'login view');
  const lf = doc.querySelector('#main form'); lf.elements.email.value = 'wrong@example.test'; lf.elements.password.value = 'not the password'; fire(lf, 'submit');
  await waitFor(() => doc.querySelector('.alert'), 'login failure message');
  check(text('.alert').includes('incorrect'), 'wrong credentials show a clear error');
  lf.elements.email.value = EMAIL; lf.elements.password.value = PASSWORD; fire(lf, 'submit');
  await waitFor(() => h1() === 'Overview', 'dashboard after login');
  check(text('.dl').includes('1 published'), 'dashboard shows measured counts');
  check(text('.dl').includes('not collected'), 'dashboard states that listener statistics are not collected');
  doc.querySelector('.admin-nav a[href="/admin/articles"]').click();
  await waitFor(() => h1() === 'Articles' && doc.querySelector('.admin'), 'admin article list');
  doc.querySelector('a[href="/admin/articles/new"]').click();
  await waitFor(() => h1() === 'New article', 'article editor');
  const ed = doc.querySelector('.admin-body form');
  setVal(ed.querySelector('input[type=text]'), 'Smoke test article');
  setVal(ed.querySelector('textarea.mono'), '# Heading\n\nBody with <script>alert(1)</script> **bold**');
  await waitFor(() => doc.querySelector('.preview strong'), 'live server-rendered preview');
  check(!doc.querySelector('.preview').innerHTML.includes('<script'), 'preview is sanitised by the server');
  [...doc.querySelectorAll('button')].find(b => b.textContent === 'Publish now').click();
  await waitFor(() => /^\/admin\/articles\/\d+$/.test(win.location.pathname) && text('.pill') === 'published', 'article saved and published');
  const pub = await (await fetch(BASE + '/api/v1/articles')).json();
  check(pub.total === 2 && pub.items.some(a => a.title === 'Smoke test article'), 'published article is visible through the public API');
  [...doc.querySelectorAll('button')].find(b => b.textContent === 'Sign out').click();
  await waitFor(() => h1() === 'Administrator sign in', 'signed out');
  const after = await realFetch('/api/v1/admin/dashboard');
  check(after.status === 401, 'session is gone on the server after sign out');
  if (errors.length) { console.log('\nBrowser errors:\n' + errors.join('\n')); process.exit(1); }
  console.log('\nAll smoke checks passed with no browser errors.'); process.exit(0);
})().catch(e => { console.error('\n' + e.message); if (errors.length) console.error(errors.join('\n')); if (doc) console.error('Current view:', win.location.pathname, '|', h1()); process.exit(1); });
