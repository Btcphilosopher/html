#!/usr/bin/env sh
# Backs up the Postgres database and the media volume. Run from the repository root while the stack is up.
# Usage: scripts/backup.sh [backup-directory]      NOT exercised in the build environment (no Docker there).
set -eu
DIR="${1:-./backups}/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$DIR"
docker compose --env-file .env -f deploy/compose.yaml exec -T db pg_dump -U pp -Fc pp > "$DIR/database.dump"
docker run --rm -v personal-podcast_media:/data:ro -v "$(cd "$DIR" && pwd)":/backup alpine tar -C /data -czf /backup/media.tar.gz .
echo "Backup written to $DIR"
