#!/usr/bin/env sh
# Restores a backup made by backup.sh. DESTRUCTIVE: replaces the current database and media.
# Usage: scripts/restore.sh <backup-directory> --yes      NOT exercised in the build environment (no Docker there).
set -eu
[ "${2:-}" = "--yes" ] || { echo "This replaces the live database and media. Re-run with --yes to continue."; exit 1; }
DIR="$1"
docker compose --env-file .env -f deploy/compose.yaml stop app
docker compose --env-file .env -f deploy/compose.yaml exec -T db pg_restore -U pp -d pp --clean --if-exists < "$DIR/database.dump"
docker run --rm -v personal-podcast_media:/data -v "$(cd "$DIR" && pwd)":/backup alpine sh -c 'rm -rf /data/* && tar -C /data -xzf /backup/media.tar.gz'
docker compose --env-file .env -f deploy/compose.yaml start app
echo "Restore complete."
