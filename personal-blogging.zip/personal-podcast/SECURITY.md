# Security notes and threat model

Report vulnerabilities privately to the site operator (add a contact address here before publishing).

## Controls in place

* **Passwords:** Argon2id. Login runs the same hashing work for unknown users. No default credentials; the first
  administrator is created from the command line. Passwords need 12+ characters; changing it signs out all other sessions.
* **Sessions:** random 256-bit token, only its SHA-256 is stored; cookie is `HttpOnly`, `SameSite=Lax`, and `Secure`
  (enforced in production). No token is ever placed in `localStorage`; the only `localStorage` use is the playback position.
* **CSRF:** every cookie-authenticated write needs an `X-CSRF-Token` that matches the session, and the `Origin` header,
  if present, must match the site.
* **XSS:** the frontend builds DOM with text nodes. The only `innerHTML` receives server-sanitised HTML (`nh3`
  allow-list; scripts, event handlers and `javascript:` URLs removed) or static icons. The CSP uses a per-response nonce,
  has no `unsafe-inline`, `frame-ancestors 'none'`, and allows only same-origin images, media and connections.
* **Uploads:** authentication is checked before the body is parsed; `Content-Length` and size limits; contents sniffed
  and, for audio, decoded by `ffprobe`; the declared MIME type is ignored; SVG is rejected; storage keys are generated
  server-side and validated against a strict pattern and the storage root; temporary files are removed on failure and swept.
* **Media privacy:** audio and images are public only while a live episode, article or setting uses them; otherwise the
  server answers 404 to everyone except a signed-in administrator.
* **Payments:** amounts are integer satoshis; the provider's own API is the evidence of settlement; webhooks need a
  valid signature or secret *and* a settled status; `(provider, event_id)` is unique so replays are harmless; invoice
  status changes follow an explicit transition table; every event is recorded; credentials never reach the browser.
* **Abuse:** in-memory rate limits on login, invoice creation, status polling and subscriptions.
* **Headers:** `nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy`, HSTS in production,
  `no-store` on authentication, admin and payment responses. CORS is off unless origins are listed explicitly.
* **Secrets:** only from environment variables; the application refuses to start in production with weak or placeholder values.

## Threat model

| Threat | Mitigation | Residual risk |
|---|---|---|
| Account takeover (guessing, stuffing) | Argon2id, per-IP and per-email throttling, audit log of failures, long minimum length | No 2FA; throttling is per process. Use a unique passphrase and consider restricting `/admin` at the proxy |
| Session theft | HttpOnly/Secure cookies, 12 h lifetime, logout deletes the server session | Malware on the admin machine |
| Malicious uploads | Sniffing, ffprobe, no SVG, nosniff, random names, quotas | ffprobe/ffmpeg bugs; keep the image updated |
| Stored XSS via Markdown, titles, settings | Allow-list sanitiser, text-node rendering, nonce CSP | A sanitiser bypass would be limited by the CSP |
| CSRF | Token plus Origin check plus SameSite=Lax | None known |
| Payment spoofing | Settlement confirmed through the provider API; forged or unsettled webhooks recorded, not honoured | A compromised provider account |
| Webhook replay or duplication | Unique event ids; transitions are one-way | The LNbits webhook secret travels in the URL (LNbits cannot sign); the Caddyfile strips it from logs. Keep it long and rotate it |
| Wrong donation address | Checksum validation | A valid but wrong address cannot be detected. Check it by hand |
| Storage exhaustion | Per-file limit, total quota, proxy body limit, admin-only upload | Disk shared with other services |
| Scraping | Public content is public by design; paging limits (50 per page) | Bulk downloading of free MP3s |
| Denial of service | Streaming reads, rate limits on expensive public endpoints, Caddy in front | Not a substitute for a CDN or provider-level protection |
| Email abuse (subscribe bombing) | Rate limit, 60 s resend cooldown, verification required, generic responses | Distributed sources |

## Known limitations

Rate limits and the publish scheduler are per process (run one worker, or move limits to a shared store). Subscription
unsubscribe links are signed with `PP_SECRET_KEY`; rotating the key invalidates old links. Audit and payment records are
retained until you prune them. This software has not had an independent security review.
