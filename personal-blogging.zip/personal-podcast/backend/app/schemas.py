from datetime import datetime
from typing import Any, Generic, Literal, TypeVar

from pydantic import AwareDatetime, BaseModel, ConfigDict, EmailStr, Field, field_validator

from .services.text import SLUG_PATTERN

T = TypeVar("T")
_STRICT = ConfigDict(extra="forbid", str_strip_whitespace=True)


class Page(BaseModel, Generic[T]):
    items: list[T]
    page: int
    per_page: int
    total: int
    pages: int


class Chapter(BaseModel):
    model_config = _STRICT
    start_seconds: int = Field(ge=0, le=86_400)
    title: str = Field(min_length=1, max_length=200)


class Link(BaseModel):
    model_config = _STRICT
    title: str = Field(min_length=1, max_length=200)
    url: str = Field(max_length=500)

    @field_validator("url")
    @classmethod
    def _http(cls, v: str) -> str:
        if not v.startswith(("http://", "https://")) or any(c.isspace() for c in v):
            raise ValueError("must be an absolute http(s) URL")
        return v


class Term(BaseModel):
    name: str
    slug: str


Names = list[str]


def _names(v):
    if v is None:
        return v
    out = [" ".join(x.split()) for x in v]
    if any(not x or len(x) > 40 for x in out) or len(out) > 20:
        raise ValueError("up to 20 names of 1 to 40 characters")
    return out


class EpisodeCreate(BaseModel):
    model_config = _STRICT
    title: str = Field(min_length=1, max_length=200)
    slug: str | None = Field(default=None, max_length=100, pattern=SLUG_PATTERN)
    summary: str = Field(default="", max_length=4000)
    show_notes_md: str = Field(default="", max_length=100_000)
    season: int | None = Field(default=None, ge=1, le=999)
    episode_number: int | None = Field(default=None, ge=1, le=99_999)
    episode_type: Literal["full", "trailer", "bonus"] = "full"
    explicit: bool = False
    audio_id: int | None = None
    artwork_id: int | None = None
    tags: Names = Field(default_factory=list)
    categories: Names = Field(default_factory=list)
    chapters: list[Chapter] = Field(default_factory=list, max_length=200)
    links: list[Link] = Field(default_factory=list, max_length=50)
    transcript: str | None = Field(default=None, max_length=500_000)
    _n = field_validator("tags", "categories")(lambda cls, v: _names(v))


class EpisodeUpdate(BaseModel):
    model_config = _STRICT
    version: int = Field(ge=1)
    title: str | None = Field(default=None, min_length=1, max_length=200)
    slug: str | None = Field(default=None, max_length=100, pattern=SLUG_PATTERN)
    summary: str | None = Field(default=None, max_length=4000)
    show_notes_md: str | None = Field(default=None, max_length=100_000)
    season: int | None = Field(default=None, ge=1, le=999)
    episode_number: int | None = Field(default=None, ge=1, le=99_999)
    episode_type: Literal["full", "trailer", "bonus"] | None = None
    explicit: bool | None = None
    audio_id: int | None = None
    artwork_id: int | None = None
    tags: Names | None = None
    categories: Names | None = None
    chapters: list[Chapter] | None = Field(default=None, max_length=200)
    links: list[Link] | None = Field(default=None, max_length=50)
    transcript: str | None = Field(default=None, max_length=500_000)
    _n = field_validator("tags", "categories")(lambda cls, v: _names(v))


class ArticleCreate(BaseModel):
    model_config = _STRICT
    title: str = Field(min_length=1, max_length=200)
    slug: str | None = Field(default=None, max_length=100, pattern=SLUG_PATTERN)
    excerpt: str = Field(default="", max_length=1000)
    body_md: str = Field(default="", max_length=300_000)
    cover_id: int | None = None
    seo_title: str = Field(default="", max_length=200)
    seo_description: str = Field(default="", max_length=400)
    tags: Names = Field(default_factory=list)
    categories: Names = Field(default_factory=list)
    _n = field_validator("tags", "categories")(lambda cls, v: _names(v))


class ArticleUpdate(BaseModel):
    model_config = _STRICT
    version: int = Field(ge=1)
    title: str | None = Field(default=None, min_length=1, max_length=200)
    slug: str | None = Field(default=None, max_length=100, pattern=SLUG_PATTERN)
    excerpt: str | None = Field(default=None, max_length=1000)
    body_md: str | None = Field(default=None, max_length=300_000)
    cover_id: int | None = None
    seo_title: str | None = Field(default=None, max_length=200)
    seo_description: str | None = Field(default=None, max_length=400)
    tags: Names | None = None
    categories: Names | None = None
    _n = field_validator("tags", "categories")(lambda cls, v: _names(v))


class PublishRequest(BaseModel):
    model_config = _STRICT
    publish_at: AwareDatetime | None = None


class MarkdownPreview(BaseModel):
    model_config = _STRICT
    markdown: str = Field(max_length=300_000)


# ---- responses ---------------------------------------------------------------------------------
class ArticleCard(BaseModel):
    id: int
    slug: str
    title: str
    excerpt: str
    cover_url: str | None
    published_at: datetime | None
    updated_at: datetime
    tags: list[Term]
    categories: list[Term]
    reading_minutes: int
    url: str


class EpisodeCard(BaseModel):
    id: int
    slug: str
    title: str
    summary: str
    published_at: datetime | None
    season: int | None
    episode_number: int | None
    episode_type: str
    explicit: bool
    duration_seconds: float | None
    audio_url: str | None
    audio_size_bytes: int | None
    download_url: str | None
    artwork_url: str | None
    tags: list[Term]
    categories: list[Term]
    url: str


class EpisodePublic(EpisodeCard):
    show_notes_html: str
    chapters: list[Chapter]
    links: list[Link]
    transcript: str | None
    related_articles: list[ArticleCard] = []


class ArticlePublic(ArticleCard):
    body_html: str
    seo_title: str
    seo_description: str
    related_articles: list[ArticleCard] = []


class AdminFields(BaseModel):
    status: str
    publish_at: datetime | None
    version: int
    created_at: datetime
    deleted_at: datetime | None


class EpisodeAdminCard(EpisodeCard, AdminFields):
    pass


class EpisodeAdmin(EpisodePublic, AdminFields):
    show_notes_md: str
    audio_id: int | None
    artwork_id: int | None


class ArticleAdminCard(ArticleCard, AdminFields):
    pass


class ArticleAdmin(ArticlePublic, AdminFields):
    body_md: str
    cover_id: int | None


class RevisionOut(BaseModel):
    id: int
    version: int
    created_at: datetime
    snapshot: dict[str, Any]


class MediaOut(BaseModel):
    id: int
    public_id: str
    url: str
    original_filename: str
    mime: str
    size_bytes: int
    kind: str
    duration_seconds: float | None
    status: str
    storage_key: str
    meta: dict[str, Any]
    created_at: datetime
    used_by: list[dict[str, Any]] = []


# ---- auth / settings / payments / subscribers --------------------------------------------------
class LoginRequest(BaseModel):
    model_config = _STRICT
    email: str = Field(max_length=255)
    password: str = Field(max_length=256)


class PasswordChange(BaseModel):
    model_config = _STRICT
    current_password: str = Field(max_length=256)
    new_password: str = Field(min_length=12, max_length=256)


class SocialLink(BaseModel):
    model_config = _STRICT
    label: str = Field(min_length=1, max_length=40)
    url: str = Field(max_length=300)

    @field_validator("url")
    @classmethod
    def _http(cls, v: str) -> str:
        if not v.startswith(("http://", "https://")):
            raise ValueError("must be an absolute http(s) URL")
        return v


class SiteSettings(BaseModel):
    model_config = ConfigDict(extra="ignore")
    publisher_name: str = ""
    site_title: str = "Untitled publication"
    site_subtitle: str = ""
    wordmark: str = ""
    about_md: str = ""
    author_bio_md: str = ""
    social_links: list[SocialLink] = []
    contact_email: str = ""
    copyright_notice: str = ""
    default_artwork_id: int | None = None
    podcast_title: str = ""
    podcast_description: str = ""
    podcast_language: str = "en"
    podcast_explicit: bool = False
    podcast_category: str = ""
    podcast_author: str = ""
    podcast_owner_name: str = ""
    podcast_owner_email: str = ""
    donation_address: str = ""
    donation_message: str = ""
    suggested_amounts_sats: list[int] = []


class SiteSettingsPatch(BaseModel):
    model_config = _STRICT
    publisher_name: str | None = Field(default=None, max_length=120)
    site_title: str | None = Field(default=None, min_length=1, max_length=120)
    site_subtitle: str | None = Field(default=None, max_length=300)
    wordmark: str | None = Field(default=None, max_length=80)
    about_md: str | None = Field(default=None, max_length=50_000)
    author_bio_md: str | None = Field(default=None, max_length=20_000)
    social_links: list[SocialLink] | None = Field(default=None, max_length=12)
    contact_email: str | None = Field(default=None, max_length=255)
    copyright_notice: str | None = Field(default=None, max_length=300)
    default_artwork_id: int | None = None
    podcast_title: str | None = Field(default=None, max_length=200)
    podcast_description: str | None = Field(default=None, max_length=4000)
    podcast_language: str | None = Field(default=None, pattern=r"^[a-z]{2,3}(-[A-Za-z]{2,4})?$")
    podcast_explicit: bool | None = None
    podcast_category: str | None = Field(default=None, max_length=100)
    podcast_author: str | None = Field(default=None, max_length=200)
    podcast_owner_name: str | None = Field(default=None, max_length=200)
    podcast_owner_email: str | None = Field(default=None, max_length=255)
    donation_address: str | None = Field(default=None, max_length=100)
    donation_message: str | None = Field(default=None, max_length=1000)
    suggested_amounts_sats: list[int] | None = Field(default=None, max_length=8)

    @field_validator("suggested_amounts_sats")
    @classmethod
    def _amounts(cls, v):
        if v is not None and any(a < 1 or a > 100_000_000 for a in v):
            raise ValueError("amounts must be between 1 and 100,000,000 satoshis")
        return v


class InvoiceRequest(BaseModel):
    model_config = _STRICT
    kind: Literal["lightning", "onchain"]
    amount_sats: int | None = Field(default=None, ge=1)
    supporter_name: str = Field(default="", max_length=80)
    message: str = Field(default="", max_length=500)


class SubscribeRequest(BaseModel):
    model_config = _STRICT
    email: EmailStr


class TokenRequest(BaseModel):
    model_config = _STRICT
    token: str = Field(min_length=10, max_length=200)
