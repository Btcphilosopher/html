"""Publishing rules shared by episodes and articles: visibility, validation, revisions, serialisation."""
import logging
import uuid
from datetime import datetime, timedelta

from sqlalchemy import and_, extract, func, or_, select, update
from sqlalchemy.orm import Session

from .. import models as m
from ..errors import ApiError
from .text import plain_text, render_markdown, slugify

log = logging.getLogger("pp.content")
KINDS = {"episode": m.Episode, "article": m.Article}
SIMPLE = {
    "episode": ["title", "summary", "season", "episode_number", "episode_type", "explicit", "chapters", "links", "transcript"],
    "article": ["title", "excerpt", "seo_title", "seo_description"],
}
NON_NULLABLE = {"title", "summary", "episode_type", "explicit", "chapters", "links", "excerpt", "body_md", "show_notes_md",
                "seo_title", "seo_description", "tags", "categories"}
SEARCH_COLS = {"episode": ("title", "summary", "show_notes_md"), "article": ("title", "excerpt", "body_md")}
REVISION_FIELDS = {
    "episode": ["title", "slug", "summary", "show_notes_md", "season", "episode_number", "episode_type", "explicit",
                "audio_id", "artwork_id", "chapters", "links", "transcript"],
    "article": ["title", "slug", "excerpt", "body_md", "cover_id", "seo_title", "seo_description"],
}


def live_clause(model, now: datetime | None = None):
    """The single definition of 'publicly visible'. Draft, trashed and future-dated content never matches."""
    return and_(model.deleted_at.is_(None), model.status.in_(("published", "scheduled")),
                model.publish_at.is_not(None), model.publish_at <= (now or m.utcnow()))


def is_live(obj) -> bool:
    return obj.deleted_at is None and obj.status in ("published", "scheduled") and obj.publish_at is not None and obj.publish_at <= m.utcnow()


def kind_of(obj) -> str:
    return "episode" if isinstance(obj, m.Episode) else "article"


# ---- lookups ------------------------------------------------------------------------------------
def get_or_404(db: Session, kind: str, ident: int, include_deleted: bool = True):
    obj = db.get(KINDS[kind], ident)
    if not obj or (obj.deleted_at and not include_deleted):
        raise ApiError(404, "not_found", f"{kind.capitalize()} not found.")
    return obj


def get_live_by_slug(db: Session, kind: str, slug: str):
    model = KINDS[kind]
    obj = db.scalar(select(model).where(model.slug == slug, live_clause(model)))
    if not obj:
        raise ApiError(404, "not_found", f"{kind.capitalize()} not found.")
    return obj


def paginate(db: Session, stmt, page: int, per_page: int) -> tuple[list, int, int]:
    total = db.scalar(select(func.count()).select_from(stmt.order_by(None).subquery())) or 0
    rows = db.scalars(stmt.limit(per_page).offset((page - 1) * per_page)).unique().all()
    return rows, total, max(1, -(-total // per_page))


def list_stmt(kind: str, *, live: bool, q=None, category=None, tag=None, year=None, season=None, status=None):
    model = KINDS[kind]
    stmt = select(model)
    if live:
        stmt = stmt.where(live_clause(model)).order_by(model.publish_at.desc(), model.id.desc())
    else:
        if status == "trashed":
            stmt = stmt.where(model.deleted_at.is_not(None))
        else:
            stmt = stmt.where(model.deleted_at.is_(None))
            if status in ("draft", "scheduled", "published"):
                stmt = stmt.where(model.status == status)
        stmt = stmt.order_by(model.updated_at.desc(), model.id.desc())
    if q:
        stmt = stmt.where(or_(*[func.lower(getattr(model, c)).contains(q.lower(), autoescape=True) for c in SEARCH_COLS[kind]]))
    if category:
        stmt = stmt.where(model.categories.any(m.Category.slug == slugify(category)))
    if tag:
        stmt = stmt.where(model.tags.any(m.Tag.slug == slugify(tag)))
    if year:
        stmt = stmt.where(extract("year", model.publish_at) == year)
    if season and kind == "episode":
        stmt = stmt.where(model.season == season)
    return stmt


# ---- writes -------------------------------------------------------------------------------------
def get_or_create_terms(db: Session, model, names: list[str]) -> list:
    out, seen = [], set()
    for raw in names:
        name = " ".join(raw.split())[:40]
        slug = slugify(name)
        if not slug or slug in seen:
            continue
        seen.add(slug)
        term = db.scalar(select(model).where(model.slug == slug))
        if not term:
            term = model(name=name, slug=slug)
            db.add(term)
            db.flush()
        out.append(term)
    return out


def check_media(db: Session, media_id: int | None, kind: str) -> m.MediaAsset | None:
    if media_id is None:
        return None
    asset = db.get(m.MediaAsset, media_id)
    if not asset or asset.kind != kind or asset.status != "ready":
        raise ApiError(422, "invalid_media", f"Media {media_id} is not a ready {kind} file.")
    return asset


def ensure_slug_free(db: Session, model, slug: str, exclude_id: int | None = None) -> None:
    taken = db.scalar(select(model.id).where(model.slug == slug, model.id != (exclude_id or -1)))
    if taken:
        raise ApiError(409, "slug_taken", f"The address “{slug}” is already in use.")


def free_slug(db: Session, model, base: str) -> str:
    slug, n = base, 2
    while db.scalar(select(model.id).where(model.slug == slug)):
        slug, n = f"{base}-{n}", n + 1
    return slug


def apply_fields(db: Session, obj, data: dict) -> None:
    kind = kind_of(obj)
    for key in NON_NULLABLE & data.keys():
        if data[key] is None:
            raise ApiError(422, "validation_error", f"{key} cannot be null.")
    if data.get("slug") and data["slug"] != obj.slug:
        if obj.id is not None and obj.status != "draft":
            raise ApiError(409, "slug_locked", "The address of published or scheduled content cannot change. Unpublish it first.")
        ensure_slug_free(db, type(obj), data["slug"], obj.id)
        obj.slug = data["slug"]
    for f in SIMPLE[kind]:
        if f in data:
            val = data[f]
            if f in ("chapters", "links"):
                val = [dict(x) if isinstance(x, dict) else x.model_dump() for x in val]
            setattr(obj, f, val)
    if kind == "episode":
        if "show_notes_md" in data:
            obj.show_notes_md, obj.show_notes_html = data["show_notes_md"], render_markdown(data["show_notes_md"])
        if "audio_id" in data:
            obj.audio = check_media(db, data["audio_id"], "audio")
        if "artwork_id" in data:
            obj.artwork = check_media(db, data["artwork_id"], "image")
    else:
        if "body_md" in data:
            obj.body_md, obj.body_html = data["body_md"], render_markdown(data["body_md"])
        if "cover_id" in data:
            obj.cover = check_media(db, data["cover_id"], "image")
    if "tags" in data:
        obj.tags = get_or_create_terms(db, m.Tag, data["tags"])
    if "categories" in data:
        obj.categories = get_or_create_terms(db, m.Category, data["categories"])


def record_revision(db: Session, obj, user_id: int | None) -> None:
    kind = kind_of(obj)
    snap = {f: getattr(obj, f) for f in REVISION_FIELDS[kind]}
    snap["tags"], snap["categories"] = [t.name for t in obj.tags], [c.name for c in obj.categories]
    db.add(m.ContentRevision(content_type=kind, content_id=obj.id, version=obj.version, snapshot=snap, author_id=user_id))


def create(db: Session, kind: str, data: dict, user_id: int):
    model = KINDS[kind]
    data = dict(data)
    slug = data.pop("slug", None)
    if slug:
        ensure_slug_free(db, model, slug)
    else:
        slug = free_slug(db, model, slugify(data["title"], "untitled"))
    obj = model(guid=str(uuid.uuid4()), slug=slug, title=data["title"], status="draft", version=1)
    apply_fields(db, obj, data)
    db.add(obj)
    db.flush()
    record_revision(db, obj, user_id)
    return obj


def update_fields(db: Session, obj, data: dict, user_id: int):
    data = dict(data)
    version = data.pop("version")
    if obj.deleted_at:
        raise ApiError(409, "trashed", "Restore this item before editing it.")
    if version != obj.version:
        raise ApiError(409, "version_conflict", "This item was changed elsewhere. Reload it before saving.", {"current_version": obj.version})
    apply_fields(db, obj, data)
    obj.version += 1
    db.flush()
    record_revision(db, obj, user_id)
    return obj


def publish(db: Session, obj, publish_at: datetime | None):
    if obj.deleted_at:
        raise ApiError(409, "trashed", "Restore this item before publishing it.")
    if kind_of(obj) == "episode" and not (obj.audio and obj.audio.status == "ready"):
        raise ApiError(422, "audio_required", "Attach an uploaded MP3 before publishing this episode.")
    now = m.utcnow()
    when = publish_at or now
    obj.publish_at = when
    obj.status = "scheduled" if when > now + timedelta(seconds=5) else "published"
    obj.version += 1
    return obj


def unpublish(db: Session, obj):
    obj.status = "draft"
    obj.version += 1
    return obj


def publish_due(db: Session, now: datetime | None = None) -> dict:
    """Idempotent: flips due 'scheduled' items to 'published'. Visibility never depends on this running."""
    now, counts = now or m.utcnow(), {}
    for model in (m.Episode, m.Article):
        res = db.execute(update(model).where(model.status == "scheduled", model.publish_at <= now,
                                             model.deleted_at.is_(None)).values(status="published"))
        counts[model.__tablename__] = res.rowcount
    db.commit()
    if any(counts.values()):
        log.info("scheduled content published", extra={"counts": counts})
    return counts


def audit(db: Session, action: str, *, user_id: int | None = None, target: str = "", detail: dict | None = None, ip: str | None = None):
    db.add(m.AuditLog(user_id=user_id, action=action, target=target, detail=detail or {}, ip=ip))


# ---- serialisation ------------------------------------------------------------------------------
def media_filename(a: m.MediaAsset) -> str:
    ext = {"audio/mpeg": "mp3", "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp"}.get(a.mime, "bin")
    stem = a.original_filename.rsplit(".", 1)[0]
    return f"{slugify(stem, 'file')}.{ext}"


def media_url(a: m.MediaAsset | None) -> str | None:
    return f"/media/{a.public_id}/{media_filename(a)}" if a and a.status == "ready" else None


def _terms(items) -> list[dict]:
    return [{"name": t.name, "slug": t.slug} for t in items]


def episode_dict(ep: m.Episode) -> dict:
    audio = ep.audio if ep.audio and ep.audio.status == "ready" else None
    url = media_url(audio)
    return dict(
        id=ep.id, slug=ep.slug, title=ep.title, summary=ep.summary, published_at=ep.publish_at if is_live(ep) else None,
        season=ep.season, episode_number=ep.episode_number, episode_type=ep.episode_type, explicit=ep.explicit,
        duration_seconds=audio.duration_seconds if audio else None, audio_url=url,
        audio_size_bytes=audio.size_bytes if audio else None, download_url=f"{url}?download=1" if url else None,
        artwork_url=media_url(ep.artwork), tags=_terms(ep.tags), categories=_terms(ep.categories),
        url=f"/episodes/{ep.slug}", show_notes_html=ep.show_notes_html, chapters=ep.chapters or [], links=ep.links or [],
        transcript=ep.transcript, status=ep.status, publish_at=ep.publish_at, version=ep.version, created_at=ep.created_at,
        deleted_at=ep.deleted_at, show_notes_md=ep.show_notes_md, audio_id=ep.audio_id, artwork_id=ep.artwork_id,
    )


def article_dict(a: m.Article) -> dict:
    words = len(plain_text(a.body_html).split())
    return dict(
        id=a.id, slug=a.slug, title=a.title, excerpt=a.excerpt or plain_text(a.body_html)[:240],
        cover_url=media_url(a.cover), published_at=a.publish_at if is_live(a) else None, updated_at=a.updated_at,
        tags=_terms(a.tags), categories=_terms(a.categories), reading_minutes=max(1, round(words / 220)),
        url=f"/articles/{a.slug}", body_html=a.body_html, seo_title=a.seo_title, seo_description=a.seo_description,
        status=a.status, publish_at=a.publish_at, version=a.version, created_at=a.created_at, deleted_at=a.deleted_at,
        body_md=a.body_md, cover_id=a.cover_id,
    )


def related_articles(db: Session, tags: list[m.Tag], exclude_id: int | None = None, limit: int = 3) -> list[dict]:
    """Live articles sharing a tag first; padded with the newest live articles."""
    found: list[m.Article] = []
    if tags:
        stmt = (select(m.Article).where(live_clause(m.Article), m.Article.id != (exclude_id or -1),
                                        m.Article.tags.any(m.Tag.id.in_([t.id for t in tags])))
                .order_by(m.Article.publish_at.desc()).limit(limit))
        found = list(db.scalars(stmt).unique())
    if len(found) < limit:
        have = {a.id for a in found} | {exclude_id or -1}
        stmt = select(m.Article).where(live_clause(m.Article), m.Article.id.not_in(have)).order_by(m.Article.publish_at.desc()).limit(limit - len(found))
        found += list(db.scalars(stmt).unique())
    return [article_dict(a) for a in found]
