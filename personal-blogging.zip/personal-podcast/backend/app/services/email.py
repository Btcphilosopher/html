import smtplib
from email.message import EmailMessage


class EmailService:
    """Minimal SMTP adapter. `configured` is False until PP_SMTP_HOST and PP_SMTP_FROM are set."""

    def __init__(self, settings):
        self.s = settings

    @property
    def configured(self) -> bool:
        return bool(self.s.smtp_host and self.s.smtp_from)

    def send(self, to: str, subject: str, body: str) -> None:
        msg = EmailMessage()
        msg["From"], msg["To"], msg["Subject"] = self.s.smtp_from, to, subject
        msg.set_content(body)
        factory = smtplib.SMTP_SSL if self.s.smtp_port == 465 else smtplib.SMTP
        with factory(self.s.smtp_host, self.s.smtp_port, timeout=15) as smtp:
            if self.s.smtp_port != 465:
                smtp.starttls()
            if self.s.smtp_user:
                smtp.login(self.s.smtp_user, self.s.smtp_password)
            smtp.send_message(msg)
