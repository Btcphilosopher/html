"""Bitcoin address validation (Base58Check, Bech32, Bech32m) and BIP21 URIs. No network access."""
import hashlib
from decimal import Decimal
from urllib.parse import quote

_B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_BECH = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
_NETS = {"mainnet": {"b58": {0x00, 0x05}, "hrp": "bc"}, "testnet": {"b58": {0x6F, 0xC4}, "hrp": "tb"}}


def _b58check(addr: str, versions: set[int]) -> bool:
    n = 0
    for ch in addr:
        i = _B58.find(ch)
        if i < 0:
            return False
        n = n * 58 + i
    if n.bit_length() > 200:
        return False
    raw = n.to_bytes(25, "big")
    pad = len(addr) - len(addr.lstrip("1"))
    if raw[:pad] != b"\x00" * pad:
        return False
    return raw[0] in versions and hashlib.sha256(hashlib.sha256(raw[:21]).digest()).digest()[:4] == raw[21:]


def _polymod(values: list[int]) -> int:
    gen = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk = 1
    for v in values:
        top = chk >> 25
        chk = ((chk & 0x1FFFFFF) << 5) ^ v
        for i in range(5):
            if (top >> i) & 1:
                chk ^= gen[i]
    return chk


def _convert(data: list[int], frm: int, to: int) -> list[int] | None:
    """Regroup 5-bit values into bytes, rejecting non-zero or oversized padding (BIP173)."""
    acc = bits = 0
    out, maxv = [], (1 << to) - 1
    for v in data:
        acc = (acc << frm) | v
        bits += frm
        while bits >= to:
            bits -= to
            out.append((acc >> bits) & maxv)
    if bits >= frm or ((acc << (to - bits)) & maxv):
        return None
    return out


def _segwit(addr: str, hrp: str) -> bool:
    if any(ord(c) < 33 or ord(c) > 126 for c in addr) or (addr.lower() != addr and addr.upper() != addr):
        return False
    addr = addr.lower()
    pos = addr.rfind("1")
    if pos < 1 or pos + 7 > len(addr) or len(addr) > 90 or addr[:pos] != hrp:
        return False
    if any(c not in _BECH for c in addr[pos + 1:]):
        return False
    data = [_BECH.find(c) for c in addr[pos + 1:]]
    spec = _polymod([ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp] + data)
    if spec not in (1, 0x2BC830A3) or not data[:-6]:
        return False
    version, program = data[0], _convert(data[1:-6], 5, 8)
    if version > 16 or program is None or not 2 <= len(program) <= 40:
        return False
    if version == 0:
        return spec == 1 and len(program) in (20, 32)
    return spec == 0x2BC830A3


def validate_address(addr: str, network: str = "mainnet") -> bool:
    net = _NETS[network]
    addr = (addr or "").strip()
    if not 14 <= len(addr) <= 90:
        return False
    return _b58check(addr, net["b58"]) or _segwit(addr, net["hrp"])


def bip21(address: str, amount_sats: int | None = None, label: str | None = None) -> str:
    params = []
    if amount_sats:
        params.append("amount=" + f"{Decimal(amount_sats) / Decimal(10**8):.8f}")
    if label:
        params.append("label=" + quote(label))
    return f"bitcoin:{address}" + ("?" + "&".join(params) if params else "")
