"""Upload sniffing and ffprobe inspection. The client-declared MIME type is never trusted."""
import json
import shutil
import subprocess
from pathlib import Path


class ProbeError(Exception):
    pass


def ffprobe_available() -> bool:
    return shutil.which("ffprobe") is not None


def sniff_mp3(head: bytes) -> bool:
    if head[:3] == b"ID3":
        return True
    return (len(head) >= 4 and head[0] == 0xFF and (head[1] & 0xE0) == 0xE0
            and ((head[1] >> 3) & 3) != 1 and ((head[1] >> 1) & 3) != 0)


def sniff_image(head: bytes) -> tuple[str, str] | None:
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png", "png"
    if head.startswith(b"\xff\xd8\xff"):
        return "image/jpeg", "jpg"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "image/webp", "webp"
    return None


def probe_mp3(path: Path) -> dict:
    """Return {'duration': float|None, 'bit_rate': int|None}; raise ProbeError if it is not really MP3 audio."""
    cmd = ["ffprobe", "-v", "error", "-show_entries", "format=format_name,duration,bit_rate:stream=codec_type,codec_name",
           "-of", "json", str(path)]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30, check=False)
    except subprocess.TimeoutExpired as exc:
        raise ProbeError("Inspecting the audio timed out.") from exc
    if proc.returncode != 0:
        raise ProbeError("The file could not be decoded as audio.")
    try:
        info = json.loads(proc.stdout)
    except ValueError as exc:
        raise ProbeError("The file could not be inspected.") from exc
    streams = info.get("streams") or []
    audio = [s for s in streams if s.get("codec_type") == "audio"]
    if "mp3" not in (info.get("format") or {}).get("format_name", "") or not audio or audio[0].get("codec_name") != "mp3":
        raise ProbeError("The file is not MP3 audio.")
    fmt = info["format"]
    try:
        duration = float(fmt["duration"])
    except (KeyError, ValueError):
        duration = None
    try:
        bit_rate = int(fmt["bit_rate"])
    except (KeyError, ValueError):
        bit_rate = None
    return {"duration": duration, "bit_rate": bit_rate}
