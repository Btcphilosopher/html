"""RSS 2.0 + Apple Podcasts namespace feeds generated from published database rows."""
import hashlib
import logging
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import format_datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models as m
from .content import live_clause, media_url
from .site import default_artwork
from .text import plain_text, strip_xml_invalid

log = logging.getLogger("pp.rss")
NS = {"itunes": "http://www.itunes.com/dtds/podcast-1.0.dtd", "content": "http://purl.org/rss/1.0/modules/content/",
      "atom": "http://www.w3.org/2005/Atom"}
for _p, _u in NS.items():
    ET.register_namespace(_p, _u)
MAX_ITEMS = 500


def _q(prefix: str, tag: str) -> str:
    return f"{{{NS[prefix]}}}{tag}"


def _rfc2822(dt: datetime) -> str:
    return format_datetime(dt.astimezone(timezone.utc), usegmt=True)


def _hms(seconds: float) -> str:
    s = int(round(seconds))
    return f"{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"


def _sub(parent, tag, _text=None, **attrs):
    el = ET.SubElement(parent, tag, {k: strip_xml_invalid(str(v)) for k, v in attrs.items()})
    if _text is not None:
        el.text = strip_xml_invalid(str(_text))
    return el


def build_feed(db: Session, settings, storage, site, kind: str) -> tuple[bytes, datetime | None]:
    """kind: 'podcast' | 'blog' | 'all'. Returns (xml bytes, last modified)."""
    base = settings.site_url
    entries: list[tuple[datetime, int, str, object]] = []
    if kind in ("podcast", "all"):
        for ep in db.scalars(select(m.Episode).where(live_clause(m.Episode)).order_by(m.Episode.publish_at.desc(), m.Episode.id.desc()).limit(MAX_ITEMS)).unique():
            entries.append((ep.publish_at, ep.id, "episode", ep))
    if kind in ("blog", "all"):
        for a in db.scalars(select(m.Article).where(live_clause(m.Article)).order_by(m.Article.publish_at.desc(), m.Article.id.desc()).limit(MAX_ITEMS)).unique():
            entries.append((a.publish_at, a.id, "article", a))
    entries.sort(key=lambda e: (e[0], e[1]), reverse=True)

    title = {"podcast": site.podcast_title or site.site_title, "blog": f"{site.site_title}: articles", "all": site.site_title}[kind]
    desc = site.podcast_description or site.site_subtitle or title
    path = {"podcast": "/feed/podcast.xml", "blog": "/feed/blog.xml", "all": "/feed/all.xml"}[kind]
    rss = ET.Element("rss", {"version": "2.0"})
    ch = ET.SubElement(rss, "channel")
    _sub(ch, "title", title)
    _sub(ch, "link", base + "/")
    _sub(ch, "description", desc)
    _sub(ch, "language", site.podcast_language or "en")
    if site.copyright_notice:
        _sub(ch, "copyright", site.copyright_notice)
    _sub(ch, "generator", "personal-podcast")
    _sub(ch, _q("atom", "link"), href=base + path, rel="self", type="application/rss+xml")
    author = site.podcast_author or site.publisher_name
    if kind != "blog":
        if author:
            _sub(ch, _q("itunes", "author"), author)
        if site.podcast_owner_email or site.podcast_owner_name:
            owner = ET.SubElement(ch, _q("itunes", "owner"))
            if site.podcast_owner_name:
                _sub(owner, _q("itunes", "name"), site.podcast_owner_name)
            if site.podcast_owner_email:
                _sub(owner, _q("itunes", "email"), site.podcast_owner_email)
        _sub(ch, _q("itunes", "explicit"), "true" if site.podcast_explicit else "false")
        _sub(ch, _q("itunes", "type"), "episodic")
        if site.podcast_category:
            _sub(ch, _q("itunes", "category"), text=site.podcast_category)
    art = default_artwork(db, site)
    if art:
        _sub(ch, _q("itunes", "image"), href=base + media_url(art))
        img = ET.SubElement(ch, "image")
        _sub(img, "url", base + media_url(art))
        _sub(img, "title", title)
        _sub(img, "link", base + "/")

    last_mod: datetime | None = None
    for published, _id, etype, obj in entries:
        item = ET.Element("item")
        link = f"{base}/{'episodes' if etype == 'episode' else 'articles'}/{obj.slug}"
        if etype == "episode":
            audio = obj.audio
            if not audio or audio.status != "ready" or not storage.exists(audio.storage_key):
                log.warning("episode skipped in feed: audio missing", extra={"episode_id": obj.id})
                continue
            body_html, text = obj.show_notes_html, obj.summary or plain_text(obj.show_notes_html)[:4000]
        else:
            body_html, text = obj.body_html, obj.excerpt or plain_text(obj.body_html)[:500]
        _sub(item, "title", obj.title)
        _sub(item, "link", link)
        _sub(item, "guid", obj.guid, isPermaLink="false")
        _sub(item, "pubDate", _rfc2822(published))
        _sub(item, "description", text or obj.title)
        if body_html:
            _sub(item, _q("content", "encoded"), body_html)
        for c in obj.categories:
            _sub(item, "category", c.name)
        if etype == "episode":
            _sub(item, "enclosure", url=base + media_url(audio), length=storage.size(audio.storage_key), type="audio/mpeg")
            if audio.duration_seconds:
                _sub(item, _q("itunes", "duration"), _hms(audio.duration_seconds))
            _sub(item, _q("itunes", "explicit"), "true" if obj.explicit else "false")
            _sub(item, _q("itunes", "episodeType"), obj.episode_type)
            if obj.episode_number:
                _sub(item, _q("itunes", "episode"), obj.episode_number)
            if obj.season:
                _sub(item, _q("itunes", "season"), obj.season)
            if obj.artwork:
                _sub(item, _q("itunes", "image"), href=base + media_url(obj.artwork))
        ch.append(item)
        stamp = max(published, obj.updated_at)
        last_mod = stamp if last_mod is None or stamp > last_mod else last_mod
    if last_mod:
        build = ET.Element("lastBuildDate")
        build.text = _rfc2822(last_mod)
        ch.insert(5, build)
    return ET.tostring(rss, encoding="utf-8", xml_declaration=True), last_mod


def etag_for(body: bytes) -> str:
    return '"' + hashlib.sha256(body).hexdigest()[:32] + '"'


def feed_warnings(db: Session, settings, site) -> list[str]:
    """Things Apple Podcasts / directories will complain about. Shown on the admin dashboard."""
    out = []
    if not site.podcast_description:
        out.append("Add a podcast description in Settings.")
    if not default_artwork(db, site):
        out.append("Upload default artwork (square, 1400 to 3000 px) and select it in Settings.")
    if not site.podcast_category:
        out.append("Choose a podcast category in Settings.")
    if not site.podcast_owner_email:
        out.append("Add an owner email so directories can verify the feed.")
    if not settings.site_url.startswith("https://"):
        out.append("The site URL is not HTTPS; directories require HTTPS enclosure URLs.")
    return out
