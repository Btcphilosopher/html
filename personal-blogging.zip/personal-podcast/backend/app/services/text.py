import re
import unicodedata

import markdown as _markdown
import nh3

SLUG_PATTERN = r"^[a-z0-9]+(?:-[a-z0-9]+)*$"
SLUG_RE = re.compile(SLUG_PATTERN)
_XML_BAD = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]")


def slugify(text: str, fallback: str = "") -> str:
    norm = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()
    slug = re.sub(r"[^a-z0-9]+", "-", norm.lower()).strip("-")[:80].strip("-")
    return slug or fallback


def strip_xml_invalid(text: str) -> str:
    return _XML_BAD.sub("", text or "")


_TAGS = {"p", "br", "hr", "h1", "h2", "h3", "h4", "h5", "h6", "em", "strong", "code", "pre", "blockquote", "ul", "ol",
         "li", "a", "img", "table", "thead", "tbody", "tr", "th", "td", "del", "sup", "sub", "figure", "figcaption"}
_ATTRS = {"a": {"href", "title"}, "img": {"src", "alt", "title"}, "th": {"align"}, "td": {"align"}}


def render_markdown(md: str) -> str:
    """Markdown -> sanitised HTML. Raw HTML in the source is run through the same allow-list."""
    html = _markdown.markdown(md or "", extensions=["extra", "sane_lists"], output_format="html")
    return nh3.clean(html, tags=_TAGS, attributes=_ATTRS, url_schemes={"http", "https", "mailto"},
                     link_rel="noopener noreferrer", strip_comments=True)


def plain_text(html: str) -> str:
    return re.sub(r"\s+", " ", nh3.clean(html or "", tags=set())).strip()
