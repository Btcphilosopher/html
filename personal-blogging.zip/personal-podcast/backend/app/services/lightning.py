"""Lightning payment providers. Providers only create invoices and report authoritative status;
the payments API decides what a webhook means. Secrets never leave the server."""
import hashlib
import hmac
import json
import secrets
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Mapping

import httpx


class ProviderError(Exception):
    """The provider is unreachable or returned something unusable."""


class WebhookAuthError(Exception):
    """A webhook failed authentication and must be rejected."""


@dataclass
class ProviderInvoice:
    provider_ref: str
    bolt11: str
    expires_at: datetime


@dataclass
class WebhookEvent:
    event_id: str
    provider_ref: str


class LNbitsProvider:
    """Adapter for the documented LNbits HTTP API. Authenticates webhooks with a shared secret and
    never trusts the webhook body: settlement is confirmed by asking LNbits for the payment status."""

    name = "lnbits"

    def __init__(self, base_url: str, invoice_key: str, webhook_secret: str, client: httpx.Client | None = None):
        self.base, self.key, self.secret = base_url.rstrip("/"), invoice_key, webhook_secret
        self.client = client or httpx.Client(timeout=10)

    def create_invoice(self, amount_sats: int, memo: str, expiry_seconds: int, webhook_url: str) -> ProviderInvoice:
        try:
            r = self.client.post(f"{self.base}/api/v1/payments", headers={"X-Api-Key": self.key},
                                 json={"out": False, "amount": amount_sats, "memo": memo, "expiry": expiry_seconds,
                                       "webhook": f"{webhook_url}?secret={self.secret}"})
            r.raise_for_status()
            body = r.json()
            ref, bolt11 = body["payment_hash"], body.get("bolt11") or body["payment_request"]
        except (httpx.HTTPError, KeyError, ValueError) as exc:
            raise ProviderError("Could not create a Lightning invoice.") from exc
        return ProviderInvoice(ref, bolt11, datetime.now(timezone.utc) + timedelta(seconds=expiry_seconds))

    def get_status(self, provider_ref: str) -> str:
        try:
            r = self.client.get(f"{self.base}/api/v1/payments/{provider_ref}", headers={"X-Api-Key": self.key})
            r.raise_for_status()
            return "paid" if r.json().get("paid") is True else "unpaid"
        except (httpx.HTTPError, ValueError) as exc:
            raise ProviderError("Could not check the payment status.") from exc

    def parse_webhook(self, headers: Mapping[str, str], query: Mapping[str, str], body: bytes) -> WebhookEvent:
        if not hmac.compare_digest(query.get("secret", ""), self.secret):
            raise WebhookAuthError("bad webhook secret")
        try:
            ref = str(json.loads(body)["payment_hash"])
        except (ValueError, KeyError, TypeError) as exc:
            raise WebhookAuthError("malformed webhook body") from exc
        return WebhookEvent(event_id=ref, provider_ref=ref)


class MockProvider:
    """Test-only provider (Settings refuses it unless PP_ENV=test). Signed webhooks like a real provider would be;
    `settle()` stands in for the real network settling an invoice."""

    name = "mock"

    def __init__(self, secret: str):
        self.secret, self.invoices, self.settled = secret, {}, set()

    def create_invoice(self, amount_sats, memo, expiry_seconds, webhook_url):
        ref = secrets.token_hex(16)
        self.invoices[ref] = amount_sats
        return ProviderInvoice(ref, f"lnbcmock{amount_sats}n1{ref}", datetime.now(timezone.utc) + timedelta(seconds=expiry_seconds))

    def get_status(self, provider_ref):
        return "paid" if provider_ref in self.settled else "unpaid"

    def settle(self, provider_ref):
        self.settled.add(provider_ref)

    def sign(self, body: bytes) -> str:
        return hmac.new(self.secret.encode(), body, hashlib.sha256).hexdigest()

    def parse_webhook(self, headers, query, body):
        if not hmac.compare_digest(headers.get("x-mock-signature", ""), self.sign(body)):
            raise WebhookAuthError("bad signature")
        try:
            data = json.loads(body)
            return WebhookEvent(str(data["event_id"]), str(data["payment_hash"]))
        except (ValueError, KeyError, TypeError) as exc:
            raise WebhookAuthError("malformed webhook body") from exc


def build_provider(settings):
    if settings.payment_provider == "lnbits":
        return LNbitsProvider(settings.lnbits_url, settings.lnbits_invoice_key, settings.lnbits_webhook_secret)
    if settings.payment_provider == "mock":
        return MockProvider(settings.mock_webhook_secret)
    return None
