from sqlalchemy import select
from sqlalchemy.orm import Session

from ..models import MediaAsset, SiteSetting
from ..schemas import SiteSettings


def load_site(db: Session) -> SiteSettings:
    rows = {r.key: r.value for r in db.scalars(select(SiteSetting))}
    return SiteSettings(**{k: v for k, v in rows.items() if k in SiteSettings.model_fields})


def save_site(db: Session, changes: dict) -> None:
    for key, value in changes.items():
        row = db.get(SiteSetting, key)
        if row:
            row.value = value
        else:
            db.add(SiteSetting(key=key, value=value))


def default_artwork(db: Session, site: SiteSettings) -> MediaAsset | None:
    if not site.default_artwork_id:
        return None
    asset = db.get(MediaAsset, site.default_artwork_id)
    return asset if asset and asset.kind == "image" and asset.status == "ready" else None
