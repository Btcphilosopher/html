"""Application configuration. Every value comes from PP_* environment variables (or a .env file)."""
from pathlib import Path

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

REPO_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="PP_", env_file=".env", extra="ignore")

    env: str = "development"  # development | production | test
    site_url: str = "http://localhost:8000"
    secret_key: str = "dev-insecure-secret-change-me"
    database_url: str = "sqlite:///./data/personal_podcast.db"
    media_dir: Path = Path("./data/media")
    frontend_path: Path = REPO_ROOT / "index.html"
    auto_create_tables: bool = False  # development convenience only; production uses Alembic
    scheduler_enabled: bool = True
    scheduler_interval_seconds: int = 30

    cookie_secure: bool = True
    session_ttl_hours: int = 12
    cors_origins: str = ""  # comma separated, explicit origins only

    max_audio_mb: int = 300
    max_image_mb: int = 10
    storage_quota_mb: int = 5000
    require_ffprobe: bool = False
    stale_upload_seconds: int = 3600

    bitcoin_network: str = "mainnet"  # mainnet | testnet
    payment_provider: str = "none"  # none | lnbits | mock (mock only when env=test)
    lnbits_url: str = ""
    lnbits_invoice_key: str = ""
    lnbits_webhook_secret: str = ""
    mock_webhook_secret: str = "test-webhook-secret"
    invoice_expiry_seconds: int = 3600
    max_invoice_sats: int = 10_000_000

    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @model_validator(mode="after")
    def _check(self):
        if self.env == "production":
            if not self.cookie_secure:
                raise ValueError("PP_COOKIE_SECURE must be true in production")
            if not self.site_url.startswith("https://"):
                raise ValueError("PP_SITE_URL must be https:// in production")
            if len(self.secret_key) < 32 or self.secret_key.startswith("dev-") or "change-me" in self.secret_key:
                raise ValueError("PP_SECRET_KEY must be a random value of at least 32 characters in production")
        if self.payment_provider == "mock" and self.env != "test":
            raise ValueError("The mock payment provider is only available when PP_ENV=test")
        if self.payment_provider == "lnbits" and not (self.lnbits_url and self.lnbits_invoice_key and self.lnbits_webhook_secret):
            raise ValueError("lnbits needs PP_LNBITS_URL, PP_LNBITS_INVOICE_KEY and PP_LNBITS_WEBHOOK_SECRET")
        if self.payment_provider not in {"none", "lnbits", "mock"}:
            raise ValueError("PP_PAYMENT_PROVIDER must be none, lnbits or mock")
        if self.bitcoin_network not in {"mainnet", "testnet"}:
            raise ValueError("PP_BITCOIN_NETWORK must be mainnet or testnet")
        self.site_url = self.site_url.rstrip("/")
        return self
