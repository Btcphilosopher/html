class ApiError(Exception):
    """Raised anywhere in the API; rendered as {"error": {"code", "message", "details"}}."""

    def __init__(self, status: int, code: str, message: str, details=None, headers: dict | None = None):
        super().__init__(message)
        self.status, self.code, self.message, self.details, self.headers = status, code, message, details, headers or {}
