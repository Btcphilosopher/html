"""One router factory for episodes and articles: they share lifecycle, validation and permissions."""
from fastapi import APIRouter, Depends, Query, Request, Response
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas import Page, PublishRequest, RevisionOut
from ..security import client_ip, require_admin
from ..services import content
from ..models import AuthSession, ContentRevision
from sqlalchemy import select


def make_router(kind, plural, Create, Update, to_dict, Card, Public, AdminCard, Admin) -> APIRouter:
    r = APIRouter(tags=[plural])

    def page_of(db, stmt, page, per_page, model, mapper=to_dict):
        rows, total, pages = content.paginate(db, stmt, page, per_page)
        return {"items": [mapper(x) for x in rows], "page": page, "per_page": per_page, "total": total, "pages": pages}

    # ---- public ----
    @r.get(f"/{plural}", response_model=Page[Card])
    def list_public(db: Session = Depends(get_db), page: int = Query(1, ge=1, le=10_000), per_page: int = Query(12, ge=1, le=50),
                    q: str | None = Query(None, max_length=100), category: str | None = Query(None, max_length=60),
                    tag: str | None = Query(None, max_length=60), year: int | None = Query(None, ge=1990, le=2100),
                    season: int | None = Query(None, ge=1, le=999)):
        stmt = content.list_stmt(kind, live=True, q=q, category=category, tag=tag, year=year, season=season)
        return page_of(db, stmt, page, per_page, None)

    @r.get(f"/{plural}/{{slug}}", response_model=Public)
    def detail(slug: str, db: Session = Depends(get_db)):
        obj = content.get_live_by_slug(db, kind, slug)
        d = to_dict(obj)
        d["related_articles"] = content.related_articles(db, obj.tags, obj.id if kind == "article" else None)
        return d

    # ---- admin reads ----
    @r.get(f"/admin/{plural}", response_model=Page[AdminCard])
    def list_admin(db: Session = Depends(get_db), _: AuthSession = Depends(require_admin), page: int = Query(1, ge=1, le=10_000),
                   per_page: int = Query(20, ge=1, le=50), q: str | None = Query(None, max_length=100),
                   status: str | None = Query(None, pattern="^(draft|scheduled|published|trashed)$")):
        return page_of(db, content.list_stmt(kind, live=False, q=q, status=status), page, per_page, None)

    @r.get(f"/admin/{plural}/{{ident}}", response_model=Admin)
    def detail_admin(ident: int, db: Session = Depends(get_db), _: AuthSession = Depends(require_admin)):
        obj = content.get_or_404(db, kind, ident)
        d = to_dict(obj)
        d["related_articles"] = []
        return d

    @r.get(f"/admin/{plural}/{{ident}}/revisions", response_model=list[RevisionOut])
    def revisions(ident: int, db: Session = Depends(get_db), _: AuthSession = Depends(require_admin)):
        content.get_or_404(db, kind, ident)
        rows = db.scalars(select(ContentRevision).where(ContentRevision.content_type == kind, ContentRevision.content_id == ident)
                          .order_by(ContentRevision.id.desc()).limit(50))
        return [{"id": x.id, "version": x.version, "created_at": x.created_at, "snapshot": x.snapshot} for x in rows]

    # ---- writes ----
    def respond(db, obj):
        db.commit()
        d = to_dict(obj)
        d["related_articles"] = []
        return d

    @r.post(f"/{plural}", response_model=Admin, status_code=201)
    def create(body: Create, request: Request, db: Session = Depends(get_db), sess: AuthSession = Depends(require_admin)):
        obj = content.create(db, kind, body.model_dump(exclude_unset=True), sess.user_id)
        content.audit(db, f"{kind}.create", user_id=sess.user_id, target=str(obj.id), ip=client_ip(request))
        return respond(db, obj)

    @r.patch(f"/{plural}/{{ident}}", response_model=Admin)
    def patch(ident: int, body: Update, request: Request, db: Session = Depends(get_db), sess: AuthSession = Depends(require_admin)):
        obj = content.get_or_404(db, kind, ident)
        content.update_fields(db, obj, body.model_dump(exclude_unset=True), sess.user_id)
        content.audit(db, f"{kind}.update", user_id=sess.user_id, target=str(obj.id), ip=client_ip(request))
        return respond(db, obj)

    @r.post(f"/{plural}/{{ident}}/publish", response_model=Admin)
    def publish(ident: int, request: Request, body: PublishRequest | None = None, db: Session = Depends(get_db),
                sess: AuthSession = Depends(require_admin)):
        obj = content.get_or_404(db, kind, ident)
        content.publish(db, obj, body.publish_at if body else None)
        content.audit(db, f"{kind}.publish", user_id=sess.user_id, target=str(obj.id), detail={"status": obj.status}, ip=client_ip(request))
        return respond(db, obj)

    @r.post(f"/{plural}/{{ident}}/unpublish", response_model=Admin)
    def unpublish(ident: int, request: Request, db: Session = Depends(get_db), sess: AuthSession = Depends(require_admin)):
        obj = content.get_or_404(db, kind, ident)
        content.unpublish(db, obj)
        content.audit(db, f"{kind}.unpublish", user_id=sess.user_id, target=str(obj.id), ip=client_ip(request))
        return respond(db, obj)

    @r.delete(f"/{plural}/{{ident}}", status_code=204)
    def delete(ident: int, request: Request, db: Session = Depends(get_db), sess: AuthSession = Depends(require_admin)):
        obj = content.get_or_404(db, kind, ident)
        obj.deleted_at, obj.status = content.m.utcnow(), "draft"
        obj.version += 1
        content.audit(db, f"{kind}.delete", user_id=sess.user_id, target=str(obj.id), ip=client_ip(request))
        db.commit()
        return Response(status_code=204)

    @r.post(f"/{plural}/{{ident}}/restore", response_model=Admin)
    def restore(ident: int, request: Request, db: Session = Depends(get_db), sess: AuthSession = Depends(require_admin)):
        obj = content.get_or_404(db, kind, ident)
        obj.deleted_at, obj.status = None, "draft"
        obj.version += 1
        content.audit(db, f"{kind}.restore", user_id=sess.user_id, target=str(obj.id), ip=client_ip(request))
        return respond(db, obj)

    return r
