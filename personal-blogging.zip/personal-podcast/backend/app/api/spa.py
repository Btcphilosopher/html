"""Serves index.html with per-route SEO metadata and a CSP nonce, plus robots.txt and sitemap.xml."""
import html
import re
import secrets
from datetime import timezone

from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import HTMLResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models as m
from ..database import get_db
from ..services.content import live_clause, media_url
from ..services.site import default_artwork, load_site
from ..services.text import plain_text

router = APIRouter(include_in_schema=False)
RESERVED = ("api/", "media/", "feed/")


def _meta(request: Request, db: Session, path: str) -> tuple[str, int]:
    s, site = request.app.state.settings, load_site(db)
    title, desc, image, audio, kind, status = site.site_title, site.site_subtitle or site.podcast_description, None, None, "website", 200
    art = default_artwork(db, site)
    if art:
        image = s.site_url + media_url(art)
    if mt := re.fullmatch(r"/episodes/([a-z0-9-]+)", path):
        ep = db.scalar(select(m.Episode).where(m.Episode.slug == mt[1], live_clause(m.Episode)))
        if ep:
            title, desc, kind = ep.title, ep.summary or plain_text(ep.show_notes_html)[:200], "article"
            image = s.site_url + media_url(ep.artwork) if ep.artwork else image
            audio = s.site_url + media_url(ep.audio) if ep.audio else None
        else:
            status = 404
    elif mt := re.fullmatch(r"/articles/([a-z0-9-]+)", path):
        a = db.scalar(select(m.Article).where(m.Article.slug == mt[1], live_clause(m.Article)))
        if a:
            title, desc, kind = a.seo_title or a.title, a.seo_description or a.excerpt or plain_text(a.body_html)[:200], "article"
            image = s.site_url + media_url(a.cover) if a.cover else image
        else:
            status = 404
    full = title if title == site.site_title else f"{title} | {site.site_title}"
    e = lambda v: html.escape(v or "", quote=True)  # noqa: E731
    tags = [f"<title>{e(full)}</title>", f'<meta name="description" content="{e(desc)}">',
            f'<link rel="canonical" href="{e(s.site_url + path)}">',
            f'<meta property="og:type" content="{kind}">', f'<meta property="og:title" content="{e(title)}">',
            f'<meta property="og:description" content="{e(desc)}">', f'<meta property="og:url" content="{e(s.site_url + path)}">',
            f'<meta property="og:site_name" content="{e(site.site_title)}">',
            f'<meta name="twitter:card" content="{"summary_large_image" if image else "summary"}">',
            f'<link rel="alternate" type="application/rss+xml" title="Podcast" href="{e(s.site_url)}/feed/podcast.xml">',
            f'<link rel="alternate" type="application/rss+xml" title="Articles" href="{e(s.site_url)}/feed/blog.xml">']
    if image:
        tags.append(f'<meta property="og:image" content="{e(image)}">')
    if audio:
        tags.append(f'<meta property="og:audio" content="{e(audio)}"><meta property="og:audio:type" content="audio/mpeg">')
    if status == 404 or path.startswith("/admin"):
        tags.append('<meta name="robots" content="noindex">')
    return "\n".join(tags), status, f"<h1>{e(title)}</h1><p>{e(desc)}</p>"


@router.get("/robots.txt")
def robots(request: Request):
    return Response(f"User-agent: *\nDisallow: /admin\nDisallow: /api/\nSitemap: {request.app.state.settings.site_url}/sitemap.xml\n", media_type="text/plain")


@router.get("/sitemap.xml")
def sitemap(request: Request, db: Session = Depends(get_db)):
    base = request.app.state.settings.site_url
    urls = [(f"{base}{p}", None) for p in ("/", "/episodes", "/articles", "/about", "/support")]
    for model, prefix in ((m.Episode, "episodes"), (m.Article, "articles")):
        for o in db.scalars(select(model).where(live_clause(model)).order_by(model.publish_at.desc())).unique():
            urls.append((f"{base}/{prefix}/{o.slug}", o.updated_at.astimezone(timezone.utc).strftime("%Y-%m-%d")))
    body = "".join(f"<url><loc>{html.escape(u)}</loc>{f'<lastmod>{d}</lastmod>' if d else ''}</url>" for u, d in urls)
    return Response(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{body}</urlset>', media_type="application/xml")


@router.get("/{full_path:path}")
def shell(request: Request, full_path: str, db: Session = Depends(get_db)):
    if full_path.startswith(RESERVED):
        return Response('{"error":{"code":"not_found","message":"Not found."}}', status_code=404, media_type="application/json")
    path = "/" + full_path.rstrip("/") if full_path.rstrip("/") else "/"
    path_file = request.app.state.settings.frontend_path
    if not path_file.is_file():
        return Response("index.html not found. Set PP_FRONTEND_PATH.", status_code=500, media_type="text/plain")
    meta, status, noscript = _meta(request, db, path)
    nonce = secrets.token_urlsafe(16)
    page = path_file.read_text(encoding="utf-8").replace("__CSP_NONCE__", nonce).replace("<!--SERVER_META-->", meta).replace("<!--SERVER_NOSCRIPT-->", noscript)
    csp = (f"default-src 'self'; script-src 'nonce-{nonce}'; style-src 'nonce-{nonce}'; img-src 'self' data:; media-src 'self'; "
           "connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
    return HTMLResponse(page, status_code=status, headers={"Content-Security-Policy": csp, "Cache-Control": "no-cache"})
