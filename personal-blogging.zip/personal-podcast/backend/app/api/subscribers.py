import logging
from datetime import timedelta

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import models as m
from ..database import get_db
from ..errors import ApiError
from ..schemas import SubscribeRequest, TokenRequest
from ..security import client_ip, hmac_token, new_token, require_admin, sha256_hex
import hmac

log = logging.getLogger("pp.subscribers")
router = APIRouter(prefix="/subscribers", tags=["subscribers"])
VERIFY_TTL = timedelta(hours=48)
RESEND_COOLDOWN = timedelta(seconds=60)
GENERIC = {"message": "If this address can be subscribed, a verification email is on its way."}


def unsubscribe_token(secret: str, sub: m.Subscriber) -> str:
    return f"{sub.id}.{hmac_token(secret, f'unsub:{sub.id}:{sub.email}')}"


@router.post("", status_code=202)
def subscribe(body: SubscribeRequest, request: Request, db: Session = Depends(get_db)):
    request.app.state.limiters["subscribe"].check(client_ip(request))
    mail = request.app.state.email
    if not mail.configured:
        raise ApiError(503, "email_unavailable", "This site cannot send verification emails yet, so subscriptions are switched off.")
    settings, email, now = request.app.state.settings, body.email.lower(), m.utcnow()
    sub = db.scalar(select(m.Subscriber).where(m.Subscriber.email == email))
    if sub and sub.status == "verified":
        return GENERIC  # no signal about who is already subscribed
    if sub and sub.status == "pending" and sub.verify_sent_at and now - sub.verify_sent_at < RESEND_COOLDOWN:
        return GENERIC
    if not sub:
        sub = m.Subscriber(email=email, status="pending")
        db.add(sub)
    sub.status = "pending"
    token = new_token()
    sub.verify_token_hash, sub.verify_sent_at = sha256_hex(token), now
    db.commit()
    link = f"{settings.site_url}/subscribe/verify?token={token}"
    try:
        mail.send(email, "Confirm your subscription", f"Confirm your subscription by opening this link (valid for 48 hours):\n\n{link}\n\nIf you did not ask for this, ignore this email.")
    except Exception as exc:  # smtplib raises many types; none should leak to the caller
        log.error("verification email failed", extra={"error": type(exc).__name__})
        raise ApiError(502, "email_failed", "The verification email could not be sent. Try again later.") from exc
    return GENERIC


@router.post("/verify")
def verify(body: TokenRequest, db: Session = Depends(get_db)):
    sub = db.scalar(select(m.Subscriber).where(m.Subscriber.verify_token_hash == sha256_hex(body.token)))
    if not sub or not sub.verify_sent_at or m.utcnow() - sub.verify_sent_at > VERIFY_TTL:
        raise ApiError(400, "invalid_token", "This verification link is invalid or has expired.")
    sub.status, sub.verified_at, sub.verify_token_hash = "verified", m.utcnow(), None
    db.commit()
    return {"status": "verified"}


@router.post("/unsubscribe")
def unsubscribe(body: TokenRequest, request: Request, db: Session = Depends(get_db)):
    sid, _, sig = body.token.partition(".")
    sub = db.get(m.Subscriber, int(sid)) if sid.isdigit() else None
    expected = unsubscribe_token(request.app.state.settings.secret_key, sub) if sub else ""
    if not sub or not hmac.compare_digest(body.token, expected):
        raise ApiError(400, "invalid_token", "This unsubscribe link is invalid.")
    sub.status, sub.unsubscribed_at, sub.verify_token_hash = "unsubscribed", m.utcnow(), None
    db.commit()
    return {"status": "unsubscribed"}


@router.get("")
def list_subscribers(db: Session = Depends(get_db), _: m.AuthSession = Depends(require_admin), page: int = Query(1, ge=1),
                     per_page: int = Query(50, ge=1, le=200), status: str | None = Query(None, pattern="^(pending|verified|unsubscribed)$")):
    stmt = select(m.Subscriber).order_by(m.Subscriber.id.desc())
    if status:
        stmt = stmt.where(m.Subscriber.status == status)
    total = db.scalar(select(func.count()).select_from(stmt.order_by(None).subquery())) or 0
    rows = db.scalars(stmt.limit(per_page).offset((page - 1) * per_page))
    counts = dict(db.execute(select(m.Subscriber.status, func.count()).group_by(m.Subscriber.status)).all())
    return {"items": [{"id": s.id, "email": s.email, "status": s.status, "created_at": s.created_at, "verified_at": s.verified_at} for s in rows],
            "page": page, "per_page": per_page, "total": total, "counts": counts}
