from email_validator import EmailNotValidError, validate_email
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import AuthSession
from ..schemas import SiteSettings, SiteSettingsPatch
from ..security import client_ip, require_admin
from ..services.bitcoin import validate_address
from ..services.content import audit, check_media, media_url
from ..services.site import default_artwork, load_site, save_site
from ..services.text import render_markdown

router = APIRouter(prefix="/settings", tags=["settings"])
PRIVATE = {"about_md", "author_bio_md"}


@router.get("/public")
def public_settings(request: Request, db: Session = Depends(get_db)):
    site, state = load_site(db), request.app.state
    data = site.model_dump(exclude=PRIVATE)
    art = default_artwork(db, site)
    data.update(
        about_html=render_markdown(site.about_md), author_bio_html=render_markdown(site.author_bio_md),
        default_artwork_url=media_url(art),
        donations={"onchain_address": site.donation_address or None, "lightning_available": state.provider is not None,
                   "suggested_amounts_sats": site.suggested_amounts_sats, "message": site.donation_message,
                   "network": state.settings.bitcoin_network},
        email_signup_available=state.email.configured,
        feeds={"podcast": "/feed/podcast.xml", "blog": "/feed/blog.xml", "all": "/feed/all.xml"},
    )
    return data


@router.get("", response_model=SiteSettings)
def admin_settings(db: Session = Depends(get_db), _: AuthSession = Depends(require_admin)):
    return load_site(db)


@router.patch("", response_model=SiteSettings)
def update_settings(body: SiteSettingsPatch, request: Request, db: Session = Depends(get_db), sess: AuthSession = Depends(require_admin)):
    changes = body.model_dump(exclude_unset=True)
    for key, value in list(changes.items()):
        if value is None and key != "default_artwork_id":
            raise ApiError(422, "validation_error", f"{key} cannot be null.")
    if changes.get("donation_address"):
        net = request.app.state.settings.bitcoin_network
        changes["donation_address"] = changes["donation_address"].strip()
        if not validate_address(changes["donation_address"], net):
            raise ApiError(422, "invalid_bitcoin_address", f"That is not a valid {net} Bitcoin address (checksum failed).")
    for key in ("contact_email", "podcast_owner_email"):
        if changes.get(key):
            try:
                changes[key] = validate_email(changes[key], check_deliverability=False).normalized
            except EmailNotValidError as exc:
                raise ApiError(422, "invalid_email", f"{key}: {exc}") from exc
    if "default_artwork_id" in changes:
        check_media(db, changes["default_artwork_id"], "image")
    save_site(db, changes)
    audit(db, "settings.update", user_id=sess.user_id, detail={"keys": sorted(changes)}, ip=client_ip(request))
    db.commit()
    return load_site(db)
