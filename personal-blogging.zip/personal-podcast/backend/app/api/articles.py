from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import schemas as s
from ..database import get_db
from ..errors import ApiError
from ..models import AuthSession, ContentRevision
from ..security import client_ip, require_admin
from ..services import content
from ..services.content import article_dict
from ..services.text import render_markdown
from .content_routes import make_router

router = make_router("article", "articles", s.ArticleCreate, s.ArticleUpdate, article_dict,
                     s.ArticleCard, s.ArticlePublic, s.ArticleAdminCard, s.ArticleAdmin)


@router.post("/articles/preview")
def preview(body: s.MarkdownPreview, _: AuthSession = Depends(require_admin)):
    """Server-side render so the editor preview shows exactly what the sanitiser will publish."""
    return {"html": render_markdown(body.markdown)}


@router.post("/admin/articles/{ident}/revisions/{revision_id}/restore", response_model=s.ArticleAdmin)
def restore_revision(ident: int, revision_id: int, request: Request, db: Session = Depends(get_db),
                     sess: AuthSession = Depends(require_admin)):
    art = content.get_or_404(db, "article", ident)
    rev = db.scalar(select(ContentRevision).where(ContentRevision.id == revision_id, ContentRevision.content_type == "article",
                                                  ContentRevision.content_id == ident))
    if not rev:
        raise ApiError(404, "not_found", "Revision not found.")
    snap = {k: v for k, v in rev.snapshot.items() if k not in ("slug", "cover_id")}  # permalinks and media are not rolled back
    snap["version"] = art.version
    content.update_fields(db, art, snap, sess.user_id)
    content.audit(db, "article.restore_revision", user_id=sess.user_id, target=str(art.id), detail={"revision": rev.id}, ip=client_ip(request))
    db.commit()
    d = article_dict(art)
    d["related_articles"] = []
    return d
