from datetime import timedelta

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from ..database import get_db
from ..errors import ApiError
from ..models import AuthSession, User, utcnow
from ..schemas import LoginRequest, PasswordChange
from ..security import (COOKIE, DUMMY_HASH, client_ip, hash_password, lookup_session, new_token, require_admin, sha256_hex,
                        verify_password)
from ..services.content import audit

router = APIRouter(prefix="/auth", tags=["auth"])


def _session_payload(user: User, sess: AuthSession) -> dict:
    return {"authenticated": True, "email": user.email, "csrf_token": sess.csrf_token, "expires_at": sess.expires_at}


@router.post("/login")
def login(body: LoginRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    limiters, ip = request.app.state.limiters, client_ip(request)
    email = body.email.strip().lower()
    limiters["login_ip"].check(ip)
    limiters["login_email"].check(email)
    user = db.scalar(select(User).where(User.email == email))
    ok = verify_password(user.password_hash if user else DUMMY_HASH, body.password)  # same work either way
    if not (user and ok):
        audit(db, "auth.login_failed", target=email[:120], ip=ip)
        db.commit()
        raise ApiError(401, "invalid_credentials", "Email or password is incorrect.")
    settings = request.app.state.settings
    token = new_token()
    sess = AuthSession(token_hash=sha256_hex(token), csrf_token=new_token(), user_id=user.id, ip=ip,
                       expires_at=utcnow() + timedelta(hours=settings.session_ttl_hours))
    db.add(sess)
    user.last_login_at = utcnow()
    audit(db, "auth.login", user_id=user.id, ip=ip)
    db.commit()
    response.set_cookie(COOKIE, token, max_age=settings.session_ttl_hours * 3600, httponly=True,
                        secure=settings.cookie_secure, samesite="lax", path="/")
    response.headers["Cache-Control"] = "no-store"
    return _session_payload(user, sess)


@router.get("/session")
def session(request: Request, response: Response, db: Session = Depends(get_db)):
    response.headers["Cache-Control"] = "no-store"
    sess = lookup_session(request, db)
    if not sess:
        return {"authenticated": False}
    return _session_payload(db.get(User, sess.user_id), sess)


@router.post("/logout", status_code=204)
def logout(request: Request, response: Response, sess: AuthSession = Depends(require_admin), db: Session = Depends(get_db)):
    audit(db, "auth.logout", user_id=sess.user_id, ip=client_ip(request))
    db.delete(sess)
    db.commit()
    response.delete_cookie(COOKIE, path="/")
    response.status_code = 204
    return response


@router.post("/password/change", status_code=204)
def change_password(body: PasswordChange, request: Request, sess: AuthSession = Depends(require_admin), db: Session = Depends(get_db)):
    request.app.state.limiters["login_ip"].check(client_ip(request))
    user = db.get(User, sess.user_id)
    if not verify_password(user.password_hash, body.current_password):
        raise ApiError(403, "invalid_credentials", "The current password is incorrect.")
    user.password_hash = hash_password(body.new_password)
    db.execute(delete(AuthSession).where(AuthSession.user_id == user.id, AuthSession.id != sess.id))  # sign out everywhere else
    audit(db, "auth.password_changed", user_id=user.id, ip=client_ip(request))
    db.commit()
    return Response(status_code=204)
