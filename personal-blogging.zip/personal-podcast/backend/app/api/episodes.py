from .. import schemas as s
from ..services.content import episode_dict
from .content_routes import make_router

router = make_router("episode", "episodes", s.EpisodeCreate, s.EpisodeUpdate, episode_dict,
                     s.EpisodeCard, s.EpisodePublic, s.EpisodeAdminCard, s.EpisodeAdmin)
