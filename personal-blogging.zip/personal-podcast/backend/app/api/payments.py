import io
import logging
import re
import uuid
from datetime import timedelta
from urllib.parse import quote

import qrcode
import qrcode.image.svg
from fastapi import APIRouter, Depends, Query, Request, Response
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from .. import models as m
from ..database import get_db
from ..errors import ApiError
from ..schemas import InvoiceRequest
from ..security import client_ip, require_admin
from ..services.bitcoin import bip21
from ..services.lightning import ProviderError, WebhookAuthError
from ..services.site import load_site

log = logging.getLogger("pp.payments")
router = APIRouter(prefix="/payments", tags=["payments"])
ALLOWED = {"pending": {"paid", "expired", "cancelled"}, "expired": {"paid"}, "paid": set(), "cancelled": set()}


def qr_url(data: str) -> str:
    return "/api/v1/payments/qr?data=" + quote(data, safe="")


def invoice_dict(inv: m.PaymentInvoice) -> dict:
    return {"id": inv.public_id, "kind": "lightning", "status": inv.status, "amount_sats": inv.amount_sats, "bolt11": inv.bolt11,
            "expires_at": inv.expires_at, "paid_at": inv.paid_at, "qr_url": qr_url("lightning:" + inv.bolt11)}


def transition(inv: m.PaymentInvoice, new: str) -> bool:
    if new not in ALLOWED[inv.status]:
        return False
    inv.status = new
    if new == "paid":
        inv.paid_at = m.utcnow()
    return True


@router.post("/invoices")
def create_invoice(body: InvoiceRequest, request: Request, db: Session = Depends(get_db)):
    request.app.state.limiters["invoice"].check(client_ip(request))
    settings, site = request.app.state.settings, load_site(db)
    if body.amount_sats and body.amount_sats > settings.max_invoice_sats:
        raise ApiError(422, "amount_too_large", f"The maximum amount is {settings.max_invoice_sats} satoshis.")
    if body.kind == "onchain":
        if not site.donation_address:
            raise ApiError(503, "onchain_unavailable", "No Bitcoin address has been configured.")
        uri = bip21(site.donation_address, body.amount_sats)
        # No database record: on-chain gifts are not tracked here, so nothing about the donor is stored.
        return {"kind": "onchain", "address": site.donation_address, "amount_sats": body.amount_sats, "bip21": uri,
                "tracking": "none", "qr_url": qr_url(uri)}
    provider = request.app.state.provider
    if not provider:
        raise ApiError(503, "lightning_unavailable", "Lightning payments are not configured on this site.")
    if not body.amount_sats:
        raise ApiError(422, "amount_required", "Choose an amount in satoshis.")
    try:
        pi = provider.create_invoice(body.amount_sats, f"Support {site.site_title}"[:100], settings.invoice_expiry_seconds,
                                     f"{settings.site_url}/api/v1/payments/webhooks/{provider.name}")
    except ProviderError as exc:
        log.error("provider invoice creation failed", extra={"provider": provider.name})
        raise ApiError(502, "provider_error", "The Lightning provider is not responding. Try again shortly.") from exc
    inv = m.PaymentInvoice(public_id=uuid.uuid4().hex, provider=provider.name, amount_sats=body.amount_sats, memo="",
                           supporter_name=body.supporter_name, message=body.message, status="pending",
                           provider_ref=pi.provider_ref, bolt11=pi.bolt11, expires_at=pi.expires_at)
    db.add(inv)
    db.flush()
    db.add(m.PaymentEvent(provider=provider.name, event_id=f"created:{inv.public_id}", invoice_id=inv.id, outcome="invoice_created"))
    db.commit()
    return invoice_dict(inv)


@router.get("/qr")
def qr(data: str = Query(min_length=8, max_length=2000)):
    if not re.fullmatch(r"(bitcoin:|lightning:)[\x21-\x7e]+", data):
        raise ApiError(422, "invalid_qr_data", "Only bitcoin: and lightning: payment URIs can be encoded.")
    buf = io.BytesIO()
    qrcode.make(data, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2).save(buf)
    return Response(buf.getvalue(), media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=3600", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'"})


@router.get("")
def list_invoices(db: Session = Depends(get_db), _: m.AuthSession = Depends(require_admin), limit: int = Query(25, ge=1, le=100)):
    rows = db.scalars(select(m.PaymentInvoice).order_by(m.PaymentInvoice.id.desc()).limit(limit))
    return [{**invoice_dict(i), "supporter_name": i.supporter_name, "message": i.message, "provider": i.provider, "created_at": i.created_at}
            for i in rows]


def _record(db, inv, provider, event_id, outcome):
    db.add(m.PaymentEvent(provider=provider, event_id=event_id, invoice_id=inv.id if inv else None, outcome=outcome))


@router.get("/{public_id}")
def get_invoice(public_id: str, request: Request, db: Session = Depends(get_db)):
    inv = db.scalar(select(m.PaymentInvoice).where(m.PaymentInvoice.public_id == public_id))
    if not inv:
        raise ApiError(404, "not_found", "Invoice not found.")
    provider = request.app.state.provider
    if inv.status in ("pending", "expired") and provider and provider.name == inv.provider:
        request.app.state.limiters["invoice_poll"].check(client_ip(request))
        try:
            if provider.get_status(inv.provider_ref) == "paid":
                outcome = "paid_after_expiry" if inv.status == "expired" else "paid"
                if transition(inv, "paid"):
                    _record(db, inv, inv.provider, f"poll:{inv.provider_ref}", outcome)
        except ProviderError:
            log.warning("status check failed", extra={"invoice": inv.public_id})
    if inv.status == "pending" and inv.expires_at <= m.utcnow():
        transition(inv, "expired")
    db.commit()
    return invoice_dict(inv)


@router.post("/webhooks/{provider_name}")
async def webhook(provider_name: str, request: Request, db: Session = Depends(get_db)):
    provider = request.app.state.provider
    if not provider or provider.name != provider_name:
        raise ApiError(404, "not_found", "Unknown payment provider.")
    body = await request.body()
    if len(body) > 65_536:
        raise ApiError(413, "payload_too_large", "Webhook body too large.")
    try:
        ev = provider.parse_webhook({k.lower(): v for k, v in request.headers.items()}, dict(request.query_params), body)
    except WebhookAuthError as exc:
        log.warning("webhook rejected", extra={"provider": provider_name, "reason": str(exc), "ip": client_ip(request)})
        raise ApiError(401, "invalid_webhook", "Webhook authentication failed.") from exc
    inv = db.scalar(select(m.PaymentInvoice).where(m.PaymentInvoice.provider == provider_name, m.PaymentInvoice.provider_ref == ev.provider_ref))
    if not inv:
        _record(db, None, provider_name, f"{ev.event_id}:unknown:{uuid.uuid4().hex[:8]}", "unknown_invoice")
        db.commit()
        return {"status": "ignored"}
    try:  # The webhook only says "look at this payment"; the provider's own API is the evidence.
        settled = provider.get_status(ev.provider_ref) == "paid"
    except ProviderError as exc:
        raise ApiError(503, "verification_unavailable", "Could not verify the payment; retry later.") from exc
    if not settled:
        _record(db, inv, provider_name, f"{ev.event_id}:unsettled:{uuid.uuid4().hex[:8]}", "not_settled")
        db.commit()
        return {"status": "not_settled"}
    outcome = "already_paid" if inv.status == "paid" else ("paid_after_expiry" if inv.status == "expired" else "paid")
    transition(inv, "paid")
    _record(db, inv, provider_name, ev.event_id, outcome)  # unique (provider, event_id) makes redelivery idempotent
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        return {"status": "duplicate"}
    return {"status": outcome}
