from datetime import timezone
from email.utils import format_datetime

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session

from ..database import get_db
from ..services.rss_generator import build_feed, etag_for
from ..services.site import load_site

router = APIRouter(prefix="/feed", tags=["feeds"])


def _serve(request: Request, db: Session, kind: str) -> Response:
    body, last_mod = build_feed(db, request.app.state.settings, request.app.state.storage, load_site(db), kind)
    etag = etag_for(body)
    headers = {"ETag": etag, "Cache-Control": "public, max-age=300"}
    if last_mod:
        headers["Last-Modified"] = format_datetime(last_mod.astimezone(timezone.utc), usegmt=True)
    if request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers=headers)
    return Response(body, media_type="application/rss+xml; charset=utf-8", headers=headers)


@router.get("/podcast.xml")
def podcast(request: Request, db: Session = Depends(get_db)):
    return _serve(request, db, "podcast")


@router.get("/blog.xml")
def blog(request: Request, db: Session = Depends(get_db)):
    return _serve(request, db, "blog")


@router.get("/all.xml")
def everything(request: Request, db: Session = Depends(get_db)):
    return _serve(request, db, "all")
