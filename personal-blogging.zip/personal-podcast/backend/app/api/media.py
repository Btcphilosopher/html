import hashlib
import logging
import os
import re
import uuid
from datetime import timezone
from email.utils import format_datetime
from typing import Literal

from fastapi import APIRouter, Depends, File, Form, Query, Request, Response, UploadFile
from fastapi.responses import StreamingResponse
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from .. import models as m
from ..database import get_db
from ..errors import ApiError
from ..schemas import MediaOut, Page
from ..security import client_ip, lookup_session, require_admin
from ..services import audio
from ..services.content import audit, live_clause, media_filename, media_url, paginate
from ..services.site import load_site

log = logging.getLogger("pp.media")
router = APIRouter(tags=["media"])          # /api/v1/media (admin)
public_router = APIRouter(tags=["media-delivery"])  # /media/... (public, byte-range streaming)


# ---- admin: upload / list / delete -----------------------------------------------------------------
def _clean_name(name: str | None) -> str:
    base = os.path.basename((name or "upload").replace("\\", "/"))
    return re.sub(r"[\x00-\x1f\x7f]", "", base)[:200] or "upload"


def ingest(request: Request, db: Session, upload: UploadFile, kind: str, user_id: int) -> m.MediaAsset:
    settings, storage = request.app.state.settings, request.app.state.storage
    max_bytes = (settings.max_audio_mb if kind == "audio" else settings.max_image_mb) * 1024 * 1024
    head = upload.file.read(4096)
    upload.file.seek(0)
    if kind == "audio":
        if not audio.sniff_mp3(head):
            raise ApiError(415, "not_mp3", "This file is not an MP3. The file contents are inspected, so renaming a file does not help.")
        mime, ext = "audio/mpeg", "mp3"
    else:
        sniffed = audio.sniff_image(head)
        if not sniffed:
            raise ApiError(415, "not_image", "Only PNG, JPEG and WebP images are accepted.")
        mime, ext = sniffed
    tmp, digest, size = storage.new_tmp(), hashlib.sha256(), 0
    saved_key = None
    try:
        with open(tmp, "wb") as out:
            while chunk := upload.file.read(1024 * 1024):
                size += len(chunk)
                if size > max_bytes:
                    raise ApiError(413, "file_too_large", f"The file exceeds the {max_bytes // (1024 * 1024)} MB limit.")
                digest.update(chunk)
                out.write(chunk)
        if size == 0:
            raise ApiError(422, "empty_file", "The file is empty.")
        used = db.scalar(select(func.coalesce(func.sum(m.MediaAsset.size_bytes), 0))) or 0
        if used + size > settings.storage_quota_mb * 1024 * 1024:
            raise ApiError(413, "quota_exceeded", "The media storage quota would be exceeded.")
        duration, meta = None, {}
        if kind == "audio":
            if audio.ffprobe_available():
                try:
                    info = audio.probe_mp3(tmp)
                except audio.ProbeError as exc:
                    raise ApiError(422, "invalid_audio", str(exc)) from exc
                duration, meta = info["duration"], {"bit_rate": info["bit_rate"]}
            elif settings.require_ffprobe:
                raise ApiError(503, "ffprobe_missing", "Audio inspection is unavailable on this server.")
            else:
                meta = {"probe": "unavailable"}
        pid = uuid.uuid4().hex
        saved_key = f"{kind}/{pid[:2]}/{pid}.{ext}"
        storage.save(tmp, saved_key)
        asset = m.MediaAsset(public_id=pid, storage_key=saved_key, original_filename=_clean_name(upload.filename), mime=mime,
                             size_bytes=size, sha256=digest.hexdigest(), kind=kind, duration_seconds=duration, status="ready",
                             meta=meta, uploader_id=user_id)
        db.add(asset)
        audit(db, "media.upload", user_id=user_id, target=pid, detail={"kind": kind, "bytes": size}, ip=client_ip(request))
        db.commit()
        return asset
    except BaseException:
        tmp.unlink(missing_ok=True)
        if saved_key:
            storage.delete(saved_key)
        db.rollback()
        raise


def usage_map(db: Session, ids: list[int]) -> dict[int, list[dict]]:
    out: dict[int, list[dict]] = {i: [] for i in ids}
    if not ids:
        return out
    for e in db.scalars(select(m.Episode).where(m.Episode.deleted_at.is_(None), or_(m.Episode.audio_id.in_(ids), m.Episode.artwork_id.in_(ids)))).unique():
        for i in (e.audio_id, e.artwork_id):
            if i in out:
                out[i].append({"type": "episode", "id": e.id, "title": e.title})
    for a in db.scalars(select(m.Article).where(m.Article.deleted_at.is_(None), m.Article.cover_id.in_(ids))).unique():
        out[a.cover_id].append({"type": "article", "id": a.id, "title": a.title})
    return out


def media_dict(a: m.MediaAsset, used_by: list[dict] | None = None) -> dict:
    return dict(id=a.id, public_id=a.public_id, url=media_url(a) or "", original_filename=a.original_filename, mime=a.mime,
                size_bytes=a.size_bytes, kind=a.kind, duration_seconds=a.duration_seconds, status=a.status,
                storage_key=a.storage_key, meta=a.meta or {}, created_at=a.created_at, used_by=used_by or [])


@router.post("/media/upload", response_model=MediaOut, status_code=201)
def upload(request: Request, file: UploadFile = File(...), kind: Literal["audio", "image"] = Form("audio"),
           db: Session = Depends(get_db), sess: m.AuthSession = Depends(require_admin)):
    asset = ingest(request, db, file, kind, sess.user_id)
    return media_dict(asset)


@router.get("/media", response_model=Page[MediaOut])
def list_media(db: Session = Depends(get_db), _: m.AuthSession = Depends(require_admin), page: int = Query(1, ge=1),
               per_page: int = Query(25, ge=1, le=100), kind: Literal["audio", "image"] | None = None):
    stmt = select(m.MediaAsset).order_by(m.MediaAsset.created_at.desc(), m.MediaAsset.id.desc())
    if kind:
        stmt = stmt.where(m.MediaAsset.kind == kind)
    rows, total, pages = paginate(db, stmt, page, per_page)
    usage = usage_map(db, [r.id for r in rows])
    return {"items": [media_dict(r, usage[r.id]) for r in rows], "page": page, "per_page": per_page, "total": total, "pages": pages}


@router.get("/media/{ident}", response_model=MediaOut)
def get_media(ident: int, db: Session = Depends(get_db), _: m.AuthSession = Depends(require_admin)):
    a = db.get(m.MediaAsset, ident)
    if not a:
        raise ApiError(404, "not_found", "Media not found.")
    return media_dict(a, usage_map(db, [a.id])[a.id])


@router.delete("/media/{ident}", status_code=204)
def delete_media(ident: int, request: Request, db: Session = Depends(get_db), sess: m.AuthSession = Depends(require_admin)):
    a = db.get(m.MediaAsset, ident)
    if not a:
        raise ApiError(404, "not_found", "Media not found.")
    in_use = usage_map(db, [a.id])[a.id]
    if in_use or load_site(db).default_artwork_id == a.id:
        raise ApiError(409, "media_in_use", "This file is still used by content or settings. Detach it first.", {"used_by": in_use})
    key = a.storage_key
    db.delete(a)
    audit(db, "media.delete", user_id=sess.user_id, target=a.public_id, ip=client_ip(request))
    db.commit()
    request.app.state.storage.delete(key)
    return Response(status_code=204)


# ---- public delivery with HTTP Range support -------------------------------------------------------
class RangeNotSatisfiable(Exception):
    pass


def parse_range(header: str | None, size: int) -> tuple[int, int] | None:
    """Single byte-range per RFC 9110. Returns None for 'serve everything' (absent, malformed or multi-range)."""
    if not header or not header.lower().startswith("bytes=") or "," in header:
        return None
    start_s, sep, end_s = header[6:].strip().partition("-")
    if not sep:
        return None
    try:
        if start_s == "":
            n = int(end_s)
            if n <= 0:
                raise RangeNotSatisfiable
            return max(size - n, 0), size - 1
        start = int(start_s)
        end = int(end_s) if end_s else size - 1
    except ValueError:
        return None
    if start < 0 or start >= size or end < start:
        raise RangeNotSatisfiable
    return start, min(end, size - 1)


def media_is_public(db: Session, a: m.MediaAsset) -> bool:
    """Media is world-readable only when a live episode/article/setting uses it. Draft audio stays private."""
    pid = a.public_id
    if db.scalar(select(m.Episode.id).where(live_clause(m.Episode), or_(
            m.Episode.audio_id == a.id, m.Episode.artwork_id == a.id, m.Episode.show_notes_md.contains(pid, autoescape=True))).limit(1)):
        return True
    if db.scalar(select(m.Article.id).where(live_clause(m.Article), or_(
            m.Article.cover_id == a.id, m.Article.body_md.contains(pid, autoescape=True))).limit(1)):
        return True
    return load_site(db).default_artwork_id == a.id


@public_router.api_route("/media/{public_id}/{filename}", methods=["GET", "HEAD"], include_in_schema=False)
@public_router.api_route("/media/{public_id}", methods=["GET", "HEAD"], include_in_schema=False)
def deliver(request: Request, public_id: str, filename: str | None = None, download: bool = False, db: Session = Depends(get_db)):
    asset = db.scalar(select(m.MediaAsset).where(m.MediaAsset.public_id == public_id)) if re.fullmatch(r"[0-9a-f]{32}", public_id) else None
    if not asset or asset.status != "ready":
        raise ApiError(404, "not_found", "Not found.")
    public = media_is_public(db, asset)
    if not public and not lookup_session(request, db):
        raise ApiError(404, "not_found", "Not found.")  # same answer as a missing file: no existence oracle for drafts
    storage = request.app.state.storage
    try:
        size = storage.size(asset.storage_key)
    except (FileNotFoundError, ValueError):
        log.error("media file missing from storage", extra={"media_id": asset.id})
        raise ApiError(404, "not_found", "Not found.")
    etag = f'"{asset.sha256[:32]}"'
    disposition = "attachment" if download else "inline"
    headers = {
        "Accept-Ranges": "bytes", "ETag": etag, "Last-Modified": format_datetime(asset.created_at.astimezone(timezone.utc), usegmt=True),
        "Cache-Control": "public, max-age=86400" if public else "private, no-store",
        "Content-Disposition": f'{disposition}; filename="{media_filename(asset)}"',
    }
    rng = request.headers.get("range")
    if_range = request.headers.get("if-range")
    if rng and if_range and if_range != etag:
        rng = None
    if not rng and request.headers.get("if-none-match") == etag:
        return Response(status_code=304, headers={k: v for k, v in headers.items() if k in ("ETag", "Cache-Control", "Last-Modified")})
    try:
        span = parse_range(rng, size)
    except RangeNotSatisfiable:
        return Response(status_code=416, headers={"Content-Range": f"bytes */{size}", "Accept-Ranges": "bytes"})
    if span:
        start, end = span
        status = 206
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    else:
        start, end, status = 0, size - 1, 200
    headers["Content-Length"] = str(end - start + 1)
    if request.method == "HEAD":
        return Response(status_code=status, headers=headers, media_type=asset.mime)
    return StreamingResponse(storage.read_range(asset.storage_key, start, end), status_code=status, headers=headers, media_type=asset.mime)
