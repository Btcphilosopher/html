from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from .. import models as m
from ..database import get_db
from ..security import require_admin
from ..services.audio import ffprobe_available
from ..services.content import live_clause
from ..services.rss_generator import feed_warnings
from ..services.site import load_site
from .media import media_dict

router = APIRouter(tags=["admin"])


def _counts(db: Session, model) -> dict:
    rows = dict(db.execute(select(model.status, func.count()).where(model.deleted_at.is_(None)).group_by(model.status)).all())
    live = db.scalar(select(func.count()).select_from(model).where(live_clause(model))) or 0
    return {"live": live, "draft": rows.get("draft", 0), "scheduled": rows.get("scheduled", 0), "total": sum(rows.values())}


@router.get("/admin/dashboard")
def dashboard(request: Request, db: Session = Depends(get_db), _: m.AuthSession = Depends(require_admin)):
    state, settings = request.app.state, request.app.state.settings
    used = db.scalar(select(func.coalesce(func.sum(m.MediaAsset.size_bytes), 0))) or 0
    uploads = db.scalars(select(m.MediaAsset).order_by(m.MediaAsset.id.desc()).limit(5)).all()
    paid = db.execute(select(func.count(), func.coalesce(func.sum(m.PaymentInvoice.amount_sats), 0)).where(m.PaymentInvoice.status == "paid")).one()
    recent_pay = db.scalars(select(m.PaymentInvoice).order_by(m.PaymentInvoice.id.desc()).limit(5)).all()
    subs = dict(db.execute(select(m.Subscriber.status, func.count()).group_by(m.Subscriber.status)).all())
    activity = db.scalars(select(m.AuditLog).where(m.AuditLog.action.not_in(("auth.login_failed",))).order_by(m.AuditLog.id.desc()).limit(10)).all()
    task = getattr(state, "scheduler_task", None)
    return {
        "episodes": _counts(db, m.Episode), "articles": _counts(db, m.Article),
        "recent_uploads": [media_dict(a) for a in uploads],
        "storage": {"used_bytes": used, "quota_bytes": settings.storage_quota_mb * 1024 * 1024,
                    "files": db.scalar(select(func.count()).select_from(m.MediaAsset)) or 0},
        "payments": {"paid_count": paid[0], "paid_total_sats": int(paid[1]),
                     "recent": [{"id": i.public_id, "status": i.status, "amount_sats": i.amount_sats, "created_at": i.created_at} for i in recent_pay]},
        "subscribers": {"verified": subs.get("verified", 0), "pending": subs.get("pending", 0), "unsubscribed": subs.get("unsubscribed", 0)},
        "activity": [{"action": a.action, "target": a.target, "created_at": a.created_at} for a in activity],
        "feed_warnings": feed_warnings(db, settings, load_site(db)),
        "health": {"database": True, "storage_writable": state.storage.writable(), "ffprobe": ffprobe_available(),
                   "lightning_provider": state.provider.name if state.provider else None, "email_configured": state.email.configured,
                   "scheduler_running": bool(task and not task.done())},
        "analytics": {"collected": False, "note": "Listener and download statistics are not collected by this installation."},
    }


@router.get("/health")
def health():
    return {"status": "ok"}


@router.get("/health/ready")
def ready(request: Request, response: Response, db: Session = Depends(get_db)):
    checks = {"database": False, "storage": request.app.state.storage.writable()}
    try:
        db.execute(text("select 1"))
        checks["database"] = True
    except Exception:
        pass
    if not all(checks.values()):
        response.status_code = 503
    return {"status": "ready" if all(checks.values()) else "unavailable", "checks": checks}
