"""Operations CLI:  python -m app.manage create-admin | seed-sample | publish-due | check-config"""
import argparse
import getpass
import subprocess
import sys
import tempfile
from pathlib import Path

from sqlalchemy import select

from . import models as m
from .config import Settings
from .database import make_engine, make_session_factory
from .security import hash_password
from .services import content
from .services.storage import LocalStorage


def _db(settings):
    engine = make_engine(settings.database_url)
    if settings.auto_create_tables:
        m.Base.metadata.create_all(engine)
    return make_session_factory(engine)()


def create_admin(args):
    settings, db = Settings(), None
    db = _db(settings)
    email = args.email.strip().lower()
    if db.scalar(select(m.User).where(m.User.email == email)):
        sys.exit("An administrator with that email already exists.")
    pw = getpass.getpass("Password (12+ characters): ")
    if len(pw) < 12 or pw != getpass.getpass("Repeat password: "):
        sys.exit("Passwords must match and be at least 12 characters.")
    db.add(m.User(email=email, password_hash=hash_password(pw)))
    db.commit()
    print(f"Administrator {email} created.")


def seed_sample(args):
    """Clearly labelled SAMPLE content for development. Generates a 5 second test tone with ffmpeg."""
    settings, db = Settings(), None
    if settings.env == "production":
        sys.exit("Refusing to seed sample content in production.")
    db = _db(settings)
    storage = LocalStorage(settings.media_dir)
    with tempfile.TemporaryDirectory() as d:
        mp3 = Path(d) / "sample-tone.mp3"
        subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=330:duration=5", "-c:a", "libmp3lame", str(mp3)], check=True)
        import hashlib
        import uuid
        pid = uuid.uuid4().hex
        key = f"audio/{pid[:2]}/{pid}.mp3"
        data = mp3.read_bytes()
        tmp = storage.new_tmp()
        tmp.write_bytes(data)
        storage.save(tmp, key)
    asset = m.MediaAsset(public_id=pid, storage_key=key, original_filename="sample-tone.mp3", mime="audio/mpeg", size_bytes=len(data),
                         sha256=hashlib.sha256(data).hexdigest(), kind="audio", duration_seconds=5.0, status="ready", meta={"sample": True})
    db.add(asset)
    db.flush()
    ep = content.create(db, "episode", {"title": "[Sample] A five second test tone", "summary": "Sample content for development. Not a real episode.",
                                        "show_notes_md": "This is **sample content** created by `manage.py seed-sample`.", "audio_id": asset.id,
                                        "tags": ["sample"]}, None)
    art = content.create(db, "article", {"title": "[Sample] Notes on starting a publication", "excerpt": "Sample article for development.",
                                         "body_md": "# Sample\n\nThis article was **generated as sample content**.", "tags": ["sample"]}, None)
    content.publish(db, ep, None)
    content.publish(db, art, None)
    db.commit()
    print("Sample episode and article published.")


def publish_due(args):
    print(content.publish_due(_db(Settings())))


def check_config(args):
    s = Settings()
    print("Configuration OK:", {"env": s.env, "site_url": s.site_url, "payment_provider": s.payment_provider, "database": s.database_url.split("@")[-1]})


def main():
    p = argparse.ArgumentParser(prog="manage")
    sub = p.add_subparsers(required=True)
    a = sub.add_parser("create-admin")
    a.add_argument("--email", required=True)
    a.set_defaults(fn=create_admin)
    sub.add_parser("seed-sample").set_defaults(fn=seed_sample)
    sub.add_parser("publish-due").set_defaults(fn=publish_due)
    sub.add_parser("check-config").set_defaults(fn=check_config)
    args = p.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
