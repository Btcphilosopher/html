"""SQLAlchemy models. Money is stored as integer satoshis; all timestamps are UTC."""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (JSON, BigInteger, Boolean, CheckConstraint, Column, DateTime, Float, ForeignKey, Index,
                        Integer, String, Table, Text, UniqueConstraint)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.types import TypeDecorator


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class UTCDateTime(TypeDecorator):
    """Timezone-aware UTC datetimes on every backend (SQLite drops tzinfo)."""

    impl = DateTime(timezone=True)
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    def process_result_value(self, value, dialect):
        if value is None:
            return None
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


class Base(DeclarativeBase):
    pass


def _fk(target: str, **kw):
    return ForeignKey(target, **kw)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    last_login_at: Mapped[datetime | None] = mapped_column(UTCDateTime)


class AuthSession(Base):
    __tablename__ = "sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    csrf_token: Mapped[str] = mapped_column(String(64))
    user_id: Mapped[int] = mapped_column(_fk("users.id", ondelete="CASCADE"), index=True)
    ip: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime)


class MediaAsset(Base):
    __tablename__ = "media_assets"
    __table_args__ = (CheckConstraint("kind in ('audio','image')", name="ck_media_kind"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[str] = mapped_column(String(32), unique=True)
    storage_key: Mapped[str] = mapped_column(String(200), unique=True)
    original_filename: Mapped[str] = mapped_column(String(255))
    mime: Mapped[str] = mapped_column(String(100))
    size_bytes: Mapped[int] = mapped_column(BigInteger)
    sha256: Mapped[str] = mapped_column(String(64))
    kind: Mapped[str] = mapped_column(String(10))
    duration_seconds: Mapped[float | None] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(20), default="ready")
    meta: Mapped[dict] = mapped_column(JSON, default=dict)
    uploader_id: Mapped[int | None] = mapped_column(_fk("users.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class Tag(Base):
    __tablename__ = "tags"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(40))
    slug: Mapped[str] = mapped_column(String(60), unique=True)


class Category(Base):
    __tablename__ = "categories"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(40))
    slug: Mapped[str] = mapped_column(String(60), unique=True)


def _link_table(name: str, owner: str, other: str) -> Table:
    return Table(
        name, Base.metadata,
        Column(f"{owner}_id", Integer, ForeignKey(f"{owner}s.id", ondelete="CASCADE"), primary_key=True),
        Column(f"{other}_id", Integer, ForeignKey(f"{'categories' if other == 'category' else other + 's'}.id", ondelete="CASCADE"), primary_key=True),
    )


episode_tags = _link_table("episode_tags", "episode", "tag")
article_tags = _link_table("article_tags", "article", "tag")
episode_categories = _link_table("episode_categories", "episode", "category")
article_categories = _link_table("article_categories", "article", "category")

CONTENT_STATUS = "status in ('draft','scheduled','published')"


class Episode(Base):
    __tablename__ = "episodes"
    __table_args__ = (CheckConstraint(CONTENT_STATUS, name="ck_episode_status"), Index("ix_episodes_public", "status", "publish_at"))
    id: Mapped[int] = mapped_column(primary_key=True)
    guid: Mapped[str] = mapped_column(String(36), unique=True)
    slug: Mapped[str] = mapped_column(String(100), unique=True)
    title: Mapped[str] = mapped_column(String(200))
    summary: Mapped[str] = mapped_column(Text, default="")
    show_notes_md: Mapped[str] = mapped_column(Text, default="")
    show_notes_html: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(12), default="draft")
    publish_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    season: Mapped[int | None] = mapped_column(Integer)
    episode_number: Mapped[int | None] = mapped_column(Integer)
    episode_type: Mapped[str] = mapped_column(String(10), default="full")
    explicit: Mapped[bool] = mapped_column(Boolean, default=False)
    audio_id: Mapped[int | None] = mapped_column(_fk("media_assets.id", ondelete="SET NULL"))
    artwork_id: Mapped[int | None] = mapped_column(_fk("media_assets.id", ondelete="SET NULL"))
    chapters: Mapped[list] = mapped_column(JSON, default=list)
    links: Mapped[list] = mapped_column(JSON, default=list)
    transcript: Mapped[str | None] = mapped_column(Text)
    version: Mapped[int] = mapped_column(Integer, default=1)
    deleted_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)
    audio: Mapped[MediaAsset | None] = relationship(foreign_keys=[audio_id], lazy="joined")
    artwork: Mapped[MediaAsset | None] = relationship(foreign_keys=[artwork_id], lazy="joined")
    tags: Mapped[list[Tag]] = relationship(secondary=episode_tags, lazy="selectin", order_by=Tag.name)
    categories: Mapped[list[Category]] = relationship(secondary=episode_categories, lazy="selectin", order_by=Category.name)


class Article(Base):
    __tablename__ = "articles"
    __table_args__ = (CheckConstraint(CONTENT_STATUS, name="ck_article_status"), Index("ix_articles_public", "status", "publish_at"))
    id: Mapped[int] = mapped_column(primary_key=True)
    guid: Mapped[str] = mapped_column(String(36), unique=True)
    slug: Mapped[str] = mapped_column(String(100), unique=True)
    title: Mapped[str] = mapped_column(String(200))
    excerpt: Mapped[str] = mapped_column(Text, default="")
    body_md: Mapped[str] = mapped_column(Text, default="")
    body_html: Mapped[str] = mapped_column(Text, default="")
    cover_id: Mapped[int | None] = mapped_column(_fk("media_assets.id", ondelete="SET NULL"))
    status: Mapped[str] = mapped_column(String(12), default="draft")
    publish_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    seo_title: Mapped[str] = mapped_column(String(200), default="")
    seo_description: Mapped[str] = mapped_column(String(400), default="")
    version: Mapped[int] = mapped_column(Integer, default=1)
    deleted_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)
    cover: Mapped[MediaAsset | None] = relationship(foreign_keys=[cover_id], lazy="joined")
    tags: Mapped[list[Tag]] = relationship(secondary=article_tags, lazy="selectin", order_by=Tag.name)
    categories: Mapped[list[Category]] = relationship(secondary=article_categories, lazy="selectin", order_by=Category.name)


class PaymentInvoice(Base):
    __tablename__ = "payment_invoices"
    __table_args__ = (
        CheckConstraint("status in ('pending','paid','expired','cancelled')", name="ck_invoice_status"),
        CheckConstraint("amount_sats > 0", name="ck_invoice_amount"),
        UniqueConstraint("provider", "provider_ref", name="uq_invoice_provider_ref"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[str] = mapped_column(String(32), unique=True)
    provider: Mapped[str] = mapped_column(String(20))
    amount_sats: Mapped[int] = mapped_column(BigInteger)
    memo: Mapped[str] = mapped_column(String(200), default="")
    supporter_name: Mapped[str] = mapped_column(String(80), default="")
    message: Mapped[str] = mapped_column(String(500), default="")
    status: Mapped[str] = mapped_column(String(12), default="pending")
    provider_ref: Mapped[str] = mapped_column(String(128))
    bolt11: Mapped[str] = mapped_column(Text)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime)
    paid_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, onupdate=utcnow)


class PaymentEvent(Base):
    __tablename__ = "payment_events"
    __table_args__ = (UniqueConstraint("provider", "event_id", name="uq_payment_event"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    provider: Mapped[str] = mapped_column(String(20))
    event_id: Mapped[str] = mapped_column(String(128))
    invoice_id: Mapped[int | None] = mapped_column(_fk("payment_invoices.id", ondelete="SET NULL"))
    outcome: Mapped[str] = mapped_column(String(40))
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class Subscriber(Base):
    __tablename__ = "subscribers"
    __table_args__ = (CheckConstraint("status in ('pending','verified','unsubscribed')", name="ck_subscriber_status"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)
    status: Mapped[str] = mapped_column(String(12), default="pending")
    verify_token_hash: Mapped[str | None] = mapped_column(String(64), index=True)
    verify_sent_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    verified_at: Mapped[datetime | None] = mapped_column(UTCDateTime)
    unsubscribed_at: Mapped[datetime | None] = mapped_column(UTCDateTime)


class SiteSetting(Base):
    __tablename__ = "site_settings"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[object] = mapped_column(JSON)


class ContentRevision(Base):
    __tablename__ = "content_revisions"
    __table_args__ = (Index("ix_revisions_content", "content_type", "content_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    content_type: Mapped[str] = mapped_column(String(12))
    content_id: Mapped[int] = mapped_column(Integer)
    version: Mapped[int] = mapped_column(Integer)
    snapshot: Mapped[dict] = mapped_column(JSON)
    author_id: Mapped[int | None] = mapped_column(_fk("users.id", ondelete="SET NULL"))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int | None] = mapped_column(_fk("users.id", ondelete="SET NULL"))
    action: Mapped[str] = mapped_column(String(60), index=True)
    target: Mapped[str] = mapped_column(String(120), default="")
    detail: Mapped[dict] = mapped_column(JSON, default=dict)
    ip: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow, index=True)
