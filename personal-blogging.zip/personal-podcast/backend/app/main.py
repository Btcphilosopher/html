import asyncio
import json
import logging
import shutil
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import select
from starlette.exceptions import HTTPException as StarletteHTTPException

from . import models
from .api import admin, articles, auth, episodes, media, payments, rss, settings as settings_api, spa, subscribers
from .config import Settings
from .database import make_engine, make_session_factory
from .errors import ApiError
from .security import RateLimiter, lookup_session
from .services import content
from .services.email import EmailService
from .services.lightning import build_provider
from .services.storage import LocalStorage

log = logging.getLogger("pp")
VERSION = "1.0.0"


class JsonFormatter(logging.Formatter):
    _skip = set(logging.makeLogRecord({}).__dict__) | {"message", "asctime"}

    def format(self, record):
        out = {"ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"), "level": record.levelname, "logger": record.name, "msg": record.getMessage()}
        out.update({k: v for k, v in record.__dict__.items() if k not in self._skip})
        if record.exc_info:
            out["exc"] = self.formatException(record.exc_info)
        return json.dumps(out, default=str)


def configure_logging():
    root = logging.getLogger()
    if not any(isinstance(h.formatter, JsonFormatter) for h in root.handlers):
        handler = logging.StreamHandler()
        handler.setFormatter(JsonFormatter())
        root.handlers = [handler]
    root.setLevel(logging.INFO)


def create_app(settings: Settings | None = None, email_service=None) -> FastAPI:
    settings = settings or Settings()
    configure_logging()
    engine = make_engine(settings.database_url)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        if settings.auto_create_tables:
            models.Base.metadata.create_all(engine)
        app.state.storage.cleanup_tmp(settings.stale_upload_seconds)
        task = asyncio.create_task(_scheduler(app)) if settings.scheduler_enabled else None
        app.state.scheduler_task = task
        log.info("started", extra={"env": settings.env, "version": VERSION})
        yield
        if task:
            task.cancel()
        engine.dispose()
        log.info("stopped")

    async def _scheduler(app: FastAPI):
        """Publishes due scheduled content and sweeps abandoned uploads. Safe to run in every replica."""
        last_sweep = 0.0
        while True:
            try:
                def work():
                    with app.state.SessionLocal() as db:
                        content.publish_due(db)
                await asyncio.to_thread(work)
                if time.monotonic() - last_sweep > 600:
                    await asyncio.to_thread(app.state.storage.cleanup_tmp, settings.stale_upload_seconds)
                    last_sweep = time.monotonic()
            except Exception:
                log.exception("scheduler iteration failed")
            await asyncio.sleep(settings.scheduler_interval_seconds)

    app = FastAPI(title="Personal Podcast API", version=VERSION, lifespan=lifespan,
                  docs_url="/api/docs", redoc_url=None, openapi_url="/api/openapi.json")
    app.state.settings, app.state.engine = settings, engine
    app.state.SessionLocal = make_session_factory(engine)
    app.state.storage = LocalStorage(settings.media_dir)
    app.state.provider = build_provider(settings)
    app.state.email = email_service or EmailService(settings)
    app.state.scheduler_task = None
    app.state.limiters = {"login_ip": RateLimiter(10, 300), "login_email": RateLimiter(5, 900), "invoice": RateLimiter(10, 60),
                          "invoice_poll": RateLimiter(120, 60), "subscribe": RateLimiter(5, 600)}

    if settings.cors_origin_list:
        app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origin_list, allow_credentials=True,
                           allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["Content-Type", "X-CSRF-Token"])

    @app.middleware("http")
    async def guards(request: Request, call_next):
        # Reject oversized or unauthenticated uploads before the multipart body is parsed to disk.
        if request.method == "POST" and request.url.path == "/api/v1/media/upload":
            limit = (settings.max_audio_mb + 1) * 1024 * 1024
            if int(request.headers.get("content-length") or 0) > limit:
                return JSONResponse({"error": {"code": "file_too_large", "message": "The upload is too large."}}, status_code=413)
            with request.app.state.SessionLocal() as db:
                if not lookup_session(request, db):
                    return JSONResponse({"error": {"code": "unauthenticated", "message": "Sign in to continue."}}, status_code=401)
        response = await call_next(request)
        h = response.headers
        h.setdefault("X-Content-Type-Options", "nosniff")
        h.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        h.setdefault("X-Frame-Options", "DENY")
        h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if settings.env == "production":
            h.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        if request.url.path.startswith(("/api/v1/auth", "/api/v1/admin", "/api/v1/payments")):
            h.setdefault("Cache-Control", "no-store")
        return response

    @app.exception_handler(ApiError)
    async def api_error(_, exc: ApiError):
        body = {"code": exc.code, "message": exc.message}
        if exc.details is not None:
            body["details"] = exc.details
        return JSONResponse({"error": body}, status_code=exc.status, headers=exc.headers)

    @app.exception_handler(StarletteHTTPException)
    async def http_error(_, exc: StarletteHTTPException):
        return JSONResponse({"error": {"code": f"http_{exc.status_code}", "message": str(exc.detail)}}, status_code=exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def validation_error(_, exc: RequestValidationError):
        details = [{"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]} for e in exc.errors()]
        return JSONResponse({"error": {"code": "validation_error", "message": "Some fields are invalid.", "details": details}}, status_code=422)

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        log.exception("unhandled error", extra={"path": request.url.path})
        return JSONResponse({"error": {"code": "internal_error", "message": "Something went wrong on the server."}}, status_code=500)

    api = "/api/v1"
    for r in (auth.router, episodes.router, articles.router, media.router, payments.router, subscribers.router,
              settings_api.router, admin.router):
        app.include_router(r, prefix=api)
    app.include_router(media.public_router)
    app.include_router(rss.router)
    app.include_router(spa.router)  # catch-all, must stay last
    return app


def app_factory() -> FastAPI:  # uvicorn --factory app.main:app_factory
    return create_app()
