import hashlib
import hmac
import secrets
import threading
import time
from collections import defaultdict, deque
from urllib.parse import urlparse

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError
from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from .database import get_db
from .errors import ApiError
from .models import AuthSession, utcnow

COOKIE = "pp_session"
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}
_ph = PasswordHasher()  # Argon2id
DUMMY_HASH = _ph.hash("timing-equaliser-not-a-real-password")


def hash_password(password: str) -> str:
    return _ph.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    try:
        return _ph.verify(stored_hash, password)
    except (VerificationError, InvalidHashError):
        return False


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def hmac_token(secret: str, message: str) -> str:
    return hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()


def client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


class RateLimiter:
    """Sliding-window limiter held in process memory. Use a shared store (Redis) if you run several workers."""

    def __init__(self, limit: int, window_seconds: int):
        self.limit, self.window = limit, window_seconds
        self._hits: dict[str, deque] = defaultdict(deque)
        self._lock = threading.Lock()

    def check(self, key: str) -> None:
        now = time.monotonic()
        with self._lock:
            if len(self._hits) > 10_000:
                for k in [k for k, q in self._hits.items() if not q or now - q[-1] > self.window]:
                    del self._hits[k]
            q = self._hits[key]
            while q and now - q[0] > self.window:
                q.popleft()
            if len(q) >= self.limit:
                retry = int(self.window - (now - q[0])) + 1
                raise ApiError(429, "rate_limited", "Too many requests. Try again shortly.", headers={"Retry-After": str(retry)})
            q.append(now)


def _origin_ok(request: Request) -> bool:
    origin = request.headers.get("origin")
    if not origin:
        return True
    s = request.app.state.settings
    return (origin.rstrip("/") == s.site_url or urlparse(origin).netloc == request.headers.get("host")
            or origin.rstrip("/") in s.cors_origin_list)


def lookup_session(request: Request, db: Session) -> AuthSession | None:
    token = request.cookies.get(COOKIE)
    if not token:
        return None
    sess = db.scalar(select(AuthSession).where(AuthSession.token_hash == sha256_hex(token)))
    if not sess or sess.expires_at <= utcnow():
        return None
    return sess


def optional_admin(request: Request, db: Session = Depends(get_db)) -> AuthSession | None:
    return lookup_session(request, db)


def require_admin(request: Request, db: Session = Depends(get_db)) -> AuthSession:
    sess = lookup_session(request, db)
    if not sess:
        raise ApiError(401, "unauthenticated", "Sign in to continue.")
    if request.method not in SAFE_METHODS:
        if not _origin_ok(request):
            raise ApiError(403, "origin_rejected", "Cross-origin request rejected.")
        if not hmac.compare_digest(request.headers.get("x-csrf-token", ""), sess.csrf_token):
            raise ApiError(403, "csrf_failed", "Missing or invalid CSRF token. Reload the page and try again.")
    return sess
