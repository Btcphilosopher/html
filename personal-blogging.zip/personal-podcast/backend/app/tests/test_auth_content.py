from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError

from app import models as m
from app.config import Settings
from app.services import content

from .conftest import EMAIL, PASSWORD, anon, make_article, make_episode


def test_anonymous_cannot_write(ctx):
    app, _ = ctx
    c = anon(app)
    assert c.post("/api/v1/episodes", json={"title": "x"}).status_code == 401
    assert c.post("/api/v1/articles", json={"title": "x"}).status_code == 401
    assert c.get("/api/v1/admin/dashboard").status_code == 401
    assert c.patch("/api/v1/settings", json={"site_title": "x"}).status_code == 401
    assert c.get("/api/v1/admin/episodes").status_code == 401


def test_login_session_logout_and_cookie_flags(build):
    app, c = build(login=False)
    assert c.post("/api/v1/auth/login", json={"email": EMAIL, "password": "wrong password!!"}).json()["error"]["code"] == "invalid_credentials"
    r = c.post("/api/v1/auth/login", json={"email": EMAIL, "password": PASSWORD})
    cookie = r.headers["set-cookie"].lower()
    assert "httponly" in cookie and "samesite=lax" in cookie
    c.headers["X-CSRF-Token"] = r.json()["csrf_token"]
    assert c.get("/api/v1/auth/session").json()["authenticated"] is True
    assert c.post("/api/v1/auth/logout").status_code == 204
    assert c.get("/api/v1/auth/session").json() == {"authenticated": False}


def test_csrf_required_for_cookie_authenticated_writes(ctx):
    _, c = ctx
    token = c.headers.pop("X-CSRF-Token")
    r = c.post("/api/v1/articles", json={"title": "x"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "csrf_failed"
    r = c.post("/api/v1/articles", json={"title": "x"}, headers={"X-CSRF-Token": token, "Origin": "https://evil.example"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "origin_rejected"
    assert c.post("/api/v1/articles", json={"title": "x"}, headers={"X-CSRF-Token": token}).status_code == 201


def test_password_change_invalidates_other_sessions(build):
    app, c = build()
    other = anon(app)
    other.post("/api/v1/auth/login", json={"email": EMAIL, "password": PASSWORD})
    assert other.get("/api/v1/auth/session").json()["authenticated"] is True
    assert c.post("/api/v1/auth/password/change", json={"current_password": "nope nope nope", "new_password": "a brand new passphrase"}).status_code == 403
    assert c.post("/api/v1/auth/password/change", json={"current_password": PASSWORD, "new_password": "a brand new passphrase"}).status_code == 204
    assert other.get("/api/v1/auth/session").json()["authenticated"] is False
    assert c.get("/api/v1/auth/session").json()["authenticated"] is True
    assert anon(app).post("/api/v1/auth/login", json={"email": EMAIL, "password": PASSWORD}).status_code == 401
    assert c.post("/api/v1/auth/password/change", json={"current_password": "a brand new passphrase", "new_password": "short"}).status_code == 422


def test_login_is_rate_limited(build):
    _, c = build(login=False)
    codes = [c.post("/api/v1/auth/login", json={"email": EMAIL, "password": "bad password 123"}).status_code for _ in range(7)]
    assert codes[:5] == [401] * 5 and codes[5] == 429


def test_production_settings_refuse_insecure_values():
    with pytest.raises(ValidationError):
        Settings(env="production", cookie_secure=False, site_url="https://x.example", secret_key="x" * 40)
    with pytest.raises(ValidationError):
        Settings(env="production", site_url="http://x.example", secret_key="x" * 40)
    with pytest.raises(ValidationError):
        Settings(env="production", site_url="https://x.example")  # default dev secret
    with pytest.raises(ValidationError):
        Settings(env="production", site_url="https://x.example", secret_key="change-me-generate-with-openssl-rand-hex-32")
    with pytest.raises(ValidationError):
        Settings(env="development", payment_provider="mock")


def test_drafts_are_private_until_published(ctx):
    app, c = ctx
    art = make_article(c, "Secret draft", publish=False)
    pub = anon(app)
    assert pub.get("/api/v1/articles").json()["total"] == 0
    assert pub.get(f"/api/v1/articles/{art['slug']}").status_code == 404
    assert c.get(f"/api/v1/admin/articles/{art['id']}").json()["status"] == "draft"
    c.post(f"/api/v1/articles/{art['id']}/publish")
    assert pub.get(f"/api/v1/articles/{art['slug']}").status_code == 200
    assert pub.get("/api/v1/articles").json()["total"] == 1
    c.post(f"/api/v1/articles/{art['id']}/unpublish")
    assert pub.get(f"/api/v1/articles/{art['slug']}").status_code == 404
    assert "body_md" not in pub.get("/api/v1/articles").json()["items"][0] if pub.get("/api/v1/articles").json()["items"] else True


def test_markdown_is_sanitised(ctx):
    app, c = ctx
    body = "<script>alert(1)</script>\n\n[click](javascript:alert(1))\n\n<img src=x onerror=alert(1)>\n\n<a href=\"https://ok.example\" onclick=\"x()\">ok</a>\n\n**bold**"
    art = make_article(c, "XSS", body_md=body)
    html = anon(app).get(f"/api/v1/articles/{art['slug']}").json()["body_html"]
    for bad in ("<script", "javascript:", "onerror", "onclick", "alert(1)"):
        assert bad not in html
    assert "<strong>bold</strong>" in html and 'rel="noopener noreferrer"' in html


def test_slug_rules(ctx):
    _, c = ctx
    a = make_article(c, "Same title", publish=False)
    b = make_article(c, "Same title", publish=False)
    assert (a["slug"], b["slug"]) == ("same-title", "same-title-2")
    r = c.post("/api/v1/articles", json={"title": "x", "slug": "same-title"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "slug_taken"
    assert c.post("/api/v1/articles", json={"title": "x", "slug": "Bad Slug!"}).status_code == 422
    c.post(f"/api/v1/articles/{a['id']}/publish")
    r = c.patch(f"/api/v1/articles/{a['id']}", json={"version": 2, "slug": "renamed"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "slug_locked"


def test_optimistic_concurrency_and_revisions(ctx):
    _, c = ctx
    a = make_article(c, "Versioned", publish=False)
    r = c.patch(f"/api/v1/articles/{a['id']}", json={"version": a["version"], "body_md": "second"})
    assert r.status_code == 200 and r.json()["version"] == 2
    stale = c.patch(f"/api/v1/articles/{a['id']}", json={"version": 1, "body_md": "clobber"})
    assert stale.status_code == 409 and stale.json()["error"]["details"]["current_version"] == 2
    c.patch(f"/api/v1/articles/{a['id']}", json={"version": 2, "body_md": "third"})
    revs = c.get(f"/api/v1/admin/articles/{a['id']}/revisions").json()
    assert [r["snapshot"]["body_md"] for r in revs] == ["third", "second", "Hello **world**"]
    first = revs[-1]["id"]
    restored = c.post(f"/api/v1/admin/articles/{a['id']}/revisions/{first}/restore").json()
    assert restored["body_md"] == "Hello **world**" and restored["version"] == 4


def test_scheduling_visibility_does_not_depend_on_the_job(ctx):
    app, c = ctx
    art = make_article(c, "Later", publish=False)
    when = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
    r = c.post(f"/api/v1/articles/{art['id']}/publish", json={"publish_at": when})
    assert r.json()["status"] == "scheduled"
    pub = anon(app)
    assert pub.get(f"/api/v1/articles/{art['slug']}").status_code == 404
    with app.state.SessionLocal() as db:  # pretend the time has come, without running the scheduler
        db.query(m.Article).update({"publish_at": datetime.now(timezone.utc) - timedelta(minutes=1)})
        db.commit()
        assert pub.get(f"/api/v1/articles/{art['slug']}").status_code == 200
        assert db.get(m.Article, art["id"]).status == "scheduled"
        assert content.publish_due(db)["articles"] == 1
        assert content.publish_due(db)["articles"] == 0  # idempotent
        assert db.get(m.Article, art["id"]).status == "published"
    assert c.post(f"/api/v1/articles/{art['id']}/publish", json={"publish_at": "2030-01-01T00:00:00"}).status_code == 422  # naive time


def test_trash_and_restore(ctx):
    app, c = ctx
    a = make_article(c, "Trash me")
    assert c.delete(f"/api/v1/articles/{a['id']}").status_code == 204
    assert anon(app).get(f"/api/v1/articles/{a['slug']}").status_code == 404
    assert c.get("/api/v1/admin/articles").json()["total"] == 0
    assert c.get("/api/v1/admin/articles?status=trashed").json()["total"] == 1
    assert c.patch(f"/api/v1/articles/{a['id']}", json={"version": 3, "title": "x"}).status_code == 409
    assert c.post(f"/api/v1/articles/{a['id']}/restore").json()["status"] == "draft"


def test_episode_needs_audio_and_validates_input(ctx):
    _, c = ctx
    ep = c.post("/api/v1/episodes", json={"title": "No audio"}).json()
    r = c.post(f"/api/v1/episodes/{ep['id']}/publish")
    assert r.status_code == 422 and r.json()["error"]["code"] == "audio_required"
    assert c.post("/api/v1/episodes", json={"title": "x", "tags": ["y" * 41]}).status_code == 422
    assert c.post("/api/v1/episodes", json={"title": "x", "season": 0}).status_code == 422
    assert c.post("/api/v1/episodes", json={"title": "x", "audio_id": 999}).json()["error"]["code"] == "invalid_media"
    assert c.post("/api/v1/episodes", json={"title": "x", "links": [{"title": "t", "url": "javascript:alert(1)"}]}).status_code == 422
    assert c.post("/api/v1/episodes", json={"title": "x", "unknown_field": 1}).status_code == 422


def test_search_filters_and_pagination(ctx, mp3_bytes):
    app, c = ctx
    for i in range(3):
        make_episode(c, mp3_bytes, f"Stoicism part {i}", tags=["philosophy"], season=1, summary="about virtue")
    make_episode(c, mp3_bytes, "Cooking", tags=["food"])
    pub = anon(app)
    assert pub.get("/api/v1/episodes?q=stoicism").json()["total"] == 3
    assert pub.get("/api/v1/episodes?q=%25").json()["total"] == 0  # wildcard characters are escaped
    assert pub.get("/api/v1/episodes?tag=food").json()["total"] == 1
    assert pub.get("/api/v1/episodes?season=1").json()["total"] == 3
    page = pub.get("/api/v1/episodes?per_page=2&page=2").json()
    assert page["total"] == 4 and len(page["items"]) == 2 and page["pages"] == 2
    assert pub.get(f"/api/v1/episodes?year={datetime.now().year}").json()["total"] == 4
