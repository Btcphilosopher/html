import json

import httpx
import pytest

from app import models as m
from app.services.bitcoin import bip21, validate_address
from app.services.lightning import LNbitsProvider, ProviderError, WebhookAuthError

from .conftest import anon

VALID = "bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq"


def test_address_validation_checks_checksums():
    for good in ("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN2", "3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy", VALID,
                 "bc1p0xlxvlhemja6c4dqv22uapctqupfhlxm9h8z3k2e72q4k9hcz7vqzk5jj0"):
        assert validate_address(good)
    for bad in ("1BvBMSEYstWetqTFn5Au4m4GFg7xJaNVN3", "bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdp", "", "hello",
                "tb1qw508d6qejxtdg4y5r3zarvary0c5xw7kxpjzsx", VALID.upper()[:-1] + "p"):
        assert not validate_address(bad)
    assert validate_address("tb1qw508d6qejxtdg4y5r3zarvary0c5xw7kxpjzsx", "testnet")
    assert bip21(VALID, 21_000) == f"bitcoin:{VALID}?amount=0.00021000"
    assert bip21(VALID) == f"bitcoin:{VALID}"


def test_unconfigured_payments_say_so(ctx):
    app, c = ctx
    p = anon(app)
    r = p.post("/api/v1/payments/invoices", json={"kind": "lightning", "amount_sats": 1000})
    assert r.status_code == 503 and r.json()["error"]["code"] == "lightning_unavailable"
    r = p.post("/api/v1/payments/invoices", json={"kind": "onchain"})
    assert r.status_code == 503 and r.json()["error"]["code"] == "onchain_unavailable"
    assert p.get("/api/v1/settings/public").json()["donations"] == {
        "onchain_address": None, "lightning_available": False, "suggested_amounts_sats": [], "message": "", "network": "mainnet"}


def test_onchain_donation_flow_stores_nothing(ctx):
    app, c = ctx
    r = c.patch("/api/v1/settings", json={"donation_address": "bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdp"})
    assert r.status_code == 422 and r.json()["error"]["code"] == "invalid_bitcoin_address"
    assert c.patch("/api/v1/settings", json={"donation_address": VALID, "suggested_amounts_sats": [1000, 21000]}).status_code == 200
    r = anon(app).post("/api/v1/payments/invoices", json={"kind": "onchain", "amount_sats": 21_000})
    j = r.json()
    assert j["address"] == VALID and j["bip21"].endswith("amount=0.00021000") and j["tracking"] == "none"
    qr = anon(app).get(j["qr_url"])
    assert qr.status_code == 200 and qr.headers["content-type"] == "image/svg+xml" and b"<svg" in qr.content
    with app.state.SessionLocal() as db:
        assert db.query(m.PaymentInvoice).count() == 0
    assert anon(app).get("/api/v1/payments/qr?data=http://evil.example/phish").status_code == 422
    assert anon(app).post("/api/v1/payments/invoices", json={"kind": "onchain", "amount_sats": 10**12}).status_code == 422


def _invoice(app, sats=1000):
    r = anon(app).post("/api/v1/payments/invoices", json={"kind": "lightning", "amount_sats": sats, "supporter_name": "Reader", "message": "Thanks"})
    assert r.status_code == 200, r.text
    inv = r.json()
    with app.state.SessionLocal() as db:
        ref = db.query(m.PaymentInvoice).filter_by(public_id=inv["id"]).one().provider_ref
    return inv, ref


def _hook(app, ref, event_id="evt-1", sig=None, provider="mock"):
    body = json.dumps({"event_id": event_id, "payment_hash": ref}).encode()
    sig = app.state.provider.sign(body) if sig is None else sig
    return anon(app).post(f"/api/v1/payments/webhooks/{provider}", content=body, headers={"X-Mock-Signature": sig, "Content-Type": "application/json"})


def _events(app, ref):
    with app.state.SessionLocal() as db:
        inv = db.query(m.PaymentInvoice).filter_by(provider_ref=ref).one()
        return [(e.event_id, e.outcome) for e in db.query(m.PaymentEvent).filter_by(invoice_id=inv.id).order_by(m.PaymentEvent.id)]


def test_only_verified_settlement_marks_paid(build):
    app, _ = build(payment_provider="mock")
    inv, ref = _invoice(app, 2100)
    p = anon(app)
    assert inv["status"] == "pending" and inv["bolt11"].startswith("lnbcmock") and inv["qr_url"].startswith("/api/v1/payments/qr")
    assert p.get(f"/api/v1/payments/{inv['id']}").json()["status"] == "pending"
    assert _hook(app, ref, sig="0" * 64).status_code == 401  # forged signature
    assert _hook(app, ref, provider="lnbits").status_code == 404
    assert anon(app).post("/api/v1/payments/webhooks/mock", content=b"not json", headers={"X-Mock-Signature": app.state.provider.sign(b"not json")}).status_code == 401
    spoof = _hook(app, ref, event_id="evt-spoof")  # correctly signed, but the provider says nothing was paid
    assert spoof.json()["status"] == "not_settled"
    assert p.get(f"/api/v1/payments/{inv['id']}").json()["status"] == "pending"
    app.state.provider.settle(ref)
    ok = _hook(app, ref, event_id="evt-1")
    assert ok.status_code == 200 and ok.json()["status"] == "paid"
    dup = _hook(app, ref, event_id="evt-1")
    assert dup.json()["status"] in ("duplicate", "already_paid")
    after = p.get(f"/api/v1/payments/{inv['id']}").json()
    assert after["status"] == "paid" and after["paid_at"]
    outcomes = [o for e, o in _events(app, ref)]
    assert outcomes.count("paid") == 1 and "not_settled" in outcomes
    assert [e for e, _ in _events(app, ref)].count("evt-1") == 1  # one row per provider event id


def test_redelivery_of_the_same_event_id_is_a_duplicate(build):
    app, _ = build(payment_provider="mock")
    _, ref = _invoice(app)
    app.state.provider.settle(ref)
    assert _hook(app, ref, event_id="same").json()["status"] == "paid"
    assert _hook(app, ref, event_id="same").json()["status"] == "duplicate"
    assert [e for e, _ in _events(app, ref)].count("same") == 1
    assert _hook(app, "f" * 32, event_id="ghost").json()["status"] == "ignored"


def test_polling_settles_and_late_webhook_is_harmless(build):
    app, _ = build(payment_provider="mock")
    inv, ref = _invoice(app)
    app.state.provider.settle(ref)
    assert anon(app).get(f"/api/v1/payments/{inv['id']}").json()["status"] == "paid"
    assert _hook(app, ref, event_id="late").json()["status"] == "already_paid"
    assert [o for _, o in _events(app, ref)].count("paid") == 1


def test_expiry_and_payment_after_expiry(build):
    from datetime import datetime, timedelta, timezone
    app, _ = build(payment_provider="mock")
    inv, ref = _invoice(app)
    with app.state.SessionLocal() as db:
        db.query(m.PaymentInvoice).update({"expires_at": datetime.now(timezone.utc) - timedelta(minutes=1)})
        db.commit()
    assert anon(app).get(f"/api/v1/payments/{inv['id']}").json()["status"] == "expired"
    app.state.provider.settle(ref)  # money really arrived: provider is the authority
    assert anon(app).get(f"/api/v1/payments/{inv['id']}").json()["status"] == "paid"
    assert "paid_after_expiry" in [o for _, o in _events(app, ref)]
    assert anon(app).get("/api/v1/payments/" + "0" * 32).status_code == 404


def test_invoice_amount_and_rate_limit(build):
    app, _ = build(payment_provider="mock", max_invoice_sats=5000)
    p = anon(app)
    assert p.post("/api/v1/payments/invoices", json={"kind": "lightning", "amount_sats": 5001}).status_code == 422
    assert p.post("/api/v1/payments/invoices", json={"kind": "lightning"}).json()["error"]["code"] == "amount_required"
    assert p.post("/api/v1/payments/invoices", json={"kind": "lightning", "amount_sats": 0}).status_code == 422
    codes = [p.post("/api/v1/payments/invoices", json={"kind": "lightning", "amount_sats": 100}).status_code for _ in range(10)]
    assert 429 in codes


def test_admin_payment_listing_requires_auth(build):
    app, c = build(payment_provider="mock")
    _invoice(app)
    assert anon(app).get("/api/v1/payments").status_code == 401
    rows = c.get("/api/v1/payments").json()
    assert rows[0]["supporter_name"] == "Reader" and rows[0]["amount_sats"] == 1000
    assert "supporter_name" not in anon(app).get(f"/api/v1/payments/{rows[0]['id']}").json()


def test_lnbits_adapter_request_shapes():
    seen = []

    def handler(req: httpx.Request):
        seen.append((req.method, req.url.path))
        if req.method == "POST" and req.url.path == "/api/v1/payments":
            body = json.loads(req.content)
            assert req.headers["x-api-key"] == "invkey" and body["amount"] == 2100 and body["out"] is False
            assert body["webhook"].endswith("?secret=whsecret")
            return httpx.Response(201, json={"payment_hash": "abc123", "payment_request": "lnbc21u1pabc"})
        if req.url.path == "/api/v1/payments/abc123":
            return httpx.Response(200, json={"paid": True})
        if req.url.path == "/api/v1/payments/boom":
            return httpx.Response(500)
        return httpx.Response(404)

    prov = LNbitsProvider("https://ln.example/", "invkey", "whsecret", client=httpx.Client(transport=httpx.MockTransport(handler)))
    pi = prov.create_invoice(2100, "memo", 600, "https://site.example/hook")
    assert pi.provider_ref == "abc123" and pi.bolt11 == "lnbc21u1pabc"
    assert prov.get_status("abc123") == "paid"
    with pytest.raises(ProviderError):
        prov.get_status("boom")
    ev = prov.parse_webhook({}, {"secret": "whsecret"}, b'{"payment_hash": "abc123"}')
    assert ev.provider_ref == "abc123"
    with pytest.raises(WebhookAuthError):
        prov.parse_webhook({}, {"secret": "wrong"}, b'{"payment_hash": "abc123"}')
    with pytest.raises(WebhookAuthError):
        prov.parse_webhook({}, {"secret": "whsecret"}, b"{}")
