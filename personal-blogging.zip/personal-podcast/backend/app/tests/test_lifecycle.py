"""The acceptance lifecycle from the brief, as one sequential API-level test against the real app, database and ffprobe."""
import email.utils
import json
import xml.etree.ElementTree as ET

from .conftest import PNG, anon, upload

VALID = "bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq"


def test_full_publishing_lifecycle(build, mp3_bytes):
    app, admin = build(payment_provider="mock")                                    # 1 log in as the administrator
    public = anon(app)
    assert public.post("/api/v1/episodes", json={"title": "nope"}).status_code == 401
    admin.patch("/api/v1/settings", json={"site_title": "Lifecycle", "donation_address": VALID})
    media = upload(admin, mp3_bytes, name="lifecycle.mp3")                         # 2 upload a valid MP3
    assert media.status_code == 201
    art = upload(admin, PNG, name="art.png", kind="image").json()
    ep = admin.post("/api/v1/episodes", json={"title": "Lifecycle episode", "audio_id": media.json()["id"], "artwork_id": art["id"],  # 3 create
                                              "show_notes_md": "Notes & more", "tags": ["test"]}).json()
    assert public.get(f"/api/v1/episodes/{ep['slug']}").status_code == 404
    assert admin.post(f"/api/v1/episodes/{ep['id']}/publish").json()["status"] == "published"   # 4 publish
    page = public.get(f"/api/v1/episodes/{ep['slug']}")                            # 5 open its public page
    assert page.status_code == 200 and page.json()["title"] == "Lifecycle episode"
    audio_url = page.json()["audio_url"]
    seek = public.get(audio_url, headers={"Range": "bytes=1000-1999"})             # 6 play and seek
    assert seek.status_code == 206 and seek.content == mp3_bytes[1000:2000]
    feed = public.get("/feed/podcast.xml")                                         # 7 retrieve the RSS feed
    item = ET.fromstring(feed.content).find("channel/item")
    enclosure = item.find("enclosure")                                             # 8 enclosure URL and length are correct
    assert int(enclosure.get("length")) == len(mp3_bytes)
    assert public.get(enclosure.get("url").replace("http://testserver", "")).content == mp3_bytes
    email.utils.parsedate_to_datetime(item.findtext("pubDate"))
    article = admin.post("/api/v1/articles", json={"title": "Lifecycle article", "body_md": "Body"}).json()   # 9 publish a blog article
    admin.post(f"/api/v1/articles/{article['id']}/publish")
    assert public.get(f"/api/v1/articles/{article['slug']}").status_code == 200
    assert "Lifecycle article" in public.get("/feed/blog.xml").text
    inv = public.post("/api/v1/payments/invoices", json={"kind": "lightning", "amount_sats": 2100}).json()   # 10 create a test invoice
    ref = next(iter(app.state.provider.invoices))
    forged = public.post("/api/v1/payments/webhooks/mock", content=json.dumps({"event_id": "e1", "payment_hash": ref}), headers={"X-Mock-Signature": "bad"})
    assert forged.status_code == 401                                               # 11 invalid payment events are rejected
    assert public.get(f"/api/v1/payments/{inv['id']}").json()["status"] == "pending"
    app.state.provider.settle(ref)
    body = json.dumps({"event_id": "e2", "payment_hash": ref}).encode()
    ok = public.post("/api/v1/payments/webhooks/mock", content=body, headers={"X-Mock-Signature": app.state.provider.sign(body)})
    assert ok.json()["status"] == "paid"                                           # 12 only verified settlement changes the status
    assert public.get(f"/api/v1/payments/{inv['id']}").json()["status"] == "paid"
