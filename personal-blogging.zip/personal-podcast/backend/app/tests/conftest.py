import base64
import subprocess
from contextlib import ExitStack

import pytest
from fastapi.testclient import TestClient

from app import models as m
from app.config import Settings
from app.main import create_app
from app.security import hash_password

EMAIL, PASSWORD = "admin@example.test", "correct horse battery staple"
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==")


class FakeEmail:
    configured = True

    def __init__(self):
        self.sent = []

    def send(self, to, subject, body):
        self.sent.append((to, subject, body))


@pytest.fixture(scope="session")
def mp3_bytes(tmp_path_factory):
    p = tmp_path_factory.mktemp("audio") / "tone.mp3"
    subprocess.run(["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=2", "-c:a", "libmp3lame", "-b:a", "64k", str(p)], check=True)
    return p.read_bytes()


@pytest.fixture
def build(tmp_path):
    stack, counter = ExitStack(), iter(range(1000))

    def _build(login=True, email=None, **over):
        n = next(counter)
        kw = dict(env="test", database_url=f"sqlite:///{tmp_path}/t{n}.db", media_dir=tmp_path / f"media{n}", auto_create_tables=True,
                  scheduler_enabled=False, cookie_secure=False, site_url="http://testserver",
                  secret_key="test-secret-key-test-secret-key-0123456789", frontend_path=tmp_path / "index.html")
        kw.update(over)
        app = create_app(Settings(**kw), email_service=email)
        client = stack.enter_context(TestClient(app))
        with app.state.SessionLocal() as db:
            db.add(m.User(email=EMAIL, password_hash=hash_password(PASSWORD)))
            db.commit()
        if login:
            r = client.post("/api/v1/auth/login", json={"email": EMAIL, "password": PASSWORD})
            assert r.status_code == 200, r.text
            client.headers["X-CSRF-Token"] = r.json()["csrf_token"]
        return app, client

    yield _build
    stack.close()


@pytest.fixture
def ctx(build):
    return build()


def anon(app):
    return TestClient(app)


def upload(client, data, name="ep.mp3", kind="audio", ctype="audio/mpeg"):
    return client.post("/api/v1/media/upload", files={"file": (name, data, ctype)}, data={"kind": kind})


def make_episode(client, mp3, title="Episode one", publish=True, **fields):
    media = upload(client, mp3)
    assert media.status_code == 201, media.text
    r = client.post("/api/v1/episodes", json={"title": title, "audio_id": media.json()["id"], **fields})
    assert r.status_code == 201, r.text
    ep = r.json()
    if publish:
        r = client.post(f"/api/v1/episodes/{ep['id']}/publish")
        assert r.status_code == 200, r.text
        ep = r.json()
    return ep


def make_article(client, title="An article", publish=True, **fields):
    r = client.post("/api/v1/articles", json={"title": title, "body_md": "Hello **world**", **fields})
    assert r.status_code == 201, r.text
    art = r.json()
    if publish:
        r = client.post(f"/api/v1/articles/{art['id']}/publish")
        assert r.status_code == 200, r.text
        art = r.json()
    return art
