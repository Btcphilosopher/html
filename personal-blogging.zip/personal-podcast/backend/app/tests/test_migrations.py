from pathlib import Path

import sqlalchemy as sa
from alembic import command
from alembic.autogenerate import compare_metadata
from alembic.config import Config
from alembic.migration import MigrationContext

from app.models import Base

BACKEND = Path(__file__).resolve().parents[2]


def _config(url):
    cfg = Config(str(BACKEND / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND / "migrations"))
    cfg.set_main_option("sqlalchemy.url", url)
    return cfg


def test_migrations_build_exactly_the_schema_the_models_describe(tmp_path):
    url = f"sqlite:///{tmp_path}/mig.db"
    command.upgrade(_config(url), "head")
    engine = sa.create_engine(url)
    tables = set(sa.inspect(engine).get_table_names())
    assert set(Base.metadata.tables) <= tables and "alembic_version" in tables
    with engine.connect() as conn:
        diff = compare_metadata(MigrationContext.configure(conn, opts={"compare_type": False}), Base.metadata)
    assert diff == [], f"models and migrations have drifted: {diff}"
    command.downgrade(_config(url), "base")
    assert set(sa.inspect(engine).get_table_names()) == {"alembic_version"}
