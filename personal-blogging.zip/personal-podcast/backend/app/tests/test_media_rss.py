import email.utils
import xml.etree.ElementTree as ET

import pytest

from app.api.media import RangeNotSatisfiable, parse_range
from app.services.storage import LocalStorage

from .conftest import PNG, anon, make_article, make_episode, upload

NS = {"itunes": "http://www.itunes.com/dtds/podcast-1.0.dtd", "content": "http://purl.org/rss/1.0/modules/content/"}


def test_valid_mp3_upload_records_real_metadata(ctx, mp3_bytes):
    _, c = ctx
    r = upload(c, mp3_bytes, name="My Episode (final).mp3")
    assert r.status_code == 201
    j = r.json()
    assert j["mime"] == "audio/mpeg" and j["size_bytes"] == len(mp3_bytes) and abs(j["duration_seconds"] - 2.0) < 0.2
    assert j["url"].endswith("/my-episode-final.mp3") and "/" not in j["storage_key"].split("/")[-1]


def test_uploads_are_inspected_not_trusted(ctx, mp3_bytes):
    app, c = ctx
    assert upload(c, b"this is plain text, not audio" * 100, name="fake.mp3").json()["error"]["code"] == "not_mp3"
    assert upload(c, b"ID3" + b"\x00" * 6000, name="broken.mp3").json()["error"]["code"] == "invalid_audio"
    assert upload(c, mp3_bytes, name="a.png", kind="image", ctype="image/png").json()["error"]["code"] == "not_image"
    assert upload(c, b"<svg xmlns='http://www.w3.org/2000/svg'><script>alert(1)</script></svg>", name="x.svg", kind="image", ctype="image/svg+xml").status_code == 415
    ok = upload(c, PNG, name="cover.png", kind="image", ctype="application/octet-stream")
    assert ok.status_code == 201 and ok.json()["mime"] == "image/png"
    assert upload(anon(app), mp3_bytes).status_code == 401
    assert len(list((app.state.storage.root / "tmp").iterdir())) == 0  # rejected uploads leave nothing behind


def test_limits_and_quota(build, mp3_bytes):
    _, c = build(max_audio_mb=0)
    assert upload(c, mp3_bytes).json()["error"]["code"] == "file_too_large"
    _, c2 = build(storage_quota_mb=0)
    assert upload(c2, mp3_bytes).json()["error"]["code"] == "quota_exceeded"


def test_storage_refuses_path_traversal(tmp_path):
    s = LocalStorage(tmp_path)
    for bad in ("../../etc/passwd", "audio/../../x.mp3", "/etc/passwd", "audio/zz/notahexid.mp3"):
        with pytest.raises(ValueError):
            s.path(bad)


def test_parse_range_unit():
    assert parse_range(None, 100) is None and parse_range("items=0-5", 100) is None and parse_range("bytes=0-1,5-6", 100) is None
    assert parse_range("bytes=0-9", 100) == (0, 9) and parse_range("bytes=90-", 100) == (90, 99)
    assert parse_range("bytes=-10", 100) == (90, 99) and parse_range("bytes=0-9999", 100) == (0, 99)
    assert parse_range("bytes=abc-def", 100) is None
    for bad in ("bytes=100-", "bytes=50-10", "bytes=-0"):
        with pytest.raises(RangeNotSatisfiable):
            parse_range(bad, 100)


def test_audio_streaming_with_ranges(ctx, mp3_bytes):
    app, c = ctx
    ep = make_episode(c, mp3_bytes)
    url, size = ep["audio_url"], len(mp3_bytes)
    p = anon(app)
    full = p.get(url)
    assert full.status_code == 200 and full.content == mp3_bytes
    assert full.headers["content-type"] == "audio/mpeg" and full.headers["accept-ranges"] == "bytes"
    part = p.get(url, headers={"Range": "bytes=0-99"})
    assert part.status_code == 206 and part.content == mp3_bytes[:100]
    assert part.headers["content-range"] == f"bytes 0-99/{size}" and part.headers["content-length"] == "100"
    assert p.get(url, headers={"Range": "bytes=-50"}).content == mp3_bytes[-50:]
    tail = p.get(url, headers={"Range": "bytes=1000-"})
    assert tail.status_code == 206 and tail.content == mp3_bytes[1000:]
    bad = p.get(url, headers={"Range": f"bytes={size + 10}-"})
    assert bad.status_code == 416 and bad.headers["content-range"] == f"bytes */{size}"
    head = p.head(url)
    assert head.status_code == 200 and head.content == b"" and head.headers["content-length"] == str(size)
    etag = full.headers["etag"]
    assert p.get(url, headers={"If-None-Match": etag}).status_code == 304
    assert p.get(url, headers={"Range": "bytes=0-9", "If-Range": '"other"'}).status_code == 200  # stale validator -> full body
    dl = p.get(ep["download_url"])
    assert dl.headers["content-disposition"].startswith("attachment; filename=")


def test_draft_media_is_private(ctx, mp3_bytes):
    app, c = ctx
    ep = make_episode(c, mp3_bytes, publish=False)
    p = anon(app)
    assert c.get(ep["audio_url"]).status_code == 200  # the administrator can preview
    assert p.get(ep["audio_url"]).status_code == 404
    c.post(f"/api/v1/episodes/{ep['id']}/publish")
    assert p.get(ep["audio_url"]).status_code == 200
    c.post(f"/api/v1/episodes/{ep['id']}/unpublish")
    assert p.get(ep["audio_url"]).status_code == 404
    assert p.get("/media/..%2f..%2fetc%2fpasswd").status_code == 404
    assert p.get("/media/not-a-real-id/x.mp3").status_code == 404


def test_media_in_use_cannot_be_deleted(ctx, mp3_bytes):
    app, c = ctx
    ep = make_episode(c, mp3_bytes, publish=False)
    r = c.delete(f"/api/v1/media/{ep['audio_id']}")
    assert r.status_code == 409 and r.json()["error"]["code"] == "media_in_use"
    spare = upload(c, mp3_bytes).json()
    assert c.delete(f"/api/v1/media/{spare['id']}").status_code == 204
    assert not app.state.storage.exists(spare["storage_key"])
    listing = c.get("/api/v1/media").json()
    assert any(i["used_by"] for i in listing["items"])


# ---- RSS ---------------------------------------------------------------------------------------------
def parse(resp):
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("application/rss+xml")
    return ET.fromstring(resp.content).find("channel")


def test_feeds_reflect_publication_state(ctx, mp3_bytes):
    app, c = ctx
    p = anon(app)
    assert parse(p.get("/feed/podcast.xml")).findall("item") == []
    draft = make_episode(c, mp3_bytes, "Hidden draft", publish=False)
    live = make_episode(c, mp3_bytes, "Visible", season=2, episode_number=5, episode_type="bonus", explicit=True)
    ch = parse(p.get("/feed/podcast.xml"))
    items = ch.findall("item")
    assert [i.findtext("title") for i in items] == ["Visible"]
    item = items[0]
    enc = item.find("enclosure")
    stored = app.state.storage.size(live and c.get(f"/api/v1/admin/episodes/{live['id']}").json() and _key(app, live["audio_id"]))
    assert enc.get("length") == str(stored) == str(len(mp3_bytes)) and enc.get("type") == "audio/mpeg"
    assert enc.get("url").startswith("http://testserver/media/")
    assert p.get(enc.get("url").replace("http://testserver", "")).content == mp3_bytes
    assert item.findtext("itunes:season", namespaces=NS) == "2" and item.findtext("itunes:episode", namespaces=NS) == "5"
    assert item.findtext("itunes:episodeType", namespaces=NS) == "bonus" and item.findtext("itunes:explicit", namespaces=NS) == "true"
    assert item.findtext("itunes:duration", namespaces=NS) == "00:00:02"
    assert item.find("guid").get("isPermaLink") == "false"
    email.utils.parsedate_to_datetime(item.findtext("pubDate"))  # valid RFC 2822
    c.post(f"/api/v1/episodes/{live['id']}/unpublish")
    assert parse(p.get("/feed/podcast.xml")).findall("item") == []
    assert draft["status"] == "draft"


def _key(app, media_id):
    from app import models as m
    with app.state.SessionLocal() as db:
        return db.get(m.MediaAsset, media_id).storage_key


def test_guid_is_stable_and_special_characters_survive(ctx, mp3_bytes):
    app, c = ctx
    tricky = "Tom & Jerry's <b>\"Café\"</b> 🎙️ ü \x08 end"
    ep = make_episode(c, mp3_bytes, tricky, summary="5 < 6 & 7 > 3", show_notes_md="Notes with <em>markup</em> & ampersands")
    first = parse(anon(app).get("/feed/podcast.xml")).find("item")
    guid = first.findtext("guid")
    assert first.findtext("title") == tricky.replace("\x08", "")
    assert first.findtext("description") == "5 < 6 & 7 > 3"
    c.patch(f"/api/v1/episodes/{ep['id']}", json={"version": ep["version"], "title": "Renamed"})
    second = parse(anon(app).get("/feed/podcast.xml")).find("item")
    assert second.findtext("guid") == guid and second.findtext("title") == "Renamed"


def test_feed_caching_headers_and_channel_metadata(ctx, mp3_bytes):
    app, c = ctx
    art = upload(c, PNG, name="art.png", kind="image", ctype="image/png").json()
    r = c.patch("/api/v1/settings", json={"site_title": "The Journal", "podcast_description": "Ideas, slowly.", "podcast_language": "en-GB",
                                          "podcast_category": "Philosophy", "podcast_owner_email": "owner@example.com",
                                          "podcast_owner_name": "O. Wner", "default_artwork_id": art["id"], "podcast_author": "A. Author"})
    assert r.status_code == 200, r.text
    make_episode(c, mp3_bytes)
    resp = anon(app).get("/feed/podcast.xml")
    ch = parse(resp)
    assert ch.findtext("title") == "The Journal" and ch.findtext("description") == "Ideas, slowly." and ch.findtext("language") == "en-GB"
    assert ch.find("itunes:image", NS).get("href").startswith("http://testserver/media/")
    assert ch.find("itunes:owner/itunes:email", NS).text == "owner@example.com" and ch.find("itunes:category", NS).get("text") == "Philosophy"
    assert ch.findtext("itunes:explicit", namespaces=NS) == "false" and ch.findtext("link") == "http://testserver/"
    assert anon(app).get("/feed/podcast.xml", headers={"If-None-Match": resp.headers["etag"]}).status_code == 304
    assert "last-modified" in resp.headers


def test_blog_and_combined_feeds(ctx, mp3_bytes):
    app, c = ctx
    make_episode(c, mp3_bytes, "Pod")
    make_article(c, "Post", excerpt="Short")
    make_article(c, "Unpublished", publish=False)
    p = anon(app)
    blog = parse(p.get("/feed/blog.xml")).findall("item")
    assert [i.findtext("title") for i in blog] == ["Post"] and blog[0].find("enclosure") is None
    assert blog[0].find("content:encoded", NS).text.startswith("<p>Hello")
    assert sorted(i.findtext("title") for i in parse(p.get("/feed/all.xml")).findall("item")) == ["Pod", "Post"]


def test_missing_audio_file_is_skipped_not_fatal(ctx, mp3_bytes):
    app, c = ctx
    ep = make_episode(c, mp3_bytes)
    app.state.storage.delete(_key(app, ep["audio_id"]))
    assert parse(anon(app).get("/feed/podcast.xml")).findall("item") == []
