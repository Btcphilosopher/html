import re
import xml.etree.ElementTree as ET

from app import models as m
from app.api.subscribers import unsubscribe_token

from .conftest import FakeEmail, anon, make_article, make_episode, upload

SHELL = '<!doctype html><html><head><!--SERVER_META--></head><body><noscript><!--SERVER_NOSCRIPT--></noscript><script nonce="__CSP_NONCE__">1</script></body></html>'


def test_subscriptions_are_off_without_email_delivery(ctx):
    app, _ = ctx
    r = anon(app).post("/api/v1/subscribers", json={"email": "reader@example.com"})
    assert r.status_code == 503 and r.json()["error"]["code"] == "email_unavailable"
    with app.state.SessionLocal() as db:
        assert db.query(m.Subscriber).count() == 0
    assert anon(app).get("/api/v1/settings/public").json()["email_signup_available"] is False


def test_subscription_verification_and_unsubscribe(build):
    mail = FakeEmail()
    app, c = build(email=mail)
    p = anon(app)
    assert p.post("/api/v1/subscribers", json={"email": "not-an-email"}).status_code == 422
    assert p.post("/api/v1/subscribers", json={"email": "Reader@Example.com"}).status_code == 202
    assert len(mail.sent) == 1 and mail.sent[0][0] == "reader@example.com"
    token = re.search(r"token=([\w-]+)", mail.sent[0][2])[1]
    assert c.get("/api/v1/subscribers").json()["counts"] == {"pending": 1}
    p.post("/api/v1/subscribers", json={"email": "reader@example.com"})
    assert len(mail.sent) == 1  # resend cooldown
    assert p.post("/api/v1/subscribers/verify", json={"token": "x" * 20}).status_code == 400
    assert p.post("/api/v1/subscribers/verify", json={"token": token}).json() == {"status": "verified"}
    assert p.post("/api/v1/subscribers/verify", json={"token": token}).status_code == 400  # single use
    assert p.post("/api/v1/subscribers", json={"email": "reader@example.com"}).status_code == 202
    assert len(mail.sent) == 1  # verified addresses get nothing and learn nothing
    with app.state.SessionLocal() as db:
        sub = db.query(m.Subscriber).one()
        good = unsubscribe_token(app.state.settings.secret_key, sub)
    assert p.post("/api/v1/subscribers/unsubscribe", json={"token": "1.deadbeefdeadbeef"}).status_code == 400
    assert p.post("/api/v1/subscribers/unsubscribe", json={"token": good}).json() == {"status": "unsubscribed"}
    assert c.get("/api/v1/subscribers").json()["counts"] == {"unsubscribed": 1}
    assert anon(app).get("/api/v1/subscribers").status_code == 401


def test_settings_public_view_hides_markdown_and_sanitises(ctx):
    app, c = ctx
    r = c.patch("/api/v1/settings", json={"about_md": "About <script>x()</script> **me**", "publisher_name": "Pub",
                                          "social_links": [{"label": "Mastodon", "url": "https://example.social/@me"}]})
    assert r.status_code == 200
    pub = anon(app).get("/api/v1/settings/public").json()
    assert "about_md" not in pub and "<script" not in pub["about_html"] and "<strong>me</strong>" in pub["about_html"]
    assert pub["social_links"][0]["label"] == "Mastodon"
    assert c.patch("/api/v1/settings", json={"social_links": [{"label": "x", "url": "javascript:alert(1)"}]}).status_code == 422
    assert c.patch("/api/v1/settings", json={"contact_email": "nope"}).status_code == 422
    assert c.patch("/api/v1/settings", json={"default_artwork_id": 12345}).status_code == 422
    assert "about_md" in c.get("/api/v1/settings").json()


def test_dashboard_reports_measurements_not_inventions(ctx, mp3_bytes):
    app, c = ctx
    make_episode(c, mp3_bytes, "One")
    make_episode(c, mp3_bytes, "Two", publish=False)
    make_article(c, "Post")
    d = c.get("/api/v1/admin/dashboard").json()
    assert d["episodes"]["live"] == 1 and d["episodes"]["draft"] == 1 and d["articles"]["live"] == 1
    assert d["storage"]["used_bytes"] == 2 * len(mp3_bytes) and d["storage"]["files"] == 2
    assert d["analytics"]["collected"] is False and d["payments"]["paid_count"] == 0
    assert d["health"]["database"] and d["health"]["storage_writable"] and d["health"]["lightning_provider"] is None
    assert any("artwork" in w for w in d["feed_warnings"])
    assert d["activity"] and len(d["recent_uploads"]) == 2


def test_spa_shell_injects_escaped_metadata_and_csp_nonce(build, tmp_path, mp3_bytes):
    (tmp_path / "index.html").write_text(SHELL)
    app, c = build()
    c.patch("/api/v1/settings", json={"site_title": "The Journal"})
    ep = make_episode(c, mp3_bytes, "A & <B> \"quoted\"", summary="Desc <i>x</i>")
    p = anon(app)
    r = p.get(f"/episodes/{ep['slug']}")
    assert r.status_code == 200
    assert "<title>A &amp; &lt;B&gt; &quot;quoted&quot; | The Journal</title>" in r.text
    assert 'property="og:audio"' in r.text and f'href="http://testserver/episodes/{ep["slug"]}"' in r.text
    nonce = re.search(r'<script nonce="([^"]+)"', r.text)[1]
    csp = r.headers["content-security-policy"]
    assert f"'nonce-{nonce}'" in csp and "unsafe-inline" not in csp and "frame-ancestors 'none'" in csp
    assert "<script>alert" not in r.text
    missing = p.get("/episodes/not-there")
    assert missing.status_code == 404 and 'content="noindex"' in missing.text
    assert p.get("/").status_code == 200 and 'content="noindex"' in p.get("/admin/episodes").text
    nf = p.get("/api/v1/nope")
    assert nf.status_code == 404 and nf.json()["error"]["code"] == "not_found"
    assert p.get("/feed/nope.xml").status_code == 404
    urls = [e.text for e in ET.fromstring(p.get("/sitemap.xml").content).iter("{http://www.sitemaps.org/schemas/sitemap/0.9}loc")]
    assert f"http://testserver/episodes/{ep['slug']}" in urls
    assert "Disallow: /admin" in p.get("/robots.txt").text


def test_errors_headers_health_and_openapi(ctx):
    app, c = ctx
    r = c.post("/api/v1/episodes", json={})
    assert r.status_code == 422 and r.json()["error"]["code"] == "validation_error" and r.json()["error"]["details"][0]["field"] == "title"
    p = anon(app)
    h = p.get("/api/v1/health")
    assert h.json() == {"status": "ok"} and h.headers["x-content-type-options"] == "nosniff" and h.headers["x-frame-options"] == "DENY"
    assert p.get("/api/v1/health/ready").json()["checks"] == {"database": True, "storage": True}
    paths = p.get("/api/openapi.json").json()["paths"]
    for expected in ("/api/v1/episodes", "/api/v1/articles/{slug}", "/api/v1/media/upload", "/api/v1/payments/webhooks/{provider_name}", "/api/v1/subscribers"):
        assert expected in paths
    assert p.get("/api/v1/auth/session").headers["cache-control"] == "no-store"
