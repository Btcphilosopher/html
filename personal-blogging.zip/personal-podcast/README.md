# Personal Podcast: podcast, blog and Bitcoin publishing platform

A self-hosted publication for one author: podcast with MP3 hosting and validated RSS, a Markdown blog, an
administration area, Bitcoin support (Lightning invoices and an on-chain address) and email subscriptions.

* **Frontend:** one file, [`index.html`](index.html). Vanilla HTML, CSS and JavaScript, no build step, no external libraries.
* **Backend:** FastAPI (Python 3.12), SQLAlchemy 2, Alembic, PostgreSQL in production (SQLite for development).
* **Deployment:** Docker Compose with PostgreSQL and Caddy (automatic HTTPS).

## Status: what is implemented, what was tested, what is not

Everything below was run in the build environment unless it says otherwise.

| Result | Detail |
|---|---|
| Backend tests | **45 passed** (`pytest`, about 25 s) against the real app, a real SQLite database and real `ffprobe`/MP3 files |
| Frontend smoke test | **18 checks passed, 0 browser errors** (`scripts/frontend_smoke.cjs`, jsdom driving the real `index.html` served by a running backend) |
| Migrations | Alembic `upgrade head` and `downgrade base` tested; a test fails if the models and migration drift apart |

**Not exercised.** Docker, Docker Compose, Caddy, PostgreSQL, a real browser (layout, responsiveness, real audio
decoding, CSP enforcement, upload progress bars), a live LNbits instance, a real SMTP server, and the backup scripts.
They are written to be correct but have not been run. Run the [pre-launch checklist](#pre-launch-checklist) before going live.

### Implemented

* Episodes and articles: drafts, scheduling, publish/unpublish, soft delete and restore, revision history (restore for
  articles), optimistic concurrency (a stale editor cannot overwrite newer work), permanent slugs (locked while public).
* Server-side Markdown rendering with an allow-list sanitiser; the editor preview is rendered by the same server code.
* MP3 and image upload: streamed to disk, size limit and quota, file-signature check, `ffprobe` validation and duration,
  unguessable storage names, no client-supplied paths.
* Media delivery with `Range`/`206`/`416`, `HEAD`, `ETag`, `If-None-Match`, `If-Range`. Draft media is not publicly readable.
* RSS 2.0 with Apple Podcasts tags at `/feed/podcast.xml`, `/feed/blog.xml`, `/feed/all.xml`; enclosure length is read
  from the stored file; stable GUIDs; ETag and Last-Modified.
* Bitcoin: checksum-validated donation address (Base58Check, Bech32, Bech32m), BIP21 URI, server-generated QR codes;
  Lightning through a provider interface with an LNbits adapter; verified-settlement-only accounting; idempotent webhooks.
* Email subscriptions with verification and unsubscribe (switched off, with a clear message, until SMTP is configured).
* Admin dashboard with measured values only, media library with upload progress and retry, settings, password change.
* Server-injected SEO metadata (`<title>`, canonical, Open Graph, `og:audio`), `sitemap.xml`, `robots.txt`.

### Not implemented (be aware before relying on it)

* **Paid articles, supporter-only audio and memberships.** Everything is free. No half-built access control exists.
* **On-chain payment tracking** (Bitcoin Core / Esplora). The site shows an address and says gifts are not tracked.
* **Listener analytics.** No downloads or listeners are counted; the dashboard says so.
* **S3-compatible object storage.** Storage is a local filesystem behind a small class (`services/storage.py`).
  See [Moving to object storage](#moving-to-object-storage).
* Waveforms, loudness analysis, artwork resizing, transcription integrations, `podcast:chapters` in the feed (chapters
  are stored and shown on the episode page), category-specific feeds, sending newsletters (only the verified list is kept).
* Two-factor authentication. Rate limits and the scheduler assume a single application process.
* Real-browser end-to-end tests (Playwright or similar).

## Repository layout

```text
index.html                    the entire frontend
backend/app/                  FastAPI application (api/, services/, models.py, schemas.py, security.py, tests/)
backend/migrations/           Alembic migrations (0001 initial schema)
backend/Dockerfile            application image (includes ffmpeg/ffprobe)
deploy/compose.yaml           PostgreSQL + application + Caddy
deploy/Caddyfile              HTTPS reverse proxy (replaces the suggested reverse-proxy.conf)
scripts/                      backup.sh, restore.sh, frontend_smoke.cjs
.env.example  SECURITY.md  LICENSE
```

## Local development

Prerequisites: Python 3.12+, `ffmpeg` (for `ffprobe`), Node 18+ only if you want to run the frontend smoke test.

```sh
cd backend
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt

export PP_ENV=development PP_COOKIE_SECURE=false      # plain http://localhost; never do this in production
alembic upgrade head                                   # creates ./data/personal_podcast.db
python -m app.manage create-admin --email you@example.com      # prompts for a password (12+ characters)
python -m app.manage seed-sample                       # optional: clearly labelled [Sample] content and a test tone
python -m uvicorn app.main:app_factory --factory --reload
```

Open <http://localhost:8000>. The backend serves `index.html`; do not open the file with `file://`. API docs generated
from the code are at `/api/docs`. The sign-in link is in the footer ("Administrator sign in").

Run the tests:

```sh
cd backend && python -m pytest -q                      # backend, 45 tests
# frontend smoke test (server must be running with an admin user and the [Sample] content):
npm install jsdom && NODE_PATH=node_modules BASE=http://localhost:8000 ADMIN_EMAIL=... ADMIN_PASSWORD=... node ../scripts/frontend_smoke.cjs
```

The smoke test expects the site title "The Slow Journal", three suggested amounts and a donation address in Settings;
adjust the assertions if you use other values.

## Configuration

All settings are environment variables prefixed `PP_` (see [`.env.example`](.env.example)). The application **refuses to
start** in production if cookies are not `Secure`, the site URL is not HTTPS, or the secret key is short or still a
placeholder. `PP_PAYMENT_PROVIDER=mock` is rejected unless `PP_ENV=test`.

Site identity (title, publisher, about page, biography, social links, contact address, copyright, podcast metadata,
default artwork, donation address, suggested amounts) is edited in **Administration, Settings**; nothing personal is invented.

## Production deployment (Docker Compose)

1. Point a DNS record at your server and open ports 80 and 443.
2. `cp .env.example .env` and set at least `PP_DOMAIN`, `PP_SITE_URL`, `PP_SECRET_KEY` (`openssl rand -hex 32`) and `POSTGRES_PASSWORD`.
3. Start: `docker compose --env-file .env -f deploy/compose.yaml up -d --build`. The application waits for PostgreSQL to be
   healthy, runs `alembic upgrade head`, then starts; Caddy starts once the application reports ready.
4. Create the administrator: `docker compose --env-file .env -f deploy/compose.yaml exec app python -m app.manage create-admin --email you@example.com`.
5. Sign in, open **Settings**, fill in the identity, podcast category, owner email and artwork, and add your donation address.
6. Check the dashboard: its "Podcast feed" section lists anything Apple Podcasts and similar directories will complain about.

### Podcast feeds and directories

Feed address: `https://your-domain/feed/podcast.xml`. Validate it with a podcast feed validator of your choice, then
submit it to each directory's own console (Apple Podcasts Connect, Spotify, and others). Directories need square
artwork (1400 to 3000 px), a category, an owner email, a description and HTTPS enclosures; the dashboard checks for these.

### Bitcoin

* **On-chain:** paste an address into Settings. It is checked for a valid checksum. The site shows it with a QR code
  and a BIP21 link. Nothing is recorded and no confirmation is shown, because tracking needs a node or indexer
  (not implemented). Verify the address yourself before publishing: funds sent to a wrong address cannot be recovered.
* **Lightning (LNbits):** create a wallet, then set `PP_PAYMENT_PROVIDER=lnbits`, `PP_LNBITS_URL`, `PP_LNBITS_INVOICE_KEY`
  (the *invoice/read* key, never the admin key) and `PP_LNBITS_WEBHOOK_SECRET`. Your LNbits instance must be able to reach
  `PP_SITE_URL`. An invoice becomes *paid* only when the server asks LNbits for the payment status and LNbits says it is
  settled; a webhook alone is never trusted. The adapter follows LNbits's documented HTTP API and is tested against a
  simulated LNbits, **not a live one**. Make a small real payment before announcing Lightning support.

### Backups and restore

`scripts/backup.sh` writes a PostgreSQL custom-format dump and a tarball of the media volume; `scripts/restore.sh <dir> --yes`
reverses it. Copy backups off the server and test a restore on a spare machine before you need it. Neither script has been run.

### Updating

`git pull`, then `docker compose --env-file .env -f deploy/compose.yaml up -d --build`. Migrations run on start. Take a backup first.

### Moving to object storage

Public URLs are `/media/{public_id}/{name}` and enclosure URLs are derived from `public_id`, never from the storage
location, so switching storage does not change episode or RSS URLs. To switch, implement the methods of
`LocalStorage` (`save`, `exists`, `size`, `read_range`, `delete`, `writable`) for your object store, keep a local
temporary directory for incoming uploads (`new_tmp`, `cleanup_tmp`), copy each object under its existing `storage_key`,
and construct the new class in `app/main.py`. For large audiences, serve objects from the
store or a CDN with `Range` support instead of through Python.

### Retention

Nothing is deleted automatically except abandoned temporary uploads (older than `PP_STALE_UPLOAD_SECONDS`, swept hourly
and at start). Audit logs, content revisions and payment events are kept; prune them in SQL according to your own policy.

## API

Generated from the code at `/api/docs` and `/api/openapi.json`. Errors always look like
`{"error": {"code": "...", "message": "...", "details": ...}}`. Cookie-authenticated writes need the `X-CSRF-Token`
header returned by login and session. Public endpoints return only content that is live (published, or scheduled and due).

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Application exits at start with a validation error | A production safety check failed; the message names the variable |
| Sign-in works but every write returns `csrf_failed` | The page was loaded from a different origin than the API; use one domain |
| Uploads fail with `413` | Raise `PP_MAX_AUDIO_MB` and the `max_size` in `deploy/Caddyfile` together |
| Upload says the file is not MP3 | Contents are inspected; re-export as MP3 (AAC/M4A is not accepted) |
| Feed shows no episodes | The episode is a draft, scheduled for the future, or its audio file is missing from storage (see logs) |
| Lightning invoices return `lightning_unavailable` | `PP_PAYMENT_PROVIDER` is `none` |
| Subscribe form says it is unavailable | `PP_SMTP_HOST` and `PP_SMTP_FROM` are not set |
| Direct URL gives a blank page behind your own proxy | The proxy must pass every non-file path to the application so it can serve `index.html` |

## Pre-launch checklist

- [ ] HTTPS works, HTTP redirects, `PP_ENV=production`, the startup safety checks pass
- [ ] `PP_SECRET_KEY` and `POSTGRES_PASSWORD` are random and unique; `.env` is not in version control
- [ ] Administrator created with a strong password; no other accounts exist
- [ ] Media volume is persistent; the application user can write to it; the quota fits the disk
- [ ] Feed validated; artwork, category, owner email and description set; one test episode plays, seeks and downloads
- [ ] A backup was taken **and restored on another machine**
- [ ] Donation address checked by eye and by sending a small test amount you can recover
- [ ] If using Lightning: a small real payment was made and the invoice turned *paid*
- [ ] If using email: a real verification email arrived and the link worked
- [ ] Reviewed [SECURITY.md](SECURITY.md), including the known limitations
