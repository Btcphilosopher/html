# FAN: Phase 1 (functional foundation)

A launchable video platform foundation: FastAPI backend, SQLAlchemy catalogue, range-request media delivery,
and a single `index.html` with a launch screen, catalogue browsing and a custom player.
This build has not been executed or tested yet. Run it and expect to fix small issues.

## Run (development)
Requires Python 3.12+. FFmpeg is optional but needed to generate the labelled sample videos.

    bash launchers/start-linux-macos.sh      # Linux / macOS
    launchers\start-windows.bat              # Windows

The launcher checks dependencies, avoids starting a duplicate backend, waits for /api/health, then opens
http://127.0.0.1:8000. A browser cannot start a backend by itself, so index.html shows connection status and
instructions instead. Opened via file://, it explains the browser restrictions and offers to try the local backend.
Interactive API docs (development only): http://127.0.0.1:8000/api/docs

## Hosted mode
Serve index.html from the web server and set <meta name="fan-api" content="https://api.example.com">
(empty means same origin). Set FAN_ENV=production, FAN_DATABASE_URL (PostgreSQL) and FAN_CORS_ORIGINS.
Terminate HTTPS at a reverse proxy.

## What works now
Health and config endpoints; published-video listing with search, category filter, sort and pagination;
playback metadata; HTTP range streaming; thumbnails; consistent JSON errors; request IDs; player controls
(play, seek, volume, speed, picture-in-picture, theatre, fullscreen, keyboard shortcuts, buffering and error states).

## Not built yet
Phase 2: accounts, history, favourites, playlists, Alembic migrations (tables are created at startup for now).
Phase 3: Studio, uploads, FFprobe/FFmpeg processing jobs, roles.
Phase 4: HLS, renditions, subtitles, signed URLs.
Phase 5: analytics, Redis, rate limits, Docker Compose, tests, backup and deployment guidance.
The player shows no quality, subtitle or audio-track menus because no source has those yet.
