@echo off
rem Starts the FAN backend (if not already running) and opens the app. Never deletes data.
setlocal
cd /d "%~dp0.."
set "HOST=127.0.0.1"
set "PORT=8000"
set "URL=http://%HOST%:%PORT%"

powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 '%URL%/api/health' | Out-Null; exit 0 } catch { exit 1 }"
if %errorlevel%==0 (
  echo FAN backend already running at %URL%
  start "" "%URL%"
  exit /b 0
)

py -3.12 -c "import sys" >nul 2>&1
if errorlevel 1 (
  echo Python 3.12 is required, and the py launcher must find it. Install it from python.org.
  exit /b 1
)
where ffmpeg >nul 2>&1 || echo Warning: ffmpeg not found. Sample videos cannot be generated.

if not exist .venv py -3.12 -m venv .venv
.venv\Scripts\pip install -q -r requirements.txt || exit /b 1

start "FAN backend" /min .venv\Scripts\uvicorn app.main:app --app-dir backend --host %HOST% --port %PORT%
for /l %%i in (1,1,30) do (
  powershell -NoProfile -Command "try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 '%URL%/api/health' | Out-Null; exit 0 } catch { exit 1 }"
  if not errorlevel 1 (
    echo FAN is up at %URL%
    start "" "%URL%"
    exit /b 0
  )
  timeout /t 1 >nul
)
echo The backend did not become healthy within 30 seconds. Check the "FAN backend" window for errors.
exit /b 1
