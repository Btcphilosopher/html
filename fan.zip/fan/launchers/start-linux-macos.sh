#!/usr/bin/env bash
# Starts the FAN backend (if not already running) and opens the app. Never deletes data.
set -euo pipefail
cd "$(dirname "$0")/.."
HOST="${FAN_HOST:-127.0.0.1}"; PORT="${FAN_PORT:-8000}"; URL="http://$HOST:$PORT"

command -v curl >/dev/null || { echo "curl is required." >&2; exit 1; }
healthy() { curl -fsS --max-time 2 "$URL/api/health" 2>/dev/null | grep -q '"status":"ok"'; }
open_app() { (command -v xdg-open >/dev/null && xdg-open "$URL") || (command -v open >/dev/null && open "$URL") || echo "Open $URL in your browser."; }

if healthy; then echo "FAN backend already running at $URL"; open_app; exit 0; fi

PY="$(command -v python3.12 || command -v python3 || true)"
[ -n "$PY" ] || { echo "Python 3.12 or newer is required." >&2; exit 1; }
"$PY" -c 'import sys; sys.exit(sys.version_info < (3, 12))' || { echo "Python 3.12 or newer is required." >&2; exit 1; }
command -v ffmpeg >/dev/null || echo "Warning: ffmpeg not found. Sample videos cannot be generated (see README)."

[ -d .venv ] || "$PY" -m venv .venv
.venv/bin/pip install -q -r requirements.txt

nohup .venv/bin/uvicorn app.main:app --app-dir backend --host "$HOST" --port "$PORT" > fan-backend.log 2>&1 &
echo $! > .fan.pid
for _ in $(seq 1 30); do
  if healthy; then echo "FAN is up at $URL"; open_app; exit 0; fi
  sleep 1
done
echo "The backend did not become healthy within 30 seconds. Last log lines:" >&2
tail -n 20 fan-backend.log >&2
exit 1
