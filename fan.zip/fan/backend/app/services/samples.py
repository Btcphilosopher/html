"""Development-only demonstration media, generated locally by FFmpeg (original, not copyrighted)."""
import logging
import shutil
import subprocess

from .. import config
from ..database import SessionLocal, Video

log = logging.getLogger("fan.samples")
SECONDS = 12
SAMPLES = [
    ("[Sample] Test pattern", "Test Cards", "testsrc2"),
    ("[Sample] Colour bars", "Test Cards", "smptebars"),
    ("[Sample] RGB channels", "Colour", "rgbtestsrc"),
]


def _ffmpeg(*args: str) -> None:
    # Argument list, no shell, with a timeout.
    subprocess.run([config.FFMPEG, "-y", "-v", "error", *args], check=True, capture_output=True, timeout=120)


def seed() -> None:
    if not config.SEED_SAMPLES:
        return
    if not shutil.which(config.FFMPEG):
        log.warning("FFmpeg not found; sample videos were not generated.")
        return
    with SessionLocal() as db:
        if db.query(Video).filter_by(is_sample=True).first():
            return
        for i, (title, category, src) in enumerate(SAMPLES, 1):
            media, thumb = f"processed/sample-{i}.mp4", f"thumbnails/sample-{i}.jpg"
            try:
                _ffmpeg(
                    "-f", "lavfi", "-i", f"{src}=size=640x360:rate=30:duration={SECONDS}",
                    "-f", "lavfi", "-i", f"sine=frequency={220 * i}:duration={SECONDS}",
                    "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-b:a", "64k", "-shortest", "-movflags", "+faststart",
                    str(config.MEDIA_DIR / media),
                )
                _ffmpeg("-i", str(config.MEDIA_DIR / media), "-frames:v", "1", "-vf", "scale=640:-2",
                        str(config.MEDIA_DIR / thumb))
            except (subprocess.SubprocessError, OSError) as exc:
                log.warning("Could not generate %s: %s", title, exc)
                continue
            db.add(Video(
                title=title, category=category, status="published", duration_s=SECONDS,
                description="Demonstration data generated locally by FFmpeg. It is not real content.",
                media_path=media, thumb_path=thumb, mime="video/mp4", is_sample=True,
            ))
        db.commit()
