import logging
import re
import shutil
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from sqlalchemy import func, or_, select, text
from sqlalchemy.orm import Session
from starlette.exceptions import HTTPException as StarletteHTTPException

from . import config
from .database import Base, SessionLocal, Video, engine
from .services import samples

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
log = logging.getLogger("fan")
VERSION = "0.1.0"


@asynccontextmanager
async def lifespan(app: FastAPI):
    for d in ("uploads", "processed", "thumbnails", "subtitles"):
        (config.MEDIA_DIR / d).mkdir(parents=True, exist_ok=True)
    Base.metadata.create_all(engine)  # Phase 1 only; Alembic migrations arrive with the Phase 2 schema
    samples.seed()
    log.info("FAN %s started in %s mode", VERSION, config.ENV)
    yield


app = FastAPI(
    title="FAN", version=VERSION, lifespan=lifespan, redoc_url=None,
    docs_url="/api/docs" if config.IS_DEV else None,
    openapi_url="/api/openapi.json" if config.IS_DEV else None,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if config.IS_DEV else config.CORS_ORIGINS,  # dev only: lets a file:// page reach the API
    allow_methods=["GET"], allow_headers=["*"],
    expose_headers=["Content-Range", "Accept-Ranges", "X-Request-ID"],
)


@app.middleware("http")
async def request_id(request: Request, call_next):
    rid = request.headers.get("x-request-id", "")[:64] or uuid.uuid4().hex[:12]
    response = await call_next(request)
    response.headers["X-Request-ID"] = rid
    return response


@app.exception_handler(StarletteHTTPException)
async def http_error(_: Request, exc: StarletteHTTPException):
    return JSONResponse({"error": {"status": exc.status_code, "message": str(exc.detail)}},
                        status_code=exc.status_code, headers=getattr(exc, "headers", None))


@app.exception_handler(RequestValidationError)
async def validation_error(_: Request, exc: RequestValidationError):
    return JSONResponse({"error": {"status": 422, "message": "Invalid request", "details": jsonable_encoder(exc.errors())}},
                        status_code=422)


def get_db():
    with SessionLocal() as db:
        yield db


def card(v: Video) -> dict:
    return {
        "id": v.id, "title": v.title, "description": v.description, "category": v.category,
        "duration_s": v.duration_s, "is_sample": v.is_sample, "created_at": v.created_at.isoformat(),
        "thumbnail_url": f"/media/thumb/{v.id}" if v.thumb_path else None,
    }


def published(db: Session, video_id: int) -> Video:
    v = db.get(Video, video_id)
    if not v or v.status != "published":
        raise HTTPException(404, "Video not found")
    return v


def resolve(rel: str | None) -> Path:
    """Map a stored relative path to a file inside MEDIA_DIR; never expose or accept raw paths."""
    p = (config.MEDIA_DIR / (rel or "")).resolve()
    if not rel or not p.is_relative_to(config.MEDIA_DIR) or not p.is_file():
        raise HTTPException(404, "Media file not found")
    return p


@app.get("/api/health")
def health():
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        log.exception("Database check failed")
        db_ok = False
    return {"status": "ok" if db_ok else "degraded", "env": config.ENV, "version": VERSION,
            "database": "up" if db_ok else "down", "ffmpeg": bool(shutil.which(config.FFMPEG))}


@app.get("/api/config")
def public_config():
    # Honest feature flags: only what this build actually implements.
    return {"name": "FAN", "env": config.ENV, "dev_mode": config.IS_DEV, "phase": 1,
            "features": {"auth": False, "uploads": False, "hls": False, "subtitles": False}}


SORTS = {"new": Video.created_at.desc(), "title": Video.title.asc(), "duration": Video.duration_s.desc()}


@app.get("/api/videos")
def list_videos(q: str | None = Query(None, max_length=100), category: str | None = Query(None, max_length=60),
                sort: str = "new", page: int = Query(1, ge=1), page_size: int = Query(24, ge=1, le=60),
                db: Session = Depends(get_db)):
    stmt = select(Video).where(Video.status == "published")
    if q and q.strip():
        like = "%" + re.sub(r"([%_\\])", r"\\\1", q.strip()) + "%"
        stmt = stmt.where(or_(Video.title.ilike(like, escape="\\"), Video.description.ilike(like, escape="\\")))
    if category:
        stmt = stmt.where(Video.category == category)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(SORTS.get(sort, SORTS["new"]), Video.id)
                      .offset((page - 1) * page_size).limit(page_size)).all()
    cats = db.scalars(select(Video.category).where(Video.status == "published").distinct()
                      .order_by(Video.category)).all()
    return {"items": [card(v) for v in rows], "total": total, "page": page, "page_size": page_size,
            "categories": cats}


@app.get("/api/videos/{video_id}")
def get_video(video_id: int, db: Session = Depends(get_db)):
    return card(published(db, video_id))


@app.get("/api/videos/{video_id}/playback")
def playback(video_id: int, db: Session = Depends(get_db)):
    v = published(db, video_id)
    resolve(v.media_path)  # fail early if the file is missing
    return {"video_id": v.id, "mime": v.mime, "url": f"/media/stream/{v.id}", "duration_s": v.duration_s,
            "renditions": [], "subtitles": [], "audio_tracks": []}  # none exist yet; the UI shows none


def _parse_range(header: str, size: int):
    m = re.fullmatch(r"bytes=(\d*)-(\d*)", header.strip())
    if not m or not (m[1] or m[2]):
        return None  # malformed or multi-range: ignore and serve the whole file
    if m[1]:
        start, end = int(m[1]), int(m[2]) if m[2] else size - 1
    else:
        start, end = max(size - int(m[2]), 0), size - 1
    end = min(end, size - 1)
    return "unsatisfiable" if start >= size or start > end else (start, end)


def _iter(path: Path, start: int, end: int, chunk: int = 1 << 20):
    with open(path, "rb") as f:
        f.seek(start)
        left = end - start + 1
        while left > 0:
            data = f.read(min(chunk, left))
            if not data:
                break
            left -= len(data)
            yield data


@app.get("/media/stream/{video_id}")
def stream(video_id: int, request: Request, db: Session = Depends(get_db)):
    v = published(db, video_id)
    path, mime = resolve(v.media_path), v.mime
    size = path.stat().st_size
    headers = {"Accept-Ranges": "bytes", "Cache-Control": "private, max-age=300"}
    rng = _parse_range(request.headers["range"], size) if "range" in request.headers else None
    if rng == "unsatisfiable":
        raise HTTPException(416, "Range not satisfiable", headers={"Content-Range": f"bytes */{size}"})
    if rng is None:
        return StreamingResponse(_iter(path, 0, size - 1), media_type=mime,
                                 headers={**headers, "Content-Length": str(size)})
    start, end = rng
    return StreamingResponse(_iter(path, start, end), status_code=206, media_type=mime, headers={
        **headers, "Content-Range": f"bytes {start}-{end}/{size}", "Content-Length": str(end - start + 1)})


@app.get("/media/thumb/{video_id}")
def thumb(video_id: int, db: Session = Depends(get_db)):
    v = published(db, video_id)
    return FileResponse(resolve(v.thumb_path), media_type="image/jpeg",
                        headers={"Cache-Control": "public, max-age=86400"})


if config.SERVE_FRONTEND:
    @app.get("/", include_in_schema=False)
    def index():
        return FileResponse(config.ROOT / "index.html", media_type="text/html")
