import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def _bool(value: str | None, default: bool) -> bool:
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "on"}


ENV = os.getenv("FAN_ENV", "development")
IS_DEV = ENV != "production"
DATABASE_URL = os.getenv("FAN_DATABASE_URL", f"sqlite:///{ROOT / 'fan.db'}")
MEDIA_DIR = Path(os.getenv("FAN_MEDIA_DIR", ROOT / "media")).resolve()
CORS_ORIGINS = [o.strip() for o in os.getenv("FAN_CORS_ORIGINS", "").split(",") if o.strip()]
SEED_SAMPLES = _bool(os.getenv("FAN_SEED_SAMPLES"), IS_DEV)
SERVE_FRONTEND = _bool(os.getenv("FAN_SERVE_FRONTEND"), True)
FFMPEG = os.getenv("FAN_FFMPEG", "ffmpeg")
